package androidx.activity.result;

public interface ActivityResultCallback<O> {
  void onActivityResult(O paramO);
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\activity\result\ActivityResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */