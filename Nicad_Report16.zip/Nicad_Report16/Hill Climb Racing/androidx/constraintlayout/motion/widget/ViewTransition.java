package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import androidx.constraintlayout.core.motion.utils.Easing;
import androidx.constraintlayout.core.motion.utils.KeyCache;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.R;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;

public class ViewTransition {
  static final int ANTICIPATE = 6;
  
  static final int BOUNCE = 4;
  
  public static final String CONSTRAINT_OVERRIDE = "ConstraintOverride";
  
  public static final String CUSTOM_ATTRIBUTE = "CustomAttribute";
  
  public static final String CUSTOM_METHOD = "CustomMethod";
  
  static final int EASE_IN = 1;
  
  static final int EASE_IN_OUT = 0;
  
  static final int EASE_OUT = 2;
  
  private static final int INTERPOLATOR_REFERENCE_ID = -2;
  
  public static final String KEY_FRAME_SET_TAG = "KeyFrameSet";
  
  static final int LINEAR = 3;
  
  public static final int ONSTATE_ACTION_DOWN = 1;
  
  public static final int ONSTATE_ACTION_DOWN_UP = 3;
  
  public static final int ONSTATE_ACTION_UP = 2;
  
  public static final int ONSTATE_SHARED_VALUE_SET = 4;
  
  public static final int ONSTATE_SHARED_VALUE_UNSET = 5;
  
  static final int OVERSHOOT = 5;
  
  private static final int SPLINE_STRING = -1;
  
  private static String TAG = "ViewTransition";
  
  private static final int UNSET = -1;
  
  static final int VIEWTRANSITIONMODE_ALLSTATES = 1;
  
  static final int VIEWTRANSITIONMODE_CURRENTSTATE = 0;
  
  static final int VIEWTRANSITIONMODE_NOSTATE = 2;
  
  public static final String VIEW_TRANSITION_TAG = "ViewTransition";
  
  private int mClearsTag;
  
  ConstraintSet.Constraint mConstraintDelta;
  
  Context mContext;
  
  private int mDefaultInterpolator;
  
  private int mDefaultInterpolatorID;
  
  private String mDefaultInterpolatorString;
  
  private boolean mDisabled;
  
  private int mDuration;
  
  private int mId;
  
  private int mIfTagNotSet;
  
  private int mIfTagSet;
  
  KeyFrames mKeyFrames;
  
  private int mOnStateTransition;
  
  private int mPathMotionArc;
  
  private int mSetsTag;
  
  private int mSharedValueCurrent;
  
  private int mSharedValueID;
  
  private int mSharedValueTarget;
  
  private int mTargetId;
  
  private String mTargetString;
  
  private int mUpDuration;
  
  int mViewTransitionMode;
  
  ConstraintSet set;
  
  ViewTransition(Context paramContext, XmlPullParser paramXmlPullParser) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: iconst_m1
    //   6: putfield mOnStateTransition : I
    //   9: aload_0
    //   10: iconst_0
    //   11: putfield mDisabled : Z
    //   14: aload_0
    //   15: iconst_0
    //   16: putfield mPathMotionArc : I
    //   19: aload_0
    //   20: iconst_m1
    //   21: putfield mDuration : I
    //   24: aload_0
    //   25: iconst_m1
    //   26: putfield mUpDuration : I
    //   29: aload_0
    //   30: iconst_0
    //   31: putfield mDefaultInterpolator : I
    //   34: aload_0
    //   35: aconst_null
    //   36: putfield mDefaultInterpolatorString : Ljava/lang/String;
    //   39: aload_0
    //   40: iconst_m1
    //   41: putfield mDefaultInterpolatorID : I
    //   44: aload_0
    //   45: iconst_m1
    //   46: putfield mSetsTag : I
    //   49: aload_0
    //   50: iconst_m1
    //   51: putfield mClearsTag : I
    //   54: aload_0
    //   55: iconst_m1
    //   56: putfield mIfTagSet : I
    //   59: aload_0
    //   60: iconst_m1
    //   61: putfield mIfTagNotSet : I
    //   64: aload_0
    //   65: iconst_m1
    //   66: putfield mSharedValueTarget : I
    //   69: aload_0
    //   70: iconst_m1
    //   71: putfield mSharedValueID : I
    //   74: aload_0
    //   75: iconst_m1
    //   76: putfield mSharedValueCurrent : I
    //   79: aload_0
    //   80: aload_1
    //   81: putfield mContext : Landroid/content/Context;
    //   84: aload_2
    //   85: invokeinterface getEventType : ()I
    //   90: istore_3
    //   91: iload_3
    //   92: iconst_1
    //   93: if_icmpeq -> 455
    //   96: iload_3
    //   97: iconst_2
    //   98: if_icmpeq -> 124
    //   101: iload_3
    //   102: iconst_3
    //   103: if_icmpeq -> 109
    //   106: goto -> 434
    //   109: ldc 'ViewTransition'
    //   111: aload_2
    //   112: invokeinterface getName : ()Ljava/lang/String;
    //   117: invokevirtual equals : (Ljava/lang/Object;)Z
    //   120: ifeq -> 434
    //   123: return
    //   124: aload_2
    //   125: invokeinterface getName : ()Ljava/lang/String;
    //   130: astore #4
    //   132: aload #4
    //   134: invokevirtual hashCode : ()I
    //   137: lookupswitch default -> 456, -1962203927 -> 248, -1239391468 -> 233, 61998586 -> 218, 366511058 -> 203, 1791837707 -> 188
    //   188: aload #4
    //   190: ldc 'CustomAttribute'
    //   192: invokevirtual equals : (Ljava/lang/Object;)Z
    //   195: ifeq -> 456
    //   198: iconst_3
    //   199: istore_3
    //   200: goto -> 263
    //   203: aload #4
    //   205: ldc 'CustomMethod'
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifeq -> 456
    //   213: iconst_4
    //   214: istore_3
    //   215: goto -> 263
    //   218: aload #4
    //   220: ldc 'ViewTransition'
    //   222: invokevirtual equals : (Ljava/lang/Object;)Z
    //   225: ifeq -> 456
    //   228: iconst_0
    //   229: istore_3
    //   230: goto -> 263
    //   233: aload #4
    //   235: ldc 'KeyFrameSet'
    //   237: invokevirtual equals : (Ljava/lang/Object;)Z
    //   240: ifeq -> 456
    //   243: iconst_1
    //   244: istore_3
    //   245: goto -> 263
    //   248: aload #4
    //   250: ldc 'ConstraintOverride'
    //   252: invokevirtual equals : (Ljava/lang/Object;)Z
    //   255: ifeq -> 456
    //   258: iconst_2
    //   259: istore_3
    //   260: goto -> 263
    //   263: iload_3
    //   264: ifeq -> 428
    //   267: iload_3
    //   268: iconst_1
    //   269: if_icmpeq -> 412
    //   272: iload_3
    //   273: iconst_2
    //   274: if_icmpeq -> 400
    //   277: iload_3
    //   278: iconst_3
    //   279: if_icmpeq -> 385
    //   282: iload_3
    //   283: iconst_4
    //   284: if_icmpeq -> 385
    //   287: getstatic androidx/constraintlayout/motion/widget/ViewTransition.TAG : Ljava/lang/String;
    //   290: astore #5
    //   292: new java/lang/StringBuilder
    //   295: dup
    //   296: invokespecial <init> : ()V
    //   299: astore #6
    //   301: aload #6
    //   303: invokestatic getLoc : ()Ljava/lang/String;
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload #6
    //   312: ldc ' unknown tag '
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: aload #6
    //   320: aload #4
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: pop
    //   326: aload #5
    //   328: aload #6
    //   330: invokevirtual toString : ()Ljava/lang/String;
    //   333: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   336: pop
    //   337: getstatic androidx/constraintlayout/motion/widget/ViewTransition.TAG : Ljava/lang/String;
    //   340: astore #4
    //   342: new java/lang/StringBuilder
    //   345: dup
    //   346: invokespecial <init> : ()V
    //   349: astore #5
    //   351: aload #5
    //   353: ldc '.xml:'
    //   355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   358: pop
    //   359: aload #5
    //   361: aload_2
    //   362: invokeinterface getLineNumber : ()I
    //   367: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   370: pop
    //   371: aload #4
    //   373: aload #5
    //   375: invokevirtual toString : ()Ljava/lang/String;
    //   378: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   381: pop
    //   382: goto -> 434
    //   385: aload_1
    //   386: aload_2
    //   387: aload_0
    //   388: getfield mConstraintDelta : Landroidx/constraintlayout/widget/ConstraintSet$Constraint;
    //   391: getfield mCustomConstraints : Ljava/util/HashMap;
    //   394: invokestatic parse : (Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;Ljava/util/HashMap;)V
    //   397: goto -> 434
    //   400: aload_0
    //   401: aload_1
    //   402: aload_2
    //   403: invokestatic buildDelta : (Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;)Landroidx/constraintlayout/widget/ConstraintSet$Constraint;
    //   406: putfield mConstraintDelta : Landroidx/constraintlayout/widget/ConstraintSet$Constraint;
    //   409: goto -> 434
    //   412: aload_0
    //   413: new androidx/constraintlayout/motion/widget/KeyFrames
    //   416: dup
    //   417: aload_1
    //   418: aload_2
    //   419: invokespecial <init> : (Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;)V
    //   422: putfield mKeyFrames : Landroidx/constraintlayout/motion/widget/KeyFrames;
    //   425: goto -> 434
    //   428: aload_0
    //   429: aload_1
    //   430: aload_2
    //   431: invokespecial parseViewTransitionTags : (Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;)V
    //   434: aload_2
    //   435: invokeinterface next : ()I
    //   440: istore_3
    //   441: goto -> 91
    //   444: astore_1
    //   445: aload_1
    //   446: invokevirtual printStackTrace : ()V
    //   449: return
    //   450: astore_1
    //   451: aload_1
    //   452: invokevirtual printStackTrace : ()V
    //   455: return
    //   456: iconst_m1
    //   457: istore_3
    //   458: goto -> 263
    // Exception table:
    //   from	to	target	type
    //   84	91	450	org/xmlpull/v1/XmlPullParserException
    //   84	91	444	java/io/IOException
    //   109	123	450	org/xmlpull/v1/XmlPullParserException
    //   109	123	444	java/io/IOException
    //   124	188	450	org/xmlpull/v1/XmlPullParserException
    //   124	188	444	java/io/IOException
    //   188	198	450	org/xmlpull/v1/XmlPullParserException
    //   188	198	444	java/io/IOException
    //   203	213	450	org/xmlpull/v1/XmlPullParserException
    //   203	213	444	java/io/IOException
    //   218	228	450	org/xmlpull/v1/XmlPullParserException
    //   218	228	444	java/io/IOException
    //   233	243	450	org/xmlpull/v1/XmlPullParserException
    //   233	243	444	java/io/IOException
    //   248	258	450	org/xmlpull/v1/XmlPullParserException
    //   248	258	444	java/io/IOException
    //   287	382	450	org/xmlpull/v1/XmlPullParserException
    //   287	382	444	java/io/IOException
    //   385	397	450	org/xmlpull/v1/XmlPullParserException
    //   385	397	444	java/io/IOException
    //   400	409	450	org/xmlpull/v1/XmlPullParserException
    //   400	409	444	java/io/IOException
    //   412	425	450	org/xmlpull/v1/XmlPullParserException
    //   412	425	444	java/io/IOException
    //   428	434	450	org/xmlpull/v1/XmlPullParserException
    //   428	434	444	java/io/IOException
    //   434	441	450	org/xmlpull/v1/XmlPullParserException
    //   434	441	444	java/io/IOException
  }
  
  private void parseViewTransitionTags(Context paramContext, XmlPullParser paramXmlPullParser) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), R.styleable.ViewTransition);
    int j = typedArray.getIndexCount();
    for (int i = 0; i < j; i++) {
      int k = typedArray.getIndex(i);
      if (k == R.styleable.ViewTransition_android_id) {
        this.mId = typedArray.getResourceId(k, this.mId);
      } else if (k == R.styleable.ViewTransition_motionTarget) {
        if (MotionLayout.IS_IN_EDIT_MODE) {
          int m = typedArray.getResourceId(k, this.mTargetId);
          this.mTargetId = m;
          if (m == -1)
            this.mTargetString = typedArray.getString(k); 
        } else if ((typedArray.peekValue(k)).type == 3) {
          this.mTargetString = typedArray.getString(k);
        } else {
          this.mTargetId = typedArray.getResourceId(k, this.mTargetId);
        } 
      } else if (k == R.styleable.ViewTransition_onStateTransition) {
        this.mOnStateTransition = typedArray.getInt(k, this.mOnStateTransition);
      } else if (k == R.styleable.ViewTransition_transitionDisable) {
        this.mDisabled = typedArray.getBoolean(k, this.mDisabled);
      } else if (k == R.styleable.ViewTransition_pathMotionArc) {
        this.mPathMotionArc = typedArray.getInt(k, this.mPathMotionArc);
      } else if (k == R.styleable.ViewTransition_duration) {
        this.mDuration = typedArray.getInt(k, this.mDuration);
      } else if (k == R.styleable.ViewTransition_upDuration) {
        this.mUpDuration = typedArray.getInt(k, this.mUpDuration);
      } else if (k == R.styleable.ViewTransition_viewTransitionMode) {
        this.mViewTransitionMode = typedArray.getInt(k, this.mViewTransitionMode);
      } else if (k == R.styleable.ViewTransition_motionInterpolator) {
        TypedValue typedValue = typedArray.peekValue(k);
        if (typedValue.type == 1) {
          k = typedArray.getResourceId(k, -1);
          this.mDefaultInterpolatorID = k;
          if (k != -1)
            this.mDefaultInterpolator = -2; 
        } else if (typedValue.type == 3) {
          String str = typedArray.getString(k);
          this.mDefaultInterpolatorString = str;
          if (str != null && str.indexOf("/") > 0) {
            this.mDefaultInterpolatorID = typedArray.getResourceId(k, -1);
            this.mDefaultInterpolator = -2;
          } else {
            this.mDefaultInterpolator = -1;
          } 
        } else {
          this.mDefaultInterpolator = typedArray.getInteger(k, this.mDefaultInterpolator);
        } 
      } else if (k == R.styleable.ViewTransition_setsTag) {
        this.mSetsTag = typedArray.getResourceId(k, this.mSetsTag);
      } else if (k == R.styleable.ViewTransition_clearsTag) {
        this.mClearsTag = typedArray.getResourceId(k, this.mClearsTag);
      } else if (k == R.styleable.ViewTransition_ifTagSet) {
        this.mIfTagSet = typedArray.getResourceId(k, this.mIfTagSet);
      } else if (k == R.styleable.ViewTransition_ifTagNotSet) {
        this.mIfTagNotSet = typedArray.getResourceId(k, this.mIfTagNotSet);
      } else if (k == R.styleable.ViewTransition_SharedValueId) {
        this.mSharedValueID = typedArray.getResourceId(k, this.mSharedValueID);
      } else if (k == R.styleable.ViewTransition_SharedValue) {
        this.mSharedValueTarget = typedArray.getInteger(k, this.mSharedValueTarget);
      } 
    } 
    typedArray.recycle();
  }
  
  private void updateTransition(MotionScene.Transition paramTransition, View paramView) {
    int i = this.mDuration;
    if (i != -1)
      paramTransition.setDuration(i); 
    paramTransition.setPathMotionArc(this.mPathMotionArc);
    paramTransition.setInterpolatorInfo(this.mDefaultInterpolator, this.mDefaultInterpolatorString, this.mDefaultInterpolatorID);
    i = paramView.getId();
    KeyFrames keyFrames = this.mKeyFrames;
    if (keyFrames != null) {
      ArrayList<Key> arrayList = keyFrames.getKeyFramesForView(-1);
      keyFrames = new KeyFrames();
      Iterator<Key> iterator = arrayList.iterator();
      while (iterator.hasNext())
        keyFrames.addKey(((Key)iterator.next()).clone().setViewId(i)); 
      paramTransition.addKeyFrame(keyFrames);
    } 
  }
  
  void applyIndependentTransition(ViewTransitionController paramViewTransitionController, MotionLayout paramMotionLayout, View paramView) {
    MotionController motionController = new MotionController(paramView);
    motionController.setBothStates(paramView);
    this.mKeyFrames.addAllFrames(motionController);
    motionController.setup(paramMotionLayout.getWidth(), paramMotionLayout.getHeight(), this.mDuration, System.nanoTime());
    new Animate(paramViewTransitionController, motionController, this.mDuration, this.mUpDuration, this.mOnStateTransition, getInterpolator(paramMotionLayout.getContext()), this.mSetsTag, this.mClearsTag);
  }
  
  void applyTransition(ViewTransitionController paramViewTransitionController, MotionLayout paramMotionLayout, int paramInt, ConstraintSet paramConstraintSet, View... paramVarArgs) {
    if (this.mDisabled)
      return; 
    int i = this.mViewTransitionMode;
    boolean bool = false;
    if (i == 2) {
      applyIndependentTransition(paramViewTransitionController, paramMotionLayout, paramVarArgs[0]);
      return;
    } 
    if (i == 1) {
      int[] arrayOfInt = paramMotionLayout.getConstraintSetIds();
      for (i = 0; i < arrayOfInt.length; i++) {
        int k = arrayOfInt[i];
        if (k != paramInt) {
          ConstraintSet constraintSet1 = paramMotionLayout.getConstraintSet(k);
          int m = paramVarArgs.length;
          for (k = 0; k < m; k++) {
            ConstraintSet.Constraint constraint1 = constraintSet1.getConstraint(paramVarArgs[k].getId());
            ConstraintSet.Constraint constraint2 = this.mConstraintDelta;
            if (constraint2 != null) {
              constraint2.applyDelta(constraint1);
              constraint1.mCustomConstraints.putAll(this.mConstraintDelta.mCustomConstraints);
            } 
          } 
        } 
      } 
    } 
    ConstraintSet constraintSet = new ConstraintSet();
    constraintSet.clone(paramConstraintSet);
    int j = paramVarArgs.length;
    for (i = 0; i < j; i++) {
      ConstraintSet.Constraint constraint1 = constraintSet.getConstraint(paramVarArgs[i].getId());
      ConstraintSet.Constraint constraint2 = this.mConstraintDelta;
      if (constraint2 != null) {
        constraint2.applyDelta(constraint1);
        constraint1.mCustomConstraints.putAll(this.mConstraintDelta.mCustomConstraints);
      } 
    } 
    paramMotionLayout.updateState(paramInt, constraintSet);
    paramMotionLayout.updateState(R.id.view_transition, paramConstraintSet);
    paramMotionLayout.setState(R.id.view_transition, -1, -1);
    MotionScene.Transition transition = new MotionScene.Transition(-1, paramMotionLayout.mScene, R.id.view_transition, paramInt);
    i = paramVarArgs.length;
    for (paramInt = bool; paramInt < i; paramInt++)
      updateTransition(transition, paramVarArgs[paramInt]); 
    paramMotionLayout.setTransition(transition);
    paramMotionLayout.transitionToEnd(new ViewTransition$$ExternalSyntheticLambda0(this, paramVarArgs));
  }
  
  boolean checkTags(View paramView) {
    int i = this.mIfTagSet;
    boolean bool2 = false;
    if (i == -1 || paramView.getTag(i) != null) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = this.mIfTagNotSet;
    if (j == -1 || paramView.getTag(j) == null) {
      j = 1;
    } else {
      j = 0;
    } 
    boolean bool1 = bool2;
    if (i != 0) {
      bool1 = bool2;
      if (j != 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  int getId() {
    return this.mId;
  }
  
  Interpolator getInterpolator(Context paramContext) {
    int i = this.mDefaultInterpolator;
    return (Interpolator)((i != -2) ? ((i != -1) ? ((i != 0) ? ((i != 1) ? ((i != 2) ? ((i != 4) ? ((i != 5) ? ((i != 6) ? null : new AnticipateInterpolator()) : new OvershootInterpolator()) : new BounceInterpolator()) : new DecelerateInterpolator()) : new AccelerateInterpolator()) : new AccelerateDecelerateInterpolator()) : new Interpolator() {
        public float getInterpolation(float param1Float) {
          return (float)easing.get(param1Float);
        }
      }) : AnimationUtils.loadInterpolator(paramContext, this.mDefaultInterpolatorID));
  }
  
  public int getSharedValue() {
    return this.mSharedValueTarget;
  }
  
  public int getSharedValueCurrent() {
    return this.mSharedValueCurrent;
  }
  
  public int getSharedValueID() {
    return this.mSharedValueID;
  }
  
  public int getStateTransition() {
    return this.mOnStateTransition;
  }
  
  boolean isEnabled() {
    return this.mDisabled ^ true;
  }
  
  boolean matchesView(View paramView) {
    if (paramView == null)
      return false; 
    if (this.mTargetId == -1 && this.mTargetString == null)
      return false; 
    if (!checkTags(paramView))
      return false; 
    if (paramView.getId() == this.mTargetId)
      return true; 
    if (this.mTargetString == null)
      return false; 
    if (paramView.getLayoutParams() instanceof ConstraintLayout.LayoutParams) {
      String str = ((ConstraintLayout.LayoutParams)paramView.getLayoutParams()).constraintTag;
      if (str != null && str.matches(this.mTargetString))
        return true; 
    } 
    return false;
  }
  
  void setEnabled(boolean paramBoolean) {
    this.mDisabled = paramBoolean ^ true;
  }
  
  void setId(int paramInt) {
    this.mId = paramInt;
  }
  
  public void setSharedValue(int paramInt) {
    this.mSharedValueTarget = paramInt;
  }
  
  public void setSharedValueCurrent(int paramInt) {
    this.mSharedValueCurrent = paramInt;
  }
  
  public void setSharedValueID(int paramInt) {
    this.mSharedValueID = paramInt;
  }
  
  public void setStateTransition(int paramInt) {
    this.mOnStateTransition = paramInt;
  }
  
  boolean supports(int paramInt) {
    int i = this.mOnStateTransition;
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1 = false;
    if (i == 1) {
      if (paramInt == 0)
        bool1 = true; 
      return bool1;
    } 
    if (i == 2) {
      bool1 = bool3;
      if (paramInt == 1)
        bool1 = true; 
      return bool1;
    } 
    bool1 = bool2;
    if (i == 3) {
      bool1 = bool2;
      if (paramInt == 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("ViewTransition(");
    stringBuilder.append(Debug.getName(this.mContext, this.mId));
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  static class Animate {
    boolean hold_at_100;
    
    KeyCache mCache;
    
    private final int mClearsTag;
    
    float mDpositionDt;
    
    int mDuration;
    
    Interpolator mInterpolator;
    
    long mLastRender;
    
    MotionController mMC;
    
    float mPosition;
    
    private final int mSetsTag;
    
    long mStart;
    
    Rect mTempRec;
    
    int mUpDuration;
    
    ViewTransitionController mVtController;
    
    boolean reverse;
    
    Animate(ViewTransitionController param1ViewTransitionController, MotionController param1MotionController, int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator, int param1Int4, int param1Int5) {
      float f;
      this.mCache = new KeyCache();
      this.reverse = false;
      this.mTempRec = new Rect();
      this.hold_at_100 = false;
      this.mVtController = param1ViewTransitionController;
      this.mMC = param1MotionController;
      this.mDuration = param1Int1;
      this.mUpDuration = param1Int2;
      long l = System.nanoTime();
      this.mStart = l;
      this.mLastRender = l;
      this.mVtController.addAnimation(this);
      this.mInterpolator = param1Interpolator;
      this.mSetsTag = param1Int4;
      this.mClearsTag = param1Int5;
      if (param1Int3 == 3)
        this.hold_at_100 = true; 
      if (param1Int1 == 0) {
        f = Float.MAX_VALUE;
      } else {
        f = 1.0F / param1Int1;
      } 
      this.mDpositionDt = f;
      mutate();
    }
    
    void mutate() {
      if (this.reverse) {
        mutateReverse();
        return;
      } 
      mutateForward();
    }
    
    void mutateForward() {
      long l1 = System.nanoTime();
      long l2 = this.mLastRender;
      this.mLastRender = l1;
      float f = this.mPosition;
      double d = (l1 - l2);
      Double.isNaN(d);
      f += (float)(d * 1.0E-6D) * this.mDpositionDt;
      this.mPosition = f;
      if (f >= 1.0F)
        this.mPosition = 1.0F; 
      Interpolator interpolator = this.mInterpolator;
      if (interpolator == null) {
        f = this.mPosition;
      } else {
        f = interpolator.getInterpolation(this.mPosition);
      } 
      MotionController motionController = this.mMC;
      boolean bool = motionController.interpolate(motionController.mView, f, l1, this.mCache);
      if (this.mPosition >= 1.0F) {
        if (this.mSetsTag != -1)
          this.mMC.getView().setTag(this.mSetsTag, Long.valueOf(System.nanoTime())); 
        if (this.mClearsTag != -1)
          this.mMC.getView().setTag(this.mClearsTag, null); 
        if (!this.hold_at_100)
          this.mVtController.removeAnimation(this); 
      } 
      if (this.mPosition < 1.0F || bool)
        this.mVtController.invalidate(); 
    }
    
    void mutateReverse() {
      long l1 = System.nanoTime();
      long l2 = this.mLastRender;
      this.mLastRender = l1;
      float f = this.mPosition;
      double d = (l1 - l2);
      Double.isNaN(d);
      f -= (float)(d * 1.0E-6D) * this.mDpositionDt;
      this.mPosition = f;
      if (f < 0.0F)
        this.mPosition = 0.0F; 
      Interpolator interpolator = this.mInterpolator;
      if (interpolator == null) {
        f = this.mPosition;
      } else {
        f = interpolator.getInterpolation(this.mPosition);
      } 
      MotionController motionController = this.mMC;
      boolean bool = motionController.interpolate(motionController.mView, f, l1, this.mCache);
      if (this.mPosition <= 0.0F) {
        if (this.mSetsTag != -1)
          this.mMC.getView().setTag(this.mSetsTag, Long.valueOf(System.nanoTime())); 
        if (this.mClearsTag != -1)
          this.mMC.getView().setTag(this.mClearsTag, null); 
        this.mVtController.removeAnimation(this);
      } 
      if (this.mPosition > 0.0F || bool)
        this.mVtController.invalidate(); 
    }
    
    public void reactTo(int param1Int, float param1Float1, float param1Float2) {
      if (param1Int != 1) {
        if (param1Int != 2)
          return; 
        this.mMC.getView().getHitRect(this.mTempRec);
        if (!this.mTempRec.contains((int)param1Float1, (int)param1Float2) && !this.reverse)
          reverse(true); 
        return;
      } 
      if (!this.reverse)
        reverse(true); 
    }
    
    void reverse(boolean param1Boolean) {
      this.reverse = param1Boolean;
      if (param1Boolean) {
        int i = this.mUpDuration;
        if (i != -1) {
          float f;
          if (i == 0) {
            f = Float.MAX_VALUE;
          } else {
            f = 1.0F / i;
          } 
          this.mDpositionDt = f;
        } 
      } 
      this.mVtController.invalidate();
      this.mLastRender = System.nanoTime();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\motion\widget\ViewTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */