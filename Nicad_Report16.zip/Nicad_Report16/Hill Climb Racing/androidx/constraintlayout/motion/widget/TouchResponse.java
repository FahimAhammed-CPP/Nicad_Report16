package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.R;
import androidx.core.widget.NestedScrollView;
import org.xmlpull.v1.XmlPullParser;

class TouchResponse {
  public static final int COMPLETE_MODE_CONTINUOUS_VELOCITY = 0;
  
  public static final int COMPLETE_MODE_SPRING = 1;
  
  private static final boolean DEBUG = false;
  
  private static final float EPSILON = 1.0E-7F;
  
  static final int FLAG_DISABLE_POST_SCROLL = 1;
  
  static final int FLAG_DISABLE_SCROLL = 2;
  
  static final int FLAG_SUPPORT_SCROLL_UP = 4;
  
  private static final int SEC_TO_MILLISECONDS = 1000;
  
  private static final int SIDE_BOTTOM = 3;
  
  private static final int SIDE_END = 6;
  
  private static final int SIDE_LEFT = 1;
  
  private static final int SIDE_MIDDLE = 4;
  
  private static final int SIDE_RIGHT = 2;
  
  private static final int SIDE_START = 5;
  
  private static final int SIDE_TOP = 0;
  
  private static final String TAG = "TouchResponse";
  
  private static final float[][] TOUCH_DIRECTION;
  
  private static final int TOUCH_DOWN = 1;
  
  private static final int TOUCH_END = 5;
  
  private static final int TOUCH_LEFT = 2;
  
  private static final int TOUCH_RIGHT = 3;
  
  private static final float[][] TOUCH_SIDES;
  
  private static final int TOUCH_START = 4;
  
  private static final int TOUCH_UP = 0;
  
  private float[] mAnchorDpDt = new float[2];
  
  private int mAutoCompleteMode = 0;
  
  private float mDragScale = 1.0F;
  
  private boolean mDragStarted = false;
  
  private float mDragThreshold = 10.0F;
  
  private int mFlags = 0;
  
  boolean mIsRotateMode = false;
  
  private float mLastTouchX;
  
  private float mLastTouchY;
  
  private int mLimitBoundsTo = -1;
  
  private float mMaxAcceleration = 1.2F;
  
  private float mMaxVelocity = 4.0F;
  
  private final MotionLayout mMotionLayout;
  
  private boolean mMoveWhenScrollAtTop = true;
  
  private int mOnTouchUp = 0;
  
  float mRotateCenterX = 0.5F;
  
  float mRotateCenterY = 0.5F;
  
  private int mRotationCenterId = -1;
  
  private int mSpringBoundary = 0;
  
  private float mSpringDamping = 10.0F;
  
  private float mSpringMass = 1.0F;
  
  private float mSpringStiffness = Float.NaN;
  
  private float mSpringStopThreshold = Float.NaN;
  
  private int[] mTempLoc = new int[2];
  
  private int mTouchAnchorId = -1;
  
  private int mTouchAnchorSide = 0;
  
  private float mTouchAnchorX = 0.5F;
  
  private float mTouchAnchorY = 0.5F;
  
  private float mTouchDirectionX = 0.0F;
  
  private float mTouchDirectionY = 1.0F;
  
  private int mTouchRegionId = -1;
  
  private int mTouchSide = 0;
  
  static {
    float[] arrayOfFloat1 = { 0.5F, 0.0F };
    float[] arrayOfFloat2 = { 0.5F, 0.5F };
    TOUCH_SIDES = new float[][] { arrayOfFloat1, { 0.0F, 0.5F }, { 1.0F, 0.5F }, { 0.5F, 1.0F }, arrayOfFloat2, { 0.0F, 0.5F }, { 1.0F, 0.5F } };
    arrayOfFloat1 = new float[] { 1.0F, 0.0F };
    TOUCH_DIRECTION = new float[][] { { 0.0F, -1.0F }, { 0.0F, 1.0F }, { -1.0F, 0.0F }, { 1.0F, 0.0F }, { -1.0F, 0.0F }, arrayOfFloat1 };
  }
  
  TouchResponse(Context paramContext, MotionLayout paramMotionLayout, XmlPullParser paramXmlPullParser) {
    this.mMotionLayout = paramMotionLayout;
    fillFromAttributeList(paramContext, Xml.asAttributeSet(paramXmlPullParser));
  }
  
  public TouchResponse(MotionLayout paramMotionLayout, OnSwipe paramOnSwipe) {
    this.mMotionLayout = paramMotionLayout;
    this.mTouchAnchorId = paramOnSwipe.getTouchAnchorId();
    int i = paramOnSwipe.getTouchAnchorSide();
    this.mTouchAnchorSide = i;
    if (i != -1) {
      float[] arrayOfFloat1 = TOUCH_SIDES[i];
      this.mTouchAnchorX = arrayOfFloat1[0];
      this.mTouchAnchorY = arrayOfFloat1[1];
    } 
    i = paramOnSwipe.getDragDirection();
    this.mTouchSide = i;
    float[][] arrayOfFloat = TOUCH_DIRECTION;
    if (i < arrayOfFloat.length) {
      float[] arrayOfFloat1 = arrayOfFloat[i];
      this.mTouchDirectionX = arrayOfFloat1[0];
      this.mTouchDirectionY = arrayOfFloat1[1];
    } else {
      this.mTouchDirectionY = Float.NaN;
      this.mTouchDirectionX = Float.NaN;
      this.mIsRotateMode = true;
    } 
    this.mMaxVelocity = paramOnSwipe.getMaxVelocity();
    this.mMaxAcceleration = paramOnSwipe.getMaxAcceleration();
    this.mMoveWhenScrollAtTop = paramOnSwipe.getMoveWhenScrollAtTop();
    this.mDragScale = paramOnSwipe.getDragScale();
    this.mDragThreshold = paramOnSwipe.getDragThreshold();
    this.mTouchRegionId = paramOnSwipe.getTouchRegionId();
    this.mOnTouchUp = paramOnSwipe.getOnTouchUp();
    this.mFlags = paramOnSwipe.getNestedScrollFlags();
    this.mLimitBoundsTo = paramOnSwipe.getLimitBoundsTo();
    this.mRotationCenterId = paramOnSwipe.getRotationCenterId();
    this.mSpringBoundary = paramOnSwipe.getSpringBoundary();
    this.mSpringDamping = paramOnSwipe.getSpringDamping();
    this.mSpringMass = paramOnSwipe.getSpringMass();
    this.mSpringStiffness = paramOnSwipe.getSpringStiffness();
    this.mSpringStopThreshold = paramOnSwipe.getSpringStopThreshold();
    this.mAutoCompleteMode = paramOnSwipe.getAutoCompleteMode();
  }
  
  private void fill(TypedArray paramTypedArray) {
    int j = paramTypedArray.getIndexCount();
    for (int i = 0; i < j; i++) {
      int k = paramTypedArray.getIndex(i);
      if (k == R.styleable.OnSwipe_touchAnchorId) {
        this.mTouchAnchorId = paramTypedArray.getResourceId(k, this.mTouchAnchorId);
      } else if (k == R.styleable.OnSwipe_touchAnchorSide) {
        k = paramTypedArray.getInt(k, this.mTouchAnchorSide);
        this.mTouchAnchorSide = k;
        float[] arrayOfFloat = TOUCH_SIDES[k];
        this.mTouchAnchorX = arrayOfFloat[0];
        this.mTouchAnchorY = arrayOfFloat[1];
      } else if (k == R.styleable.OnSwipe_dragDirection) {
        k = paramTypedArray.getInt(k, this.mTouchSide);
        this.mTouchSide = k;
        float[][] arrayOfFloat = TOUCH_DIRECTION;
        if (k < arrayOfFloat.length) {
          float[] arrayOfFloat1 = arrayOfFloat[k];
          this.mTouchDirectionX = arrayOfFloat1[0];
          this.mTouchDirectionY = arrayOfFloat1[1];
        } else {
          this.mTouchDirectionY = Float.NaN;
          this.mTouchDirectionX = Float.NaN;
          this.mIsRotateMode = true;
        } 
      } else if (k == R.styleable.OnSwipe_maxVelocity) {
        this.mMaxVelocity = paramTypedArray.getFloat(k, this.mMaxVelocity);
      } else if (k == R.styleable.OnSwipe_maxAcceleration) {
        this.mMaxAcceleration = paramTypedArray.getFloat(k, this.mMaxAcceleration);
      } else if (k == R.styleable.OnSwipe_moveWhenScrollAtTop) {
        this.mMoveWhenScrollAtTop = paramTypedArray.getBoolean(k, this.mMoveWhenScrollAtTop);
      } else if (k == R.styleable.OnSwipe_dragScale) {
        this.mDragScale = paramTypedArray.getFloat(k, this.mDragScale);
      } else if (k == R.styleable.OnSwipe_dragThreshold) {
        this.mDragThreshold = paramTypedArray.getFloat(k, this.mDragThreshold);
      } else if (k == R.styleable.OnSwipe_touchRegionId) {
        this.mTouchRegionId = paramTypedArray.getResourceId(k, this.mTouchRegionId);
      } else if (k == R.styleable.OnSwipe_onTouchUp) {
        this.mOnTouchUp = paramTypedArray.getInt(k, this.mOnTouchUp);
      } else if (k == R.styleable.OnSwipe_nestedScrollFlags) {
        this.mFlags = paramTypedArray.getInteger(k, 0);
      } else if (k == R.styleable.OnSwipe_limitBoundsTo) {
        this.mLimitBoundsTo = paramTypedArray.getResourceId(k, 0);
      } else if (k == R.styleable.OnSwipe_rotationCenterId) {
        this.mRotationCenterId = paramTypedArray.getResourceId(k, this.mRotationCenterId);
      } else if (k == R.styleable.OnSwipe_springDamping) {
        this.mSpringDamping = paramTypedArray.getFloat(k, this.mSpringDamping);
      } else if (k == R.styleable.OnSwipe_springMass) {
        this.mSpringMass = paramTypedArray.getFloat(k, this.mSpringMass);
      } else if (k == R.styleable.OnSwipe_springStiffness) {
        this.mSpringStiffness = paramTypedArray.getFloat(k, this.mSpringStiffness);
      } else if (k == R.styleable.OnSwipe_springStopThreshold) {
        this.mSpringStopThreshold = paramTypedArray.getFloat(k, this.mSpringStopThreshold);
      } else if (k == R.styleable.OnSwipe_springBoundary) {
        this.mSpringBoundary = paramTypedArray.getInt(k, this.mSpringBoundary);
      } else if (k == R.styleable.OnSwipe_autoCompleteMode) {
        this.mAutoCompleteMode = paramTypedArray.getInt(k, this.mAutoCompleteMode);
      } 
    } 
  }
  
  private void fillFromAttributeList(Context paramContext, AttributeSet paramAttributeSet) {
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.OnSwipe);
    fill(typedArray);
    typedArray.recycle();
  }
  
  float dot(float paramFloat1, float paramFloat2) {
    return paramFloat1 * this.mTouchDirectionX + paramFloat2 * this.mTouchDirectionY;
  }
  
  public int getAnchorId() {
    return this.mTouchAnchorId;
  }
  
  public int getAutoCompleteMode() {
    return this.mAutoCompleteMode;
  }
  
  public int getFlags() {
    return this.mFlags;
  }
  
  RectF getLimitBoundsTo(ViewGroup paramViewGroup, RectF paramRectF) {
    int i = this.mLimitBoundsTo;
    if (i == -1)
      return null; 
    View view = paramViewGroup.findViewById(i);
    if (view == null)
      return null; 
    paramRectF.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    return paramRectF;
  }
  
  int getLimitBoundsToId() {
    return this.mLimitBoundsTo;
  }
  
  float getMaxAcceleration() {
    return this.mMaxAcceleration;
  }
  
  public float getMaxVelocity() {
    return this.mMaxVelocity;
  }
  
  boolean getMoveWhenScrollAtTop() {
    return this.mMoveWhenScrollAtTop;
  }
  
  float getProgressDirection(float paramFloat1, float paramFloat2) {
    float f = this.mMotionLayout.getProgress();
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    f = this.mTouchDirectionX;
    if (f != 0.0F) {
      float[] arrayOfFloat1 = this.mAnchorDpDt;
      if (arrayOfFloat1[0] == 0.0F)
        arrayOfFloat1[0] = 1.0E-7F; 
      return paramFloat1 * f / arrayOfFloat1[0];
    } 
    float[] arrayOfFloat = this.mAnchorDpDt;
    if (arrayOfFloat[1] == 0.0F)
      arrayOfFloat[1] = 1.0E-7F; 
    return paramFloat2 * this.mTouchDirectionY / arrayOfFloat[1];
  }
  
  public int getSpringBoundary() {
    return this.mSpringBoundary;
  }
  
  public float getSpringDamping() {
    return this.mSpringDamping;
  }
  
  public float getSpringMass() {
    return this.mSpringMass;
  }
  
  public float getSpringStiffness() {
    return this.mSpringStiffness;
  }
  
  public float getSpringStopThreshold() {
    return this.mSpringStopThreshold;
  }
  
  RectF getTouchRegion(ViewGroup paramViewGroup, RectF paramRectF) {
    int i = this.mTouchRegionId;
    if (i == -1)
      return null; 
    View view = paramViewGroup.findViewById(i);
    if (view == null)
      return null; 
    paramRectF.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
    return paramRectF;
  }
  
  int getTouchRegionId() {
    return this.mTouchRegionId;
  }
  
  void processTouchEvent(MotionEvent paramMotionEvent, MotionLayout.MotionTracker paramMotionTracker, int paramInt, MotionScene paramMotionScene) {
    float[] arrayOfFloat;
    if (this.mIsRotateMode) {
      processTouchRotateEvent(paramMotionEvent, paramMotionTracker, paramInt, paramMotionScene);
      return;
    } 
    paramMotionTracker.addMovement(paramMotionEvent);
    paramInt = paramMotionEvent.getAction();
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2)
          return; 
        float f1 = paramMotionEvent.getRawY() - this.mLastTouchY;
        float f2 = paramMotionEvent.getRawX() - this.mLastTouchX;
        if (Math.abs(this.mTouchDirectionX * f2 + this.mTouchDirectionY * f1) > this.mDragThreshold || this.mDragStarted) {
          float f3 = this.mMotionLayout.getProgress();
          if (!this.mDragStarted) {
            this.mDragStarted = true;
            this.mMotionLayout.setProgress(f3);
          } 
          paramInt = this.mTouchAnchorId;
          if (paramInt != -1) {
            this.mMotionLayout.getAnchorDpDt(paramInt, f3, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
          } else {
            float f = Math.min(this.mMotionLayout.getWidth(), this.mMotionLayout.getHeight());
            float[] arrayOfFloat2 = this.mAnchorDpDt;
            arrayOfFloat2[1] = this.mTouchDirectionY * f;
            arrayOfFloat2[0] = f * this.mTouchDirectionX;
          } 
          float f4 = this.mTouchDirectionX;
          float[] arrayOfFloat1 = this.mAnchorDpDt;
          if (Math.abs((f4 * arrayOfFloat1[0] + this.mTouchDirectionY * arrayOfFloat1[1]) * this.mDragScale) < 0.01D) {
            arrayOfFloat1 = this.mAnchorDpDt;
            arrayOfFloat1[0] = 0.01F;
            arrayOfFloat1[1] = 0.01F;
          } 
          if (this.mTouchDirectionX != 0.0F) {
            f1 = f2 / this.mAnchorDpDt[0];
          } else {
            f1 /= this.mAnchorDpDt[1];
          } 
          f3 = Math.max(Math.min(f3 + f1, 1.0F), 0.0F);
          f1 = f3;
          if (this.mOnTouchUp == 6)
            f1 = Math.max(f3, 0.01F); 
          f3 = f1;
          if (this.mOnTouchUp == 7)
            f3 = Math.min(f1, 0.99F); 
          f1 = this.mMotionLayout.getProgress();
          if (f3 != f1) {
            if (f1 == 0.0F || f1 == 1.0F) {
              boolean bool;
              MotionLayout motionLayout = this.mMotionLayout;
              if (f1 == 0.0F) {
                bool = true;
              } else {
                bool = false;
              } 
              motionLayout.endTrigger(bool);
            } 
            this.mMotionLayout.setProgress(f3);
            paramMotionTracker.computeCurrentVelocity(1000);
            f1 = paramMotionTracker.getXVelocity();
            f3 = paramMotionTracker.getYVelocity();
            if (this.mTouchDirectionX != 0.0F) {
              f1 /= this.mAnchorDpDt[0];
            } else {
              f1 = f3 / this.mAnchorDpDt[1];
            } 
            this.mMotionLayout.mLastVelocity = f1;
          } else {
            this.mMotionLayout.mLastVelocity = 0.0F;
          } 
          this.mLastTouchX = paramMotionEvent.getRawX();
          this.mLastTouchY = paramMotionEvent.getRawY();
          return;
        } 
      } else {
        this.mDragStarted = false;
        paramMotionTracker.computeCurrentVelocity(1000);
        float f1 = paramMotionTracker.getXVelocity();
        float f2 = paramMotionTracker.getYVelocity();
        float f4 = this.mMotionLayout.getProgress();
        paramInt = this.mTouchAnchorId;
        if (paramInt != -1) {
          this.mMotionLayout.getAnchorDpDt(paramInt, f4, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
        } else {
          float f = Math.min(this.mMotionLayout.getWidth(), this.mMotionLayout.getHeight());
          float[] arrayOfFloat1 = this.mAnchorDpDt;
          arrayOfFloat1[1] = this.mTouchDirectionY * f;
          arrayOfFloat1[0] = f * this.mTouchDirectionX;
        } 
        float f3 = this.mTouchDirectionX;
        arrayOfFloat = this.mAnchorDpDt;
        float f5 = arrayOfFloat[0];
        float f6 = arrayOfFloat[1];
        if (f3 != 0.0F) {
          f1 /= f5;
        } else {
          f1 = f2 / f6;
        } 
        if (!Float.isNaN(f1)) {
          f2 = f1 / 3.0F + f4;
        } else {
          f2 = f4;
        } 
        if (f2 != 0.0F && f2 != 1.0F) {
          paramInt = this.mOnTouchUp;
          if (paramInt != 3) {
            if (f2 < 0.5D) {
              f3 = 0.0F;
            } else {
              f3 = 1.0F;
            } 
            f2 = f1;
            if (paramInt == 6) {
              f2 = f1;
              if (f4 + f1 < 0.0F)
                f2 = Math.abs(f1); 
              f3 = 1.0F;
            } 
            f1 = f2;
            if (this.mOnTouchUp == 7) {
              f1 = f2;
              if (f4 + f2 > 1.0F)
                f1 = -Math.abs(f2); 
              f3 = 0.0F;
            } 
            this.mMotionLayout.touchAnimateTo(this.mOnTouchUp, f3, f1);
            if (0.0F >= f4 || 1.0F <= f4) {
              this.mMotionLayout.setState(MotionLayout.TransitionState.FINISHED);
              return;
            } 
            return;
          } 
        } 
        if (0.0F >= f2 || 1.0F <= f2) {
          this.mMotionLayout.setState(MotionLayout.TransitionState.FINISHED);
          return;
        } 
      } 
    } else {
      this.mLastTouchX = arrayOfFloat.getRawX();
      this.mLastTouchY = arrayOfFloat.getRawY();
      this.mDragStarted = false;
    } 
  }
  
  void processTouchRotateEvent(MotionEvent paramMotionEvent, MotionLayout.MotionTracker paramMotionTracker, int paramInt, MotionScene paramMotionScene) {
    // Byte code:
    //   0: aload_2
    //   1: aload_1
    //   2: invokeinterface addMovement : (Landroid/view/MotionEvent;)V
    //   7: aload_1
    //   8: invokevirtual getAction : ()I
    //   11: istore_3
    //   12: iconst_0
    //   13: istore #18
    //   15: iload_3
    //   16: ifeq -> 1309
    //   19: iload_3
    //   20: iconst_1
    //   21: if_icmpeq -> 707
    //   24: iload_3
    //   25: iconst_2
    //   26: if_icmpeq -> 30
    //   29: return
    //   30: aload_1
    //   31: invokevirtual getRawY : ()F
    //   34: pop
    //   35: aload_1
    //   36: invokevirtual getRawX : ()F
    //   39: pop
    //   40: aload_0
    //   41: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   44: invokevirtual getWidth : ()I
    //   47: i2f
    //   48: fconst_2
    //   49: fdiv
    //   50: fstore #13
    //   52: aload_0
    //   53: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   56: invokevirtual getHeight : ()I
    //   59: i2f
    //   60: fconst_2
    //   61: fdiv
    //   62: fstore #14
    //   64: aload_0
    //   65: getfield mRotationCenterId : I
    //   68: istore_3
    //   69: iload_3
    //   70: iconst_m1
    //   71: if_icmpeq -> 158
    //   74: aload_0
    //   75: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   78: iload_3
    //   79: invokevirtual findViewById : (I)Landroid/view/View;
    //   82: astore #4
    //   84: aload_0
    //   85: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   88: aload_0
    //   89: getfield mTempLoc : [I
    //   92: invokevirtual getLocationOnScreen : ([I)V
    //   95: aload_0
    //   96: getfield mTempLoc : [I
    //   99: iconst_0
    //   100: iaload
    //   101: i2f
    //   102: fstore #11
    //   104: aload #4
    //   106: invokevirtual getLeft : ()I
    //   109: aload #4
    //   111: invokevirtual getRight : ()I
    //   114: iadd
    //   115: i2f
    //   116: fconst_2
    //   117: fdiv
    //   118: fstore #13
    //   120: aload_0
    //   121: getfield mTempLoc : [I
    //   124: iconst_1
    //   125: iaload
    //   126: i2f
    //   127: fstore #12
    //   129: aload #4
    //   131: invokevirtual getTop : ()I
    //   134: aload #4
    //   136: invokevirtual getBottom : ()I
    //   139: iadd
    //   140: i2f
    //   141: fconst_2
    //   142: fdiv
    //   143: fload #12
    //   145: fadd
    //   146: fstore #12
    //   148: fload #11
    //   150: fload #13
    //   152: fadd
    //   153: fstore #11
    //   155: goto -> 284
    //   158: aload_0
    //   159: getfield mTouchAnchorId : I
    //   162: istore_3
    //   163: fload #13
    //   165: fstore #11
    //   167: fload #14
    //   169: fstore #12
    //   171: iload_3
    //   172: iconst_m1
    //   173: if_icmpeq -> 284
    //   176: aload_0
    //   177: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   180: iload_3
    //   181: invokevirtual getMotionController : (I)Landroidx/constraintlayout/motion/widget/MotionController;
    //   184: astore #4
    //   186: aload_0
    //   187: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   190: aload #4
    //   192: invokevirtual getAnimateRelativeTo : ()I
    //   195: invokevirtual findViewById : (I)Landroid/view/View;
    //   198: astore #4
    //   200: aload #4
    //   202: ifnonnull -> 225
    //   205: ldc 'TouchResponse'
    //   207: ldc_w 'could not find view to animate to'
    //   210: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   213: pop
    //   214: fload #13
    //   216: fstore #11
    //   218: fload #14
    //   220: fstore #12
    //   222: goto -> 284
    //   225: aload_0
    //   226: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   229: aload_0
    //   230: getfield mTempLoc : [I
    //   233: invokevirtual getLocationOnScreen : ([I)V
    //   236: aload_0
    //   237: getfield mTempLoc : [I
    //   240: iconst_0
    //   241: iaload
    //   242: i2f
    //   243: aload #4
    //   245: invokevirtual getLeft : ()I
    //   248: aload #4
    //   250: invokevirtual getRight : ()I
    //   253: iadd
    //   254: i2f
    //   255: fconst_2
    //   256: fdiv
    //   257: fadd
    //   258: fstore #11
    //   260: aload_0
    //   261: getfield mTempLoc : [I
    //   264: iconst_1
    //   265: iaload
    //   266: i2f
    //   267: aload #4
    //   269: invokevirtual getTop : ()I
    //   272: aload #4
    //   274: invokevirtual getBottom : ()I
    //   277: iadd
    //   278: i2f
    //   279: fconst_2
    //   280: fdiv
    //   281: fadd
    //   282: fstore #12
    //   284: aload_1
    //   285: invokevirtual getRawX : ()F
    //   288: fstore #15
    //   290: aload_1
    //   291: invokevirtual getRawY : ()F
    //   294: fstore #16
    //   296: aload_1
    //   297: invokevirtual getRawY : ()F
    //   300: fload #12
    //   302: fsub
    //   303: f2d
    //   304: aload_1
    //   305: invokevirtual getRawX : ()F
    //   308: fload #11
    //   310: fsub
    //   311: f2d
    //   312: invokestatic atan2 : (DD)D
    //   315: dstore #5
    //   317: dload #5
    //   319: aload_0
    //   320: getfield mLastTouchY : F
    //   323: fload #12
    //   325: fsub
    //   326: f2d
    //   327: aload_0
    //   328: getfield mLastTouchX : F
    //   331: fload #11
    //   333: fsub
    //   334: f2d
    //   335: invokestatic atan2 : (DD)D
    //   338: dsub
    //   339: ldc2_w 180.0
    //   342: dmul
    //   343: ldc2_w 3.141592653589793
    //   346: ddiv
    //   347: d2f
    //   348: fstore #14
    //   350: fload #14
    //   352: ldc_w 330.0
    //   355: fcmpl
    //   356: ifle -> 370
    //   359: fload #14
    //   361: ldc_w 360.0
    //   364: fsub
    //   365: fstore #13
    //   367: goto -> 391
    //   370: fload #14
    //   372: fstore #13
    //   374: fload #14
    //   376: ldc_w -330.0
    //   379: fcmpg
    //   380: ifge -> 391
    //   383: fload #14
    //   385: ldc_w 360.0
    //   388: fadd
    //   389: fstore #13
    //   391: fload #13
    //   393: invokestatic abs : (F)F
    //   396: f2d
    //   397: ldc2_w 0.01
    //   400: dcmpl
    //   401: ifgt -> 411
    //   404: aload_0
    //   405: getfield mDragStarted : Z
    //   408: ifeq -> 1330
    //   411: aload_0
    //   412: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   415: invokevirtual getProgress : ()F
    //   418: fstore #14
    //   420: aload_0
    //   421: getfield mDragStarted : Z
    //   424: ifne -> 441
    //   427: aload_0
    //   428: iconst_1
    //   429: putfield mDragStarted : Z
    //   432: aload_0
    //   433: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   436: fload #14
    //   438: invokevirtual setProgress : (F)V
    //   441: aload_0
    //   442: getfield mTouchAnchorId : I
    //   445: istore_3
    //   446: iload_3
    //   447: iconst_m1
    //   448: if_icmpeq -> 495
    //   451: aload_0
    //   452: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   455: iload_3
    //   456: fload #14
    //   458: aload_0
    //   459: getfield mTouchAnchorX : F
    //   462: aload_0
    //   463: getfield mTouchAnchorY : F
    //   466: aload_0
    //   467: getfield mAnchorDpDt : [F
    //   470: invokevirtual getAnchorDpDt : (IFFF[F)V
    //   473: aload_0
    //   474: getfield mAnchorDpDt : [F
    //   477: astore #4
    //   479: aload #4
    //   481: iconst_1
    //   482: aload #4
    //   484: iconst_1
    //   485: faload
    //   486: f2d
    //   487: invokestatic toDegrees : (D)D
    //   490: d2f
    //   491: fastore
    //   492: goto -> 504
    //   495: aload_0
    //   496: getfield mAnchorDpDt : [F
    //   499: iconst_1
    //   500: ldc_w 360.0
    //   503: fastore
    //   504: fload #14
    //   506: fload #13
    //   508: aload_0
    //   509: getfield mDragScale : F
    //   512: fmul
    //   513: aload_0
    //   514: getfield mAnchorDpDt : [F
    //   517: iconst_1
    //   518: faload
    //   519: fdiv
    //   520: fadd
    //   521: fconst_1
    //   522: invokestatic min : (FF)F
    //   525: fconst_0
    //   526: invokestatic max : (FF)F
    //   529: fstore #13
    //   531: aload_0
    //   532: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   535: invokevirtual getProgress : ()F
    //   538: fstore #14
    //   540: fload #13
    //   542: fload #14
    //   544: fcmpl
    //   545: ifeq -> 682
    //   548: fload #14
    //   550: fconst_0
    //   551: fcmpl
    //   552: ifeq -> 562
    //   555: fload #14
    //   557: fconst_1
    //   558: fcmpl
    //   559: ifne -> 585
    //   562: aload_0
    //   563: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   566: astore #4
    //   568: fload #14
    //   570: fconst_0
    //   571: fcmpl
    //   572: ifne -> 578
    //   575: iconst_1
    //   576: istore #18
    //   578: aload #4
    //   580: iload #18
    //   582: invokevirtual endTrigger : (Z)V
    //   585: aload_0
    //   586: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   589: fload #13
    //   591: invokevirtual setProgress : (F)V
    //   594: aload_2
    //   595: sipush #1000
    //   598: invokeinterface computeCurrentVelocity : (I)V
    //   603: aload_2
    //   604: invokeinterface getXVelocity : ()F
    //   609: fstore #13
    //   611: aload_2
    //   612: invokeinterface getYVelocity : ()F
    //   617: f2d
    //   618: dstore #7
    //   620: fload #13
    //   622: f2d
    //   623: dstore #9
    //   625: dload #7
    //   627: dload #9
    //   629: invokestatic hypot : (DD)D
    //   632: dload #7
    //   634: dload #9
    //   636: invokestatic atan2 : (DD)D
    //   639: dload #5
    //   641: dsub
    //   642: invokestatic sin : (D)D
    //   645: dmul
    //   646: fload #15
    //   648: fload #11
    //   650: fsub
    //   651: f2d
    //   652: fload #16
    //   654: fload #12
    //   656: fsub
    //   657: f2d
    //   658: invokestatic hypot : (DD)D
    //   661: ddiv
    //   662: d2f
    //   663: fstore #11
    //   665: aload_0
    //   666: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   669: fload #11
    //   671: f2d
    //   672: invokestatic toDegrees : (D)D
    //   675: d2f
    //   676: putfield mLastVelocity : F
    //   679: goto -> 690
    //   682: aload_0
    //   683: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   686: fconst_0
    //   687: putfield mLastVelocity : F
    //   690: aload_0
    //   691: aload_1
    //   692: invokevirtual getRawX : ()F
    //   695: putfield mLastTouchX : F
    //   698: aload_0
    //   699: aload_1
    //   700: invokevirtual getRawY : ()F
    //   703: putfield mLastTouchY : F
    //   706: return
    //   707: aload_0
    //   708: iconst_0
    //   709: putfield mDragStarted : Z
    //   712: aload_2
    //   713: bipush #16
    //   715: invokeinterface computeCurrentVelocity : (I)V
    //   720: aload_2
    //   721: invokeinterface getXVelocity : ()F
    //   726: fstore #13
    //   728: aload_2
    //   729: invokeinterface getYVelocity : ()F
    //   734: fstore #14
    //   736: aload_0
    //   737: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   740: invokevirtual getProgress : ()F
    //   743: fstore #15
    //   745: aload_0
    //   746: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   749: invokevirtual getWidth : ()I
    //   752: i2f
    //   753: fconst_2
    //   754: fdiv
    //   755: fstore #11
    //   757: aload_0
    //   758: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   761: invokevirtual getHeight : ()I
    //   764: i2f
    //   765: fconst_2
    //   766: fdiv
    //   767: fstore #12
    //   769: aload_0
    //   770: getfield mRotationCenterId : I
    //   773: istore_3
    //   774: iload_3
    //   775: iconst_m1
    //   776: if_icmpeq -> 856
    //   779: aload_0
    //   780: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   783: iload_3
    //   784: invokevirtual findViewById : (I)Landroid/view/View;
    //   787: astore_2
    //   788: aload_0
    //   789: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   792: aload_0
    //   793: getfield mTempLoc : [I
    //   796: invokevirtual getLocationOnScreen : ([I)V
    //   799: aload_0
    //   800: getfield mTempLoc : [I
    //   803: iconst_0
    //   804: iaload
    //   805: i2f
    //   806: aload_2
    //   807: invokevirtual getLeft : ()I
    //   810: aload_2
    //   811: invokevirtual getRight : ()I
    //   814: iadd
    //   815: i2f
    //   816: fconst_2
    //   817: fdiv
    //   818: fadd
    //   819: fstore #11
    //   821: aload_0
    //   822: getfield mTempLoc : [I
    //   825: iconst_1
    //   826: iaload
    //   827: i2f
    //   828: fstore #12
    //   830: aload_2
    //   831: invokevirtual getTop : ()I
    //   834: istore #17
    //   836: aload_2
    //   837: invokevirtual getBottom : ()I
    //   840: istore_3
    //   841: fload #12
    //   843: iload #17
    //   845: iload_3
    //   846: iadd
    //   847: i2f
    //   848: fconst_2
    //   849: fdiv
    //   850: fadd
    //   851: fstore #12
    //   853: goto -> 943
    //   856: aload_0
    //   857: getfield mTouchAnchorId : I
    //   860: istore_3
    //   861: iload_3
    //   862: iconst_m1
    //   863: if_icmpeq -> 943
    //   866: aload_0
    //   867: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   870: iload_3
    //   871: invokevirtual getMotionController : (I)Landroidx/constraintlayout/motion/widget/MotionController;
    //   874: astore_2
    //   875: aload_0
    //   876: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   879: aload_2
    //   880: invokevirtual getAnimateRelativeTo : ()I
    //   883: invokevirtual findViewById : (I)Landroid/view/View;
    //   886: astore_2
    //   887: aload_0
    //   888: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   891: aload_0
    //   892: getfield mTempLoc : [I
    //   895: invokevirtual getLocationOnScreen : ([I)V
    //   898: aload_0
    //   899: getfield mTempLoc : [I
    //   902: iconst_0
    //   903: iaload
    //   904: i2f
    //   905: aload_2
    //   906: invokevirtual getLeft : ()I
    //   909: aload_2
    //   910: invokevirtual getRight : ()I
    //   913: iadd
    //   914: i2f
    //   915: fconst_2
    //   916: fdiv
    //   917: fadd
    //   918: fstore #11
    //   920: aload_0
    //   921: getfield mTempLoc : [I
    //   924: iconst_1
    //   925: iaload
    //   926: i2f
    //   927: fstore #12
    //   929: aload_2
    //   930: invokevirtual getTop : ()I
    //   933: istore #17
    //   935: aload_2
    //   936: invokevirtual getBottom : ()I
    //   939: istore_3
    //   940: goto -> 841
    //   943: aload_1
    //   944: invokevirtual getRawX : ()F
    //   947: fload #11
    //   949: fsub
    //   950: fstore #11
    //   952: aload_1
    //   953: invokevirtual getRawY : ()F
    //   956: fload #12
    //   958: fsub
    //   959: fstore #12
    //   961: fload #12
    //   963: f2d
    //   964: fload #11
    //   966: f2d
    //   967: invokestatic atan2 : (DD)D
    //   970: invokestatic toDegrees : (D)D
    //   973: dstore #5
    //   975: aload_0
    //   976: getfield mTouchAnchorId : I
    //   979: istore_3
    //   980: iload_3
    //   981: iconst_m1
    //   982: if_icmpeq -> 1026
    //   985: aload_0
    //   986: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   989: iload_3
    //   990: fload #15
    //   992: aload_0
    //   993: getfield mTouchAnchorX : F
    //   996: aload_0
    //   997: getfield mTouchAnchorY : F
    //   1000: aload_0
    //   1001: getfield mAnchorDpDt : [F
    //   1004: invokevirtual getAnchorDpDt : (IFFF[F)V
    //   1007: aload_0
    //   1008: getfield mAnchorDpDt : [F
    //   1011: astore_1
    //   1012: aload_1
    //   1013: iconst_1
    //   1014: aload_1
    //   1015: iconst_1
    //   1016: faload
    //   1017: f2d
    //   1018: invokestatic toDegrees : (D)D
    //   1021: d2f
    //   1022: fastore
    //   1023: goto -> 1035
    //   1026: aload_0
    //   1027: getfield mAnchorDpDt : [F
    //   1030: iconst_1
    //   1031: ldc_w 360.0
    //   1034: fastore
    //   1035: fload #14
    //   1037: fload #12
    //   1039: fadd
    //   1040: f2d
    //   1041: fload #13
    //   1043: fload #11
    //   1045: fadd
    //   1046: f2d
    //   1047: invokestatic atan2 : (DD)D
    //   1050: invokestatic toDegrees : (D)D
    //   1053: dload #5
    //   1055: dsub
    //   1056: d2f
    //   1057: ldc_w 62.5
    //   1060: fmul
    //   1061: fstore #12
    //   1063: fload #12
    //   1065: invokestatic isNaN : (F)Z
    //   1068: ifne -> 1097
    //   1071: fload #12
    //   1073: ldc_w 3.0
    //   1076: fmul
    //   1077: aload_0
    //   1078: getfield mDragScale : F
    //   1081: fmul
    //   1082: aload_0
    //   1083: getfield mAnchorDpDt : [F
    //   1086: iconst_1
    //   1087: faload
    //   1088: fdiv
    //   1089: fload #15
    //   1091: fadd
    //   1092: fstore #11
    //   1094: goto -> 1101
    //   1097: fload #15
    //   1099: fstore #11
    //   1101: fload #11
    //   1103: fconst_0
    //   1104: fcmpl
    //   1105: ifeq -> 1284
    //   1108: fload #11
    //   1110: fconst_1
    //   1111: fcmpl
    //   1112: ifeq -> 1284
    //   1115: aload_0
    //   1116: getfield mOnTouchUp : I
    //   1119: istore_3
    //   1120: iload_3
    //   1121: iconst_3
    //   1122: if_icmpeq -> 1284
    //   1125: fload #12
    //   1127: aload_0
    //   1128: getfield mDragScale : F
    //   1131: fmul
    //   1132: aload_0
    //   1133: getfield mAnchorDpDt : [F
    //   1136: iconst_1
    //   1137: faload
    //   1138: fdiv
    //   1139: fstore #13
    //   1141: fload #11
    //   1143: f2d
    //   1144: ldc2_w 0.5
    //   1147: dcmpg
    //   1148: ifge -> 1157
    //   1151: fconst_0
    //   1152: fstore #12
    //   1154: goto -> 1160
    //   1157: fconst_1
    //   1158: fstore #12
    //   1160: fload #13
    //   1162: fstore #11
    //   1164: iload_3
    //   1165: bipush #6
    //   1167: if_icmpne -> 1194
    //   1170: fload #13
    //   1172: fstore #11
    //   1174: fload #15
    //   1176: fload #13
    //   1178: fadd
    //   1179: fconst_0
    //   1180: fcmpg
    //   1181: ifge -> 1191
    //   1184: fload #13
    //   1186: invokestatic abs : (F)F
    //   1189: fstore #11
    //   1191: fconst_1
    //   1192: fstore #12
    //   1194: fload #11
    //   1196: fstore #13
    //   1198: fload #12
    //   1200: fstore #14
    //   1202: aload_0
    //   1203: getfield mOnTouchUp : I
    //   1206: bipush #7
    //   1208: if_icmpne -> 1240
    //   1211: fload #11
    //   1213: fstore #12
    //   1215: fload #15
    //   1217: fload #11
    //   1219: fadd
    //   1220: fconst_1
    //   1221: fcmpl
    //   1222: ifle -> 1233
    //   1225: fload #11
    //   1227: invokestatic abs : (F)F
    //   1230: fneg
    //   1231: fstore #12
    //   1233: fconst_0
    //   1234: fstore #14
    //   1236: fload #12
    //   1238: fstore #13
    //   1240: aload_0
    //   1241: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1244: aload_0
    //   1245: getfield mOnTouchUp : I
    //   1248: fload #14
    //   1250: fload #13
    //   1252: ldc_w 3.0
    //   1255: fmul
    //   1256: invokevirtual touchAnimateTo : (IFF)V
    //   1259: fconst_0
    //   1260: fload #15
    //   1262: fcmpl
    //   1263: ifge -> 1273
    //   1266: fconst_1
    //   1267: fload #15
    //   1269: fcmpg
    //   1270: ifgt -> 1330
    //   1273: aload_0
    //   1274: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1277: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1280: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1283: return
    //   1284: fconst_0
    //   1285: fload #11
    //   1287: fcmpl
    //   1288: ifge -> 1298
    //   1291: fconst_1
    //   1292: fload #11
    //   1294: fcmpg
    //   1295: ifgt -> 1330
    //   1298: aload_0
    //   1299: getfield mMotionLayout : Landroidx/constraintlayout/motion/widget/MotionLayout;
    //   1302: getstatic androidx/constraintlayout/motion/widget/MotionLayout$TransitionState.FINISHED : Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;
    //   1305: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/MotionLayout$TransitionState;)V
    //   1308: return
    //   1309: aload_0
    //   1310: aload_1
    //   1311: invokevirtual getRawX : ()F
    //   1314: putfield mLastTouchX : F
    //   1317: aload_0
    //   1318: aload_1
    //   1319: invokevirtual getRawY : ()F
    //   1322: putfield mLastTouchY : F
    //   1325: aload_0
    //   1326: iconst_0
    //   1327: putfield mDragStarted : Z
    //   1330: return
  }
  
  void scrollMove(float paramFloat1, float paramFloat2) {
    float f1 = this.mMotionLayout.getProgress();
    if (!this.mDragStarted) {
      this.mDragStarted = true;
      this.mMotionLayout.setProgress(f1);
    } 
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f1, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    float f2 = this.mTouchDirectionX;
    float[] arrayOfFloat = this.mAnchorDpDt;
    if (Math.abs(f2 * arrayOfFloat[0] + this.mTouchDirectionY * arrayOfFloat[1]) < 0.01D) {
      arrayOfFloat = this.mAnchorDpDt;
      arrayOfFloat[0] = 0.01F;
      arrayOfFloat[1] = 0.01F;
    } 
    f2 = this.mTouchDirectionX;
    if (f2 != 0.0F) {
      paramFloat1 = paramFloat1 * f2 / this.mAnchorDpDt[0];
    } else {
      paramFloat1 = paramFloat2 * this.mTouchDirectionY / this.mAnchorDpDt[1];
    } 
    paramFloat1 = Math.max(Math.min(f1 + paramFloat1, 1.0F), 0.0F);
    if (paramFloat1 != this.mMotionLayout.getProgress())
      this.mMotionLayout.setProgress(paramFloat1); 
  }
  
  void scrollUp(float paramFloat1, float paramFloat2) {
    boolean bool = false;
    this.mDragStarted = false;
    float f2 = this.mMotionLayout.getProgress();
    this.mMotionLayout.getAnchorDpDt(this.mTouchAnchorId, f2, this.mTouchAnchorX, this.mTouchAnchorY, this.mAnchorDpDt);
    float f3 = this.mTouchDirectionX;
    float[] arrayOfFloat = this.mAnchorDpDt;
    float f4 = arrayOfFloat[0];
    float f5 = this.mTouchDirectionY;
    float f6 = arrayOfFloat[1];
    float f1 = 0.0F;
    if (f3 != 0.0F) {
      paramFloat1 = paramFloat1 * f3 / f4;
    } else {
      paramFloat1 = paramFloat2 * f5 / f6;
    } 
    paramFloat2 = f2;
    if (!Float.isNaN(paramFloat1))
      paramFloat2 = f2 + paramFloat1 / 3.0F; 
    if (paramFloat2 != 0.0F) {
      boolean bool1;
      if (paramFloat2 != 1.0F) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      int i = this.mOnTouchUp;
      if (i != 3)
        bool = true; 
      if ((bool & bool1) != 0) {
        MotionLayout motionLayout = this.mMotionLayout;
        if (paramFloat2 < 0.5D) {
          paramFloat2 = f1;
        } else {
          paramFloat2 = 1.0F;
        } 
        motionLayout.touchAnimateTo(i, paramFloat2, paramFloat1);
      } 
    } 
  }
  
  public void setAnchorId(int paramInt) {
    this.mTouchAnchorId = paramInt;
  }
  
  void setAutoCompleteMode(int paramInt) {
    this.mAutoCompleteMode = paramInt;
  }
  
  void setDown(float paramFloat1, float paramFloat2) {
    this.mLastTouchX = paramFloat1;
    this.mLastTouchY = paramFloat2;
  }
  
  public void setMaxAcceleration(float paramFloat) {
    this.mMaxAcceleration = paramFloat;
  }
  
  public void setMaxVelocity(float paramFloat) {
    this.mMaxVelocity = paramFloat;
  }
  
  public void setRTL(boolean paramBoolean) {
    if (paramBoolean) {
      float[][] arrayOfFloat3 = TOUCH_DIRECTION;
      arrayOfFloat3[4] = arrayOfFloat3[3];
      arrayOfFloat3[5] = arrayOfFloat3[2];
      arrayOfFloat3 = TOUCH_SIDES;
      arrayOfFloat3[5] = arrayOfFloat3[2];
      arrayOfFloat3[6] = arrayOfFloat3[1];
    } else {
      float[][] arrayOfFloat3 = TOUCH_DIRECTION;
      arrayOfFloat3[4] = arrayOfFloat3[2];
      arrayOfFloat3[5] = arrayOfFloat3[3];
      arrayOfFloat3 = TOUCH_SIDES;
      arrayOfFloat3[5] = arrayOfFloat3[1];
      arrayOfFloat3[6] = arrayOfFloat3[2];
    } 
    float[] arrayOfFloat2 = TOUCH_SIDES[this.mTouchAnchorSide];
    this.mTouchAnchorX = arrayOfFloat2[0];
    this.mTouchAnchorY = arrayOfFloat2[1];
    int i = this.mTouchSide;
    float[][] arrayOfFloat = TOUCH_DIRECTION;
    if (i >= arrayOfFloat.length)
      return; 
    float[] arrayOfFloat1 = arrayOfFloat[i];
    this.mTouchDirectionX = arrayOfFloat1[0];
    this.mTouchDirectionY = arrayOfFloat1[1];
  }
  
  public void setTouchAnchorLocation(float paramFloat1, float paramFloat2) {
    this.mTouchAnchorX = paramFloat1;
    this.mTouchAnchorY = paramFloat2;
  }
  
  public void setTouchUpMode(int paramInt) {
    this.mOnTouchUp = paramInt;
  }
  
  void setUpTouchEvent(float paramFloat1, float paramFloat2) {
    this.mLastTouchX = paramFloat1;
    this.mLastTouchY = paramFloat2;
    this.mDragStarted = false;
  }
  
  void setupTouch() {
    NestedScrollView nestedScrollView;
    int i = this.mTouchAnchorId;
    if (i != -1) {
      View view = this.mMotionLayout.findViewById(i);
      nestedScrollView = (NestedScrollView)view;
      if (view == null) {
        StringBuilder stringBuilder = new StringBuilder("cannot find TouchAnchorId @id/");
        stringBuilder.append(Debug.getName(this.mMotionLayout.getContext(), this.mTouchAnchorId));
        Log.e("TouchResponse", stringBuilder.toString());
        View view1 = view;
      } 
    } else {
      nestedScrollView = null;
    } 
    if (nestedScrollView instanceof NestedScrollView) {
      nestedScrollView = nestedScrollView;
      nestedScrollView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              return false;
            }
          });
      nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            public void onScrollChange(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
          });
    } 
  }
  
  public String toString() {
    if (Float.isNaN(this.mTouchDirectionX))
      return "rotation"; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.mTouchDirectionX);
    stringBuilder.append(" , ");
    stringBuilder.append(this.mTouchDirectionY);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\motion\widget\TouchResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */