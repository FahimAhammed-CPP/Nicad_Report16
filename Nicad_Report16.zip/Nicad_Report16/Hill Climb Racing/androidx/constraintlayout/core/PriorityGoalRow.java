package androidx.constraintlayout.core;

import java.util.Arrays;
import java.util.Comparator;

public class PriorityGoalRow extends ArrayRow {
  private static final boolean DEBUG = false;
  
  static final int NOT_FOUND = -1;
  
  private static final float epsilon = 1.0E-4F;
  
  private int TABLE_SIZE = 128;
  
  GoalVariableAccessor accessor = new GoalVariableAccessor(this);
  
  private SolverVariable[] arrayGoals = new SolverVariable[128];
  
  Cache mCache;
  
  private int numGoals = 0;
  
  private SolverVariable[] sortArray = new SolverVariable[128];
  
  public PriorityGoalRow(Cache paramCache) {
    super(paramCache);
    this.mCache = paramCache;
  }
  
  private final void addToGoal(SolverVariable paramSolverVariable) {
    int i = this.numGoals;
    SolverVariable[] arrayOfSolverVariable = this.arrayGoals;
    if (i + 1 > arrayOfSolverVariable.length) {
      arrayOfSolverVariable = Arrays.<SolverVariable>copyOf(arrayOfSolverVariable, arrayOfSolverVariable.length * 2);
      this.arrayGoals = arrayOfSolverVariable;
      this.sortArray = Arrays.<SolverVariable>copyOf(arrayOfSolverVariable, arrayOfSolverVariable.length * 2);
    } 
    arrayOfSolverVariable = this.arrayGoals;
    i = this.numGoals;
    arrayOfSolverVariable[i] = paramSolverVariable;
    this.numGoals = ++i;
    if (i > 1 && (arrayOfSolverVariable[i - 1]).id > paramSolverVariable.id) {
      boolean bool = false;
      i = 0;
      while (true) {
        int j = this.numGoals;
        if (i < j) {
          this.sortArray[i] = this.arrayGoals[i];
          i++;
          continue;
        } 
        Arrays.sort(this.sortArray, 0, j, new Comparator<SolverVariable>() {
              public int compare(SolverVariable param1SolverVariable1, SolverVariable param1SolverVariable2) {
                return param1SolverVariable1.id - param1SolverVariable2.id;
              }
            });
        for (i = bool; i < this.numGoals; i++)
          this.arrayGoals[i] = this.sortArray[i]; 
        break;
      } 
    } 
    paramSolverVariable.inGoal = true;
    paramSolverVariable.addToRow(this);
  }
  
  private final void removeGoal(SolverVariable paramSolverVariable) {
    for (int i = 0; i < this.numGoals; i++) {
      if (this.arrayGoals[i] == paramSolverVariable)
        while (true) {
          int j = this.numGoals;
          if (i < j - 1) {
            SolverVariable[] arrayOfSolverVariable = this.arrayGoals;
            j = i + 1;
            arrayOfSolverVariable[i] = arrayOfSolverVariable[j];
            i = j;
            continue;
          } 
          this.numGoals = j - 1;
          paramSolverVariable.inGoal = false;
          return;
        }  
    } 
  }
  
  public void addError(SolverVariable paramSolverVariable) {
    this.accessor.init(paramSolverVariable);
    this.accessor.reset();
    paramSolverVariable.goalStrengthVector[paramSolverVariable.strength] = 1.0F;
    addToGoal(paramSolverVariable);
  }
  
  public void clear() {
    this.numGoals = 0;
    this.constantValue = 0.0F;
  }
  
  public SolverVariable getPivotCandidate(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: iconst_m1
    //   3: istore #4
    //   5: iload_3
    //   6: aload_0
    //   7: getfield numGoals : I
    //   10: if_icmpge -> 102
    //   13: aload_0
    //   14: getfield arrayGoals : [Landroidx/constraintlayout/core/SolverVariable;
    //   17: iload_3
    //   18: aaload
    //   19: astore_1
    //   20: aload_2
    //   21: aload_1
    //   22: getfield id : I
    //   25: baload
    //   26: ifeq -> 36
    //   29: iload #4
    //   31: istore #5
    //   33: goto -> 91
    //   36: aload_0
    //   37: getfield accessor : Landroidx/constraintlayout/core/PriorityGoalRow$GoalVariableAccessor;
    //   40: aload_1
    //   41: invokevirtual init : (Landroidx/constraintlayout/core/SolverVariable;)V
    //   44: iload #4
    //   46: iconst_m1
    //   47: if_icmpne -> 67
    //   50: iload #4
    //   52: istore #5
    //   54: aload_0
    //   55: getfield accessor : Landroidx/constraintlayout/core/PriorityGoalRow$GoalVariableAccessor;
    //   58: invokevirtual isNegative : ()Z
    //   61: ifeq -> 91
    //   64: goto -> 88
    //   67: iload #4
    //   69: istore #5
    //   71: aload_0
    //   72: getfield accessor : Landroidx/constraintlayout/core/PriorityGoalRow$GoalVariableAccessor;
    //   75: aload_0
    //   76: getfield arrayGoals : [Landroidx/constraintlayout/core/SolverVariable;
    //   79: iload #4
    //   81: aaload
    //   82: invokevirtual isSmallerThan : (Landroidx/constraintlayout/core/SolverVariable;)Z
    //   85: ifeq -> 91
    //   88: iload_3
    //   89: istore #5
    //   91: iload_3
    //   92: iconst_1
    //   93: iadd
    //   94: istore_3
    //   95: iload #5
    //   97: istore #4
    //   99: goto -> 5
    //   102: iload #4
    //   104: iconst_m1
    //   105: if_icmpne -> 110
    //   108: aconst_null
    //   109: areturn
    //   110: aload_0
    //   111: getfield arrayGoals : [Landroidx/constraintlayout/core/SolverVariable;
    //   114: iload #4
    //   116: aaload
    //   117: areturn
  }
  
  public boolean isEmpty() {
    return (this.numGoals == 0);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(" goal -> (");
    stringBuilder.append(this.constantValue);
    stringBuilder.append(") : ");
    String str = stringBuilder.toString();
    for (int i = 0; i < this.numGoals; i++) {
      SolverVariable solverVariable = this.arrayGoals[i];
      this.accessor.init(solverVariable);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(this.accessor);
      stringBuilder1.append(" ");
      str = stringBuilder1.toString();
    } 
    return str;
  }
  
  public void updateFromRow(LinearSystem paramLinearSystem, ArrayRow paramArrayRow, boolean paramBoolean) {
    SolverVariable solverVariable = paramArrayRow.variable;
    if (solverVariable == null)
      return; 
    ArrayRow.ArrayRowVariables arrayRowVariables = paramArrayRow.variables;
    int j = arrayRowVariables.getCurrentSize();
    int i;
    for (i = 0; i < j; i++) {
      SolverVariable solverVariable1 = arrayRowVariables.getVariable(i);
      float f = arrayRowVariables.getVariableValue(i);
      this.accessor.init(solverVariable1);
      if (this.accessor.addToGoal(solverVariable, f))
        addToGoal(solverVariable1); 
      this.constantValue += paramArrayRow.constantValue * f;
    } 
    removeGoal(solverVariable);
  }
  
  class GoalVariableAccessor {
    PriorityGoalRow row;
    
    SolverVariable variable;
    
    public GoalVariableAccessor(PriorityGoalRow param1PriorityGoalRow1) {
      this.row = param1PriorityGoalRow1;
    }
    
    public void add(SolverVariable param1SolverVariable) {
      for (int i = 0; i < 9; i++) {
        float[] arrayOfFloat = this.variable.goalStrengthVector;
        arrayOfFloat[i] = arrayOfFloat[i] + param1SolverVariable.goalStrengthVector[i];
        if (Math.abs(this.variable.goalStrengthVector[i]) < 1.0E-4F)
          this.variable.goalStrengthVector[i] = 0.0F; 
      } 
    }
    
    public boolean addToGoal(SolverVariable param1SolverVariable, float param1Float) {
      boolean bool1 = this.variable.inGoal;
      boolean bool = true;
      int i = 0;
      if (bool1) {
        for (i = 0; i < 9; i++) {
          float[] arrayOfFloat = this.variable.goalStrengthVector;
          arrayOfFloat[i] = arrayOfFloat[i] + param1SolverVariable.goalStrengthVector[i] * param1Float;
          if (Math.abs(this.variable.goalStrengthVector[i]) < 1.0E-4F) {
            this.variable.goalStrengthVector[i] = 0.0F;
          } else {
            bool = false;
          } 
        } 
        if (bool)
          PriorityGoalRow.this.removeGoal(this.variable); 
        return false;
      } 
      while (i < 9) {
        float f = param1SolverVariable.goalStrengthVector[i];
        if (f != 0.0F) {
          float f1 = f * param1Float;
          f = f1;
          if (Math.abs(f1) < 1.0E-4F)
            f = 0.0F; 
          this.variable.goalStrengthVector[i] = f;
        } else {
          this.variable.goalStrengthVector[i] = 0.0F;
        } 
        i++;
      } 
      return true;
    }
    
    public void init(SolverVariable param1SolverVariable) {
      this.variable = param1SolverVariable;
    }
    
    public final boolean isNegative() {
      for (int i = 8; i >= 0; i--) {
        float f = this.variable.goalStrengthVector[i];
        if (f > 0.0F)
          return false; 
        if (f < 0.0F)
          return true; 
      } 
      return false;
    }
    
    public final boolean isNull() {
      for (int i = 0; i < 9; i++) {
        if (this.variable.goalStrengthVector[i] != 0.0F)
          return false; 
      } 
      return true;
    }
    
    public final boolean isSmallerThan(SolverVariable param1SolverVariable) {
      int i = 8;
      while (i >= 0) {
        float f1 = param1SolverVariable.goalStrengthVector[i];
        float f2 = this.variable.goalStrengthVector[i];
        if (f2 == f1) {
          i--;
          continue;
        } 
        if (f2 < f1)
          return true; 
      } 
      return false;
    }
    
    public void reset() {
      Arrays.fill(this.variable.goalStrengthVector, 0.0F);
    }
    
    public String toString() {
      StringBuilder stringBuilder2;
      SolverVariable solverVariable = this.variable;
      String str1 = "[ ";
      String str2 = str1;
      if (solverVariable != null) {
        int i = 0;
        while (true) {
          str2 = str1;
          if (i < 9) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append(str1);
            stringBuilder2.append(this.variable.goalStrengthVector[i]);
            stringBuilder2.append(" ");
            str1 = stringBuilder2.toString();
            i++;
            continue;
          } 
          break;
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append((String)stringBuilder2);
      stringBuilder1.append("] ");
      stringBuilder1.append(this.variable);
      return stringBuilder1.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\PriorityGoalRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */