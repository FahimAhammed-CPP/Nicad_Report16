package androidx.constraintlayout.core.motion;

import androidx.constraintlayout.core.motion.key.MotionKeyPosition;
import androidx.constraintlayout.core.motion.utils.Easing;
import java.util.HashMap;

public class MotionPaths implements Comparable<MotionPaths> {
  public static final int CARTESIAN = 0;
  
  public static final boolean DEBUG = false;
  
  static final int OFF_HEIGHT = 4;
  
  static final int OFF_PATH_ROTATE = 5;
  
  static final int OFF_POSITION = 0;
  
  static final int OFF_WIDTH = 3;
  
  static final int OFF_X = 1;
  
  static final int OFF_Y = 2;
  
  public static final boolean OLD_WAY = false;
  
  public static final int PERPENDICULAR = 1;
  
  public static final int SCREEN = 2;
  
  public static final String TAG = "MotionPaths";
  
  static String[] names = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  HashMap<String, CustomVariable> customAttributes = new HashMap<String, CustomVariable>();
  
  float height;
  
  int mAnimateCircleAngleTo;
  
  int mAnimateRelativeTo = -1;
  
  int mDrawPath = 0;
  
  Easing mKeyFrameEasing;
  
  int mMode = 0;
  
  int mPathMotionArc = -1;
  
  float mPathRotate = Float.NaN;
  
  float mProgress = Float.NaN;
  
  float mRelativeAngle = Float.NaN;
  
  Motion mRelativeToController = null;
  
  double[] mTempDelta = new double[18];
  
  double[] mTempValue = new double[18];
  
  float position;
  
  float time;
  
  float width;
  
  float x;
  
  float y;
  
  public MotionPaths() {}
  
  public MotionPaths(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    if (paramMotionPaths1.mAnimateRelativeTo != -1) {
      initPolar(paramInt1, paramInt2, paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
      return;
    } 
    int i = paramMotionKeyPosition.mPositionType;
    if (i != 1) {
      if (i != 2) {
        initCartesian(paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
        return;
      } 
      initScreen(paramInt1, paramInt2, paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
      return;
    } 
    initPath(paramMotionKeyPosition, paramMotionPaths1, paramMotionPaths2);
  }
  
  private boolean diff(float paramFloat1, float paramFloat2) {
    return (Float.isNaN(paramFloat1) || Float.isNaN(paramFloat2)) ? ((Float.isNaN(paramFloat1) != Float.isNaN(paramFloat2))) : ((Math.abs(paramFloat1 - paramFloat2) > 1.0E-6F));
  }
  
  private static final float xRotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return (paramFloat5 - paramFloat3) * paramFloat2 - (paramFloat6 - paramFloat4) * paramFloat1 + paramFloat3;
  }
  
  private static final float yRotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    return (paramFloat5 - paramFloat3) * paramFloat1 + (paramFloat6 - paramFloat4) * paramFloat2 + paramFloat4;
  }
  
  public void applyParameters(MotionWidget paramMotionWidget) {
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionWidget.motion.mTransitionEasing);
    this.mPathMotionArc = paramMotionWidget.motion.mPathMotionArc;
    this.mAnimateRelativeTo = paramMotionWidget.motion.mAnimateRelativeTo;
    this.mPathRotate = paramMotionWidget.motion.mPathRotate;
    this.mDrawPath = paramMotionWidget.motion.mDrawPath;
    this.mAnimateCircleAngleTo = paramMotionWidget.motion.mAnimateCircleAngleTo;
    this.mProgress = paramMotionWidget.propertySet.mProgress;
    this.mRelativeAngle = 0.0F;
    for (String str : paramMotionWidget.getCustomAttributeNames()) {
      CustomVariable customVariable = paramMotionWidget.getCustomAttribute(str);
      if (customVariable != null && customVariable.isContinuous())
        this.customAttributes.put(str, customVariable); 
    } 
  }
  
  public int compareTo(MotionPaths paramMotionPaths) {
    return Float.compare(this.position, paramMotionPaths.position);
  }
  
  public void configureRelativeTo(Motion paramMotion) {
    paramMotion.getPos(this.mProgress);
  }
  
  void different(MotionPaths paramMotionPaths, boolean[] paramArrayOfboolean, String[] paramArrayOfString, boolean paramBoolean) {
    boolean bool2 = diff(this.x, paramMotionPaths.x);
    boolean bool3 = diff(this.y, paramMotionPaths.y);
    paramArrayOfboolean[0] = paramArrayOfboolean[0] | diff(this.position, paramMotionPaths.position);
    boolean bool4 = paramArrayOfboolean[1];
    boolean bool1 = bool2 | bool3 | paramBoolean;
    paramArrayOfboolean[1] = bool4 | bool1;
    paramArrayOfboolean[2] = bool1 | paramArrayOfboolean[2];
    paramArrayOfboolean[3] = paramArrayOfboolean[3] | diff(this.width, paramMotionPaths.width);
    paramBoolean = paramArrayOfboolean[4];
    paramArrayOfboolean[4] = diff(this.height, paramMotionPaths.height) | paramBoolean;
  }
  
  void fillStandard(double[] paramArrayOfdouble, int[] paramArrayOfint) {
    float f1 = this.position;
    int i = 0;
    float f2 = this.x;
    float f3 = this.y;
    float f4 = this.width;
    float f5 = this.height;
    float f6 = this.mPathRotate;
    int j;
    for (j = 0; i < paramArrayOfint.length; j = k) {
      int m = paramArrayOfint[i];
      int k = j;
      if (m < 6) {
        (new float[6])[0] = f1;
        (new float[6])[1] = f2;
        (new float[6])[2] = f3;
        (new float[6])[3] = f4;
        (new float[6])[4] = f5;
        (new float[6])[5] = f6;
        paramArrayOfdouble[j] = (new float[6])[m];
        k = j + 1;
      } 
      i++;
    } 
  }
  
  void getBounds(int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f2 = this.width;
    float f1 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 3) {
        if (j == 4)
          f1 = f; 
      } else {
        f2 = f;
      } 
    } 
    paramArrayOffloat[paramInt] = f2;
    paramArrayOffloat[paramInt + 1] = f1;
  }
  
  void getCenter(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      float[] arrayOfFloat = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat, new float[2]);
      f6 = arrayOfFloat[0];
      f1 = arrayOfFloat[1];
      double d2 = f6;
      paramDouble = f3;
      double d1 = f2;
      double d3 = Math.sin(d1);
      Double.isNaN(paramDouble);
      Double.isNaN(d2);
      double d4 = (f5 / 2.0F);
      Double.isNaN(d4);
      f2 = (float)(d2 + d3 * paramDouble - d4);
      d2 = f1;
      d1 = Math.cos(d1);
      Double.isNaN(paramDouble);
      Double.isNaN(d2);
      d3 = (f4 / 2.0F);
      Double.isNaN(d3);
      f1 = (float)(d2 - paramDouble * d1 - d3);
      f6 = f2;
    } 
    paramArrayOffloat[paramInt] = f6 + f5 / 2.0F + 0.0F;
    paramArrayOffloat[paramInt + 1] = f1 + f4 / 2.0F + 0.0F;
  }
  
  void getCenter(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble1, float[] paramArrayOffloat1, double[] paramArrayOfdouble2, float[] paramArrayOffloat2) {
    float f3 = this.x;
    float f4 = this.y;
    float f6 = this.width;
    float f5 = this.height;
    int i = 0;
    float f8 = 0.0F;
    float f10 = 0.0F;
    float f7 = 0.0F;
    float f9 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f12 = (float)paramArrayOfdouble1[i];
      float f11 = (float)paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4) {
              f5 = f12;
              f9 = f11;
            } 
          } else {
            f6 = f12;
            f10 = f11;
          } 
        } else {
          f4 = f12;
          f7 = f11;
        } 
      } else {
        f8 = f11;
        f3 = f12;
      } 
      i++;
    } 
    float f1 = f10 / 2.0F + f8;
    float f2 = f9 / 2.0F + f7;
    Motion motion = this.mRelativeToController;
    if (motion != null) {
      float[] arrayOfFloat1 = new float[2];
      float[] arrayOfFloat2 = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat1, arrayOfFloat2);
      f10 = arrayOfFloat1[0];
      f9 = arrayOfFloat1[1];
      f1 = arrayOfFloat2[0];
      f2 = arrayOfFloat2[1];
      double d2 = f10;
      double d1 = f3;
      paramDouble = f4;
      double d3 = Math.sin(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d2);
      double d4 = (f6 / 2.0F);
      Double.isNaN(d4);
      f3 = (float)(d2 + d3 * d1 - d4);
      d2 = f9;
      d3 = Math.cos(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d2);
      d4 = (f5 / 2.0F);
      Double.isNaN(d4);
      f4 = (float)(d2 - d1 * d3 - d4);
      d3 = f1;
      d1 = f8;
      d4 = Math.sin(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d3);
      double d5 = Math.cos(paramDouble);
      d2 = f7;
      Double.isNaN(d2);
      f1 = (float)(d3 + d4 * d1 + d5 * d2);
      d3 = f2;
      d4 = Math.cos(paramDouble);
      Double.isNaN(d1);
      Double.isNaN(d3);
      paramDouble = Math.sin(paramDouble);
      Double.isNaN(d2);
      f2 = (float)(d3 - d1 * d4 + paramDouble * d2);
    } 
    paramArrayOffloat1[0] = f3 + f6 / 2.0F + 0.0F;
    paramArrayOffloat1[1] = f4 + f5 / 2.0F + 0.0F;
    paramArrayOffloat2[0] = f1;
    paramArrayOffloat2[1] = f2;
  }
  
  void getCenterVelocity(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      float[] arrayOfFloat = new float[2];
      motion.getCenter(paramDouble, arrayOfFloat, new float[2]);
      f6 = arrayOfFloat[0];
      f1 = arrayOfFloat[1];
      double d2 = f6;
      paramDouble = f3;
      double d1 = f2;
      double d3 = Math.sin(d1);
      Double.isNaN(paramDouble);
      Double.isNaN(d2);
      double d4 = (f5 / 2.0F);
      Double.isNaN(d4);
      f2 = (float)(d2 + d3 * paramDouble - d4);
      d2 = f1;
      d1 = Math.cos(d1);
      Double.isNaN(paramDouble);
      Double.isNaN(d2);
      d3 = (f4 / 2.0F);
      Double.isNaN(d3);
      f1 = (float)(d2 - paramDouble * d1 - d3);
      f6 = f2;
    } 
    paramArrayOffloat[paramInt] = f6 + f5 / 2.0F + 0.0F;
    paramArrayOffloat[paramInt + 1] = f1 + f4 / 2.0F + 0.0F;
  }
  
  int getCustomData(String paramString, double[] paramArrayOfdouble, int paramInt) {
    CustomVariable customVariable = this.customAttributes.get(paramString);
    int i = 0;
    if (customVariable == null)
      return 0; 
    if (customVariable.numberOfInterpolatedValues() == 1) {
      paramArrayOfdouble[paramInt] = customVariable.getValueToInterpolate();
      return 1;
    } 
    int j = customVariable.numberOfInterpolatedValues();
    float[] arrayOfFloat = new float[j];
    customVariable.getValuesToInterpolate(arrayOfFloat);
    while (i < j) {
      paramArrayOfdouble[paramInt] = arrayOfFloat[i];
      i++;
      paramInt++;
    } 
    return j;
  }
  
  int getCustomDataCount(String paramString) {
    CustomVariable customVariable = this.customAttributes.get(paramString);
    return (customVariable == null) ? 0 : customVariable.numberOfInterpolatedValues();
  }
  
  void getRect(int[] paramArrayOfint, double[] paramArrayOfdouble, float[] paramArrayOffloat, int paramInt) {
    float f3 = this.x;
    float f2 = this.y;
    float f5 = this.width;
    float f4 = this.height;
    int i;
    for (i = 0; i < paramArrayOfint.length; i++) {
      float f = (float)paramArrayOfdouble[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f4 = f; 
          } else {
            f5 = f;
          } 
        } else {
          f2 = f;
        } 
      } else {
        f3 = f;
      } 
    } 
    Motion motion = this.mRelativeToController;
    float f6 = f3;
    float f1 = f2;
    if (motion != null) {
      f6 = motion.getCenterX();
      f1 = this.mRelativeToController.getCenterY();
      double d3 = f6;
      double d1 = f3;
      double d2 = f2;
      double d4 = Math.sin(d2);
      Double.isNaN(d1);
      Double.isNaN(d3);
      double d5 = (f5 / 2.0F);
      Double.isNaN(d5);
      f6 = (float)(d3 + d4 * d1 - d5);
      d3 = f1;
      d2 = Math.cos(d2);
      Double.isNaN(d1);
      Double.isNaN(d3);
      d4 = (f4 / 2.0F);
      Double.isNaN(d4);
      f1 = (float)(d3 - d1 * d2 - d4);
    } 
    f2 = f5 + f6;
    f3 = f4 + f1;
    Float.isNaN(Float.NaN);
    Float.isNaN(Float.NaN);
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f6 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f1 + 0.0F;
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f2 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f1 + 0.0F;
    i = paramInt + 1;
    paramArrayOffloat[paramInt] = f2 + 0.0F;
    paramInt = i + 1;
    paramArrayOffloat[i] = f3 + 0.0F;
    paramArrayOffloat[paramInt] = f6 + 0.0F;
    paramArrayOffloat[paramInt + 1] = f3 + 0.0F;
  }
  
  boolean hasCustomData(String paramString) {
    return this.customAttributes.containsKey(paramString);
  }
  
  void initCartesian(MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f7 = paramMotionPaths2.width;
    float f4 = paramMotionPaths1.width;
    float f10 = paramMotionPaths2.height;
    float f8 = paramMotionPaths1.height;
    this.position = this.time;
    float f11 = paramMotionPaths1.x;
    float f5 = f4 / 2.0F;
    float f9 = paramMotionPaths1.y;
    float f6 = f8 / 2.0F;
    float f14 = paramMotionPaths2.x;
    float f15 = f7 / 2.0F;
    float f12 = paramMotionPaths2.y;
    float f13 = f10 / 2.0F;
    f5 = f14 + f15 - f5 + f11;
    f6 = f12 + f13 - f9 + f6;
    float f2 = (f7 - f4) * f2;
    f7 = f2 / 2.0F;
    this.x = (int)(f11 + f5 * f1 - f7);
    float f3 = (f10 - f8) * f3;
    f10 = f3 / 2.0F;
    this.y = (int)(f9 + f6 * f1 - f10);
    this.width = (int)(f4 + f2);
    this.height = (int)(f8 + f3);
    if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentX;
    } 
    boolean bool = Float.isNaN(paramMotionKeyPosition.mAltPercentY);
    f4 = 0.0F;
    if (bool) {
      f3 = 0.0F;
    } else {
      f3 = paramMotionKeyPosition.mAltPercentY;
    } 
    if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
      f1 = paramMotionKeyPosition.mPercentY; 
    if (!Float.isNaN(paramMotionKeyPosition.mAltPercentX))
      f4 = paramMotionKeyPosition.mAltPercentX; 
    this.mMode = 0;
    this.x = (int)(paramMotionPaths1.x + f2 * f5 + f4 * f6 - f7);
    this.y = (int)(paramMotionPaths1.y + f5 * f3 + f6 * f1 - f10);
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initPath(MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f11 = paramMotionPaths2.width;
    float f12 = paramMotionPaths1.width;
    float f5 = paramMotionPaths2.height;
    float f6 = paramMotionPaths1.height;
    this.position = this.time;
    if (!Float.isNaN(paramMotionKeyPosition.mPercentX))
      f1 = paramMotionKeyPosition.mPercentX; 
    float f13 = paramMotionPaths1.x;
    float f7 = paramMotionPaths1.width;
    float f4 = f7 / 2.0F;
    float f8 = paramMotionPaths1.y;
    float f9 = paramMotionPaths1.height;
    float f10 = f9 / 2.0F;
    float f16 = paramMotionPaths2.x;
    float f17 = paramMotionPaths2.width / 2.0F;
    float f14 = paramMotionPaths2.y;
    float f15 = paramMotionPaths2.height / 2.0F;
    f4 = f16 + f17 - f4 + f13;
    f14 = f14 + f15 - f10 + f8;
    f10 = f4 * f1;
    f12 = (f11 - f12) * f3;
    float f3 = f12 / 2.0F;
    this.x = (int)(f13 + f10 - f3);
    f11 = f1 * f14;
    f1 = (f5 - f6) * f2;
    float f2 = f1 / 2.0F;
    this.y = (int)(f8 + f11 - f2);
    this.width = (int)(f7 + f12);
    this.height = (int)(f9 + f1);
    if (Float.isNaN(paramMotionKeyPosition.mPercentY)) {
      f1 = 0.0F;
    } else {
      f1 = paramMotionKeyPosition.mPercentY;
    } 
    f5 = -f14;
    this.mMode = 1;
    f3 = (int)(paramMotionPaths1.x + f10 - f3);
    this.x = f3;
    f2 = (int)(paramMotionPaths1.y + f11 - f2);
    this.x = f3 + f5 * f1;
    this.y = f2 + f4 * f1;
    this.mAnimateRelativeTo = this.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initPolar(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f2;
    float f3;
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    this.mMode = paramMotionKeyPosition.mPositionType;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f4 = paramMotionPaths2.width;
    float f5 = paramMotionPaths1.width;
    float f6 = paramMotionPaths2.height;
    float f7 = paramMotionPaths1.height;
    this.position = this.time;
    this.width = (int)(f5 + (f4 - f5) * f2);
    this.height = (int)(f7 + (f6 - f7) * f3);
    paramInt1 = paramMotionKeyPosition.mPositionType;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
          f2 = f1;
        } else {
          f2 = paramMotionKeyPosition.mPercentX;
        } 
        f3 = paramMotionPaths2.x;
        f4 = paramMotionPaths1.x;
        this.x = f2 * (f3 - f4) + f4;
        if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
          f1 = paramMotionKeyPosition.mPercentY; 
        f2 = paramMotionPaths2.y;
        f3 = paramMotionPaths1.y;
        this.y = f1 * (f2 - f3) + f3;
      } else {
        if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
          f2 = paramMotionPaths2.x;
          f3 = paramMotionPaths1.x;
          f2 = (f2 - f3) * f1 + f3;
        } else {
          f4 = paramMotionKeyPosition.mPercentX;
          f2 = Math.min(f3, f2) * f4;
        } 
        this.x = f2;
        if (Float.isNaN(paramMotionKeyPosition.mPercentY)) {
          f2 = paramMotionPaths2.y;
          f3 = paramMotionPaths1.y;
          f1 = f1 * (f2 - f3) + f3;
        } else {
          f1 = paramMotionKeyPosition.mPercentY;
        } 
        this.y = f1;
      } 
    } else {
      if (Float.isNaN(paramMotionKeyPosition.mPercentX)) {
        f2 = f1;
      } else {
        f2 = paramMotionKeyPosition.mPercentX;
      } 
      f3 = paramMotionPaths2.x;
      f4 = paramMotionPaths1.x;
      this.x = f2 * (f3 - f4) + f4;
      if (!Float.isNaN(paramMotionKeyPosition.mPercentY))
        f1 = paramMotionKeyPosition.mPercentY; 
      f2 = paramMotionPaths2.y;
      f3 = paramMotionPaths1.y;
      this.y = f1 * (f2 - f3) + f3;
    } 
    this.mAnimateRelativeTo = paramMotionPaths1.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void initScreen(int paramInt1, int paramInt2, MotionKeyPosition paramMotionKeyPosition, MotionPaths paramMotionPaths1, MotionPaths paramMotionPaths2) {
    float f1 = paramMotionKeyPosition.mFramePosition / 100.0F;
    this.time = f1;
    this.mDrawPath = paramMotionKeyPosition.mDrawPath;
    if (Float.isNaN(paramMotionKeyPosition.mPercentWidth)) {
      f2 = f1;
    } else {
      f2 = paramMotionKeyPosition.mPercentWidth;
    } 
    if (Float.isNaN(paramMotionKeyPosition.mPercentHeight)) {
      f3 = f1;
    } else {
      f3 = paramMotionKeyPosition.mPercentHeight;
    } 
    float f15 = paramMotionPaths2.width;
    float f4 = paramMotionPaths1.width;
    float f10 = paramMotionPaths2.height;
    float f5 = paramMotionPaths1.height;
    this.position = this.time;
    float f11 = paramMotionPaths1.x;
    float f12 = f4 / 2.0F;
    float f6 = paramMotionPaths1.y;
    float f7 = f5 / 2.0F;
    float f13 = paramMotionPaths2.x;
    float f14 = f15 / 2.0F;
    float f8 = paramMotionPaths2.y;
    float f9 = f10 / 2.0F;
    float f2 = (f15 - f4) * f2;
    this.x = (int)(f11 + (f13 + f14 - f12 + f11) * f1 - f2 / 2.0F);
    float f3 = (f10 - f5) * f3;
    this.y = (int)(f6 + (f8 + f9 - f6 + f7) * f1 - f3 / 2.0F);
    this.width = (int)(f4 + f2);
    this.height = (int)(f5 + f3);
    this.mMode = 2;
    if (!Float.isNaN(paramMotionKeyPosition.mPercentX)) {
      paramInt1 = (int)(paramInt1 - this.width);
      this.x = (int)(paramMotionKeyPosition.mPercentX * paramInt1);
    } 
    if (!Float.isNaN(paramMotionKeyPosition.mPercentY)) {
      paramInt1 = (int)(paramInt2 - this.height);
      this.y = (int)(paramMotionKeyPosition.mPercentY * paramInt1);
    } 
    this.mAnimateRelativeTo = this.mAnimateRelativeTo;
    this.mKeyFrameEasing = Easing.getInterpolator(paramMotionKeyPosition.mTransitionEasing);
    this.mPathMotionArc = paramMotionKeyPosition.mPathMotionArc;
  }
  
  void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.x = paramFloat1;
    this.y = paramFloat2;
    this.width = paramFloat3;
    this.height = paramFloat4;
  }
  
  void setDpDt(float paramFloat1, float paramFloat2, float[] paramArrayOffloat, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2) {
    int i = 0;
    float f5 = 0.0F;
    float f3 = 0.0F;
    float f4 = 0.0F;
    float f2 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f = (float)paramArrayOfdouble1[i];
      double d = paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              f2 = f; 
          } else {
            f3 = f;
          } 
        } else {
          f4 = f;
        } 
      } else {
        f5 = f;
      } 
      i++;
    } 
    float f1 = f5 - 0.0F * f3 / 2.0F;
    f4 -= 0.0F * f2 / 2.0F;
    paramArrayOffloat[0] = f1 * (1.0F - paramFloat1) + (f3 * 1.0F + f1) * paramFloat1 + 0.0F;
    paramArrayOffloat[1] = f4 * (1.0F - paramFloat2) + (f2 * 1.0F + f4) * paramFloat2 + 0.0F;
  }
  
  void setView(float paramFloat, MotionWidget paramMotionWidget, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3) {
    // Byte code:
    //   0: aload_0
    //   1: getfield x : F
    //   4: fstore #26
    //   6: aload_0
    //   7: getfield y : F
    //   10: fstore #25
    //   12: aload_0
    //   13: getfield width : F
    //   16: fstore #28
    //   18: aload_0
    //   19: getfield height : F
    //   22: fstore #27
    //   24: aload_3
    //   25: arraylength
    //   26: ifeq -> 69
    //   29: aload_0
    //   30: getfield mTempValue : [D
    //   33: arraylength
    //   34: aload_3
    //   35: aload_3
    //   36: arraylength
    //   37: iconst_1
    //   38: isub
    //   39: iaload
    //   40: if_icmpgt -> 69
    //   43: aload_3
    //   44: aload_3
    //   45: arraylength
    //   46: iconst_1
    //   47: isub
    //   48: iaload
    //   49: iconst_1
    //   50: iadd
    //   51: istore #33
    //   53: aload_0
    //   54: iload #33
    //   56: newarray double
    //   58: putfield mTempValue : [D
    //   61: aload_0
    //   62: iload #33
    //   64: newarray double
    //   66: putfield mTempDelta : [D
    //   69: aload_0
    //   70: getfield mTempValue : [D
    //   73: ldc2_w NaN
    //   76: invokestatic fill : ([DD)V
    //   79: iconst_0
    //   80: istore #33
    //   82: iload #33
    //   84: aload_3
    //   85: arraylength
    //   86: if_icmpge -> 132
    //   89: aload_0
    //   90: getfield mTempValue : [D
    //   93: astore #36
    //   95: aload_3
    //   96: iload #33
    //   98: iaload
    //   99: istore #34
    //   101: aload #36
    //   103: iload #34
    //   105: aload #4
    //   107: iload #33
    //   109: daload
    //   110: dastore
    //   111: aload_0
    //   112: getfield mTempDelta : [D
    //   115: iload #34
    //   117: aload #5
    //   119: iload #33
    //   121: daload
    //   122: dastore
    //   123: iload #33
    //   125: iconst_1
    //   126: iadd
    //   127: istore #33
    //   129: goto -> 82
    //   132: ldc NaN
    //   134: fstore #23
    //   136: iconst_0
    //   137: istore #33
    //   139: fconst_0
    //   140: fstore #30
    //   142: fconst_0
    //   143: fstore #29
    //   145: fconst_0
    //   146: fstore #32
    //   148: fconst_0
    //   149: fstore #31
    //   151: aload_0
    //   152: getfield mTempValue : [D
    //   155: astore_3
    //   156: iload #33
    //   158: aload_3
    //   159: arraylength
    //   160: if_icmpge -> 367
    //   163: aload_3
    //   164: iload #33
    //   166: daload
    //   167: invokestatic isNaN : (D)Z
    //   170: istore #35
    //   172: dconst_0
    //   173: dstore #7
    //   175: iload #35
    //   177: ifeq -> 198
    //   180: aload #6
    //   182: ifnull -> 195
    //   185: aload #6
    //   187: iload #33
    //   189: daload
    //   190: dconst_0
    //   191: dcmpl
    //   192: ifne -> 198
    //   195: goto -> 287
    //   198: aload #6
    //   200: ifnull -> 210
    //   203: aload #6
    //   205: iload #33
    //   207: daload
    //   208: dstore #7
    //   210: aload_0
    //   211: getfield mTempValue : [D
    //   214: iload #33
    //   216: daload
    //   217: invokestatic isNaN : (D)Z
    //   220: ifeq -> 226
    //   223: goto -> 238
    //   226: aload_0
    //   227: getfield mTempValue : [D
    //   230: iload #33
    //   232: daload
    //   233: dload #7
    //   235: dadd
    //   236: dstore #7
    //   238: fload #23
    //   240: fstore #22
    //   242: dload #7
    //   244: d2f
    //   245: fstore #21
    //   247: aload_0
    //   248: getfield mTempDelta : [D
    //   251: iload #33
    //   253: daload
    //   254: d2f
    //   255: fstore #24
    //   257: iload #33
    //   259: iconst_1
    //   260: if_icmpeq -> 342
    //   263: iload #33
    //   265: iconst_2
    //   266: if_icmpeq -> 327
    //   269: iload #33
    //   271: iconst_3
    //   272: if_icmpeq -> 312
    //   275: iload #33
    //   277: iconst_4
    //   278: if_icmpeq -> 297
    //   281: iload #33
    //   283: iconst_5
    //   284: if_icmpeq -> 294
    //   287: fload #23
    //   289: fstore #21
    //   291: goto -> 354
    //   294: goto -> 354
    //   297: fload #21
    //   299: fstore #27
    //   301: fload #22
    //   303: fstore #21
    //   305: fload #24
    //   307: fstore #31
    //   309: goto -> 354
    //   312: fload #21
    //   314: fstore #28
    //   316: fload #22
    //   318: fstore #21
    //   320: fload #24
    //   322: fstore #32
    //   324: goto -> 354
    //   327: fload #21
    //   329: fstore #25
    //   331: fload #22
    //   333: fstore #21
    //   335: fload #24
    //   337: fstore #29
    //   339: goto -> 354
    //   342: fload #21
    //   344: fstore #26
    //   346: fload #24
    //   348: fstore #30
    //   350: fload #22
    //   352: fstore #21
    //   354: iload #33
    //   356: iconst_1
    //   357: iadd
    //   358: istore #33
    //   360: fload #21
    //   362: fstore #23
    //   364: goto -> 151
    //   367: aload_0
    //   368: getfield mRelativeToController : Landroidx/constraintlayout/core/motion/Motion;
    //   371: astore_3
    //   372: aload_3
    //   373: ifnull -> 732
    //   376: iconst_2
    //   377: newarray float
    //   379: astore #4
    //   381: iconst_2
    //   382: newarray float
    //   384: astore #6
    //   386: aload_3
    //   387: fload_1
    //   388: f2d
    //   389: aload #4
    //   391: aload #6
    //   393: invokevirtual getCenter : (D[F[F)V
    //   396: aload #4
    //   398: iconst_0
    //   399: faload
    //   400: fstore_1
    //   401: aload #4
    //   403: iconst_1
    //   404: faload
    //   405: fstore #21
    //   407: aload #6
    //   409: iconst_0
    //   410: faload
    //   411: fstore #24
    //   413: aload #6
    //   415: iconst_1
    //   416: faload
    //   417: fstore #22
    //   419: fload_1
    //   420: f2d
    //   421: dstore #11
    //   423: fload #26
    //   425: f2d
    //   426: dstore #7
    //   428: fload #25
    //   430: f2d
    //   431: dstore #9
    //   433: dload #9
    //   435: invokestatic sin : (D)D
    //   438: dstore #13
    //   440: dload #7
    //   442: invokestatic isNaN : (D)Z
    //   445: pop
    //   446: dload #11
    //   448: invokestatic isNaN : (D)Z
    //   451: pop
    //   452: fload #28
    //   454: fconst_2
    //   455: fdiv
    //   456: f2d
    //   457: dstore #15
    //   459: dload #15
    //   461: invokestatic isNaN : (D)Z
    //   464: pop
    //   465: dload #11
    //   467: dload #13
    //   469: dload #7
    //   471: dmul
    //   472: dadd
    //   473: dload #15
    //   475: dsub
    //   476: d2f
    //   477: fstore_1
    //   478: fload #21
    //   480: f2d
    //   481: dstore #11
    //   483: dload #9
    //   485: invokestatic cos : (D)D
    //   488: dstore #13
    //   490: dload #7
    //   492: invokestatic isNaN : (D)Z
    //   495: pop
    //   496: dload #11
    //   498: invokestatic isNaN : (D)Z
    //   501: pop
    //   502: fload #27
    //   504: fconst_2
    //   505: fdiv
    //   506: f2d
    //   507: dstore #15
    //   509: dload #15
    //   511: invokestatic isNaN : (D)Z
    //   514: pop
    //   515: dload #11
    //   517: dload #13
    //   519: dload #7
    //   521: dmul
    //   522: dsub
    //   523: dload #15
    //   525: dsub
    //   526: d2f
    //   527: fstore #21
    //   529: fload #24
    //   531: f2d
    //   532: dstore #15
    //   534: fload #30
    //   536: f2d
    //   537: dstore #11
    //   539: dload #9
    //   541: invokestatic sin : (D)D
    //   544: dstore #17
    //   546: dload #11
    //   548: invokestatic isNaN : (D)Z
    //   551: pop
    //   552: dload #15
    //   554: invokestatic isNaN : (D)Z
    //   557: pop
    //   558: dload #9
    //   560: invokestatic cos : (D)D
    //   563: dstore #19
    //   565: dload #7
    //   567: invokestatic isNaN : (D)Z
    //   570: pop
    //   571: fload #29
    //   573: f2d
    //   574: dstore #13
    //   576: dload #13
    //   578: invokestatic isNaN : (D)Z
    //   581: pop
    //   582: dload #15
    //   584: dload #17
    //   586: dload #11
    //   588: dmul
    //   589: dadd
    //   590: dload #19
    //   592: dload #7
    //   594: dmul
    //   595: dload #13
    //   597: dmul
    //   598: dadd
    //   599: d2f
    //   600: fstore #24
    //   602: fload #22
    //   604: f2d
    //   605: dstore #15
    //   607: dload #9
    //   609: invokestatic cos : (D)D
    //   612: dstore #17
    //   614: dload #11
    //   616: invokestatic isNaN : (D)Z
    //   619: pop
    //   620: dload #15
    //   622: invokestatic isNaN : (D)Z
    //   625: pop
    //   626: dload #9
    //   628: invokestatic sin : (D)D
    //   631: dstore #9
    //   633: dload #7
    //   635: invokestatic isNaN : (D)Z
    //   638: pop
    //   639: dload #13
    //   641: invokestatic isNaN : (D)Z
    //   644: pop
    //   645: dload #15
    //   647: dload #11
    //   649: dload #17
    //   651: dmul
    //   652: dsub
    //   653: dload #7
    //   655: dload #9
    //   657: dmul
    //   658: dload #13
    //   660: dmul
    //   661: dadd
    //   662: d2f
    //   663: fstore #22
    //   665: aload #5
    //   667: arraylength
    //   668: iconst_2
    //   669: if_icmplt -> 686
    //   672: aload #5
    //   674: iconst_0
    //   675: fload #24
    //   677: f2d
    //   678: dastore
    //   679: aload #5
    //   681: iconst_1
    //   682: fload #22
    //   684: f2d
    //   685: dastore
    //   686: fload #23
    //   688: invokestatic isNaN : (F)Z
    //   691: ifne -> 729
    //   694: fload #23
    //   696: f2d
    //   697: dstore #7
    //   699: fload #22
    //   701: f2d
    //   702: fload #24
    //   704: f2d
    //   705: invokestatic atan2 : (DD)D
    //   708: invokestatic toDegrees : (D)D
    //   711: dstore #9
    //   713: dload #7
    //   715: invokestatic isNaN : (D)Z
    //   718: pop
    //   719: aload_2
    //   720: dload #7
    //   722: dload #9
    //   724: dadd
    //   725: d2f
    //   726: invokevirtual setRotationZ : (F)V
    //   729: goto -> 818
    //   732: fload #26
    //   734: fstore_1
    //   735: fload #25
    //   737: fstore #21
    //   739: fload #23
    //   741: invokestatic isNaN : (F)Z
    //   744: ifne -> 818
    //   747: fload #32
    //   749: fconst_2
    //   750: fdiv
    //   751: fstore_1
    //   752: fload #31
    //   754: fconst_2
    //   755: fdiv
    //   756: fstore #21
    //   758: fconst_0
    //   759: f2d
    //   760: dstore #7
    //   762: fload #23
    //   764: f2d
    //   765: dstore #9
    //   767: fload #29
    //   769: fload #21
    //   771: fadd
    //   772: f2d
    //   773: fload #30
    //   775: fload_1
    //   776: fadd
    //   777: f2d
    //   778: invokestatic atan2 : (DD)D
    //   781: invokestatic toDegrees : (D)D
    //   784: dstore #11
    //   786: dload #9
    //   788: invokestatic isNaN : (D)Z
    //   791: pop
    //   792: dload #7
    //   794: invokestatic isNaN : (D)Z
    //   797: pop
    //   798: aload_2
    //   799: dload #7
    //   801: dload #9
    //   803: dload #11
    //   805: dadd
    //   806: dadd
    //   807: d2f
    //   808: invokevirtual setRotationZ : (F)V
    //   811: fload #25
    //   813: fstore #21
    //   815: fload #26
    //   817: fstore_1
    //   818: fload_1
    //   819: ldc_w 0.5
    //   822: fadd
    //   823: fstore_1
    //   824: fload_1
    //   825: f2i
    //   826: istore #33
    //   828: fload #21
    //   830: ldc_w 0.5
    //   833: fadd
    //   834: fstore #21
    //   836: aload_2
    //   837: iload #33
    //   839: fload #21
    //   841: f2i
    //   842: fload_1
    //   843: fload #28
    //   845: fadd
    //   846: f2i
    //   847: fload #21
    //   849: fload #27
    //   851: fadd
    //   852: f2i
    //   853: invokevirtual layout : (IIII)V
    //   856: return
  }
  
  public void setupRelative(Motion paramMotion, MotionPaths paramMotionPaths) {
    double d1 = (this.x + this.width / 2.0F - paramMotionPaths.x - paramMotionPaths.width / 2.0F);
    double d2 = (this.y + this.height / 2.0F - paramMotionPaths.y - paramMotionPaths.height / 2.0F);
    this.mRelativeToController = paramMotion;
    this.x = (float)Math.hypot(d2, d1);
    if (Float.isNaN(this.mRelativeAngle)) {
      this.y = (float)(Math.atan2(d2, d1) + 1.5707963267948966D);
      return;
    } 
    this.y = (float)Math.toRadians(this.mRelativeAngle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\motion\MotionPaths.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */