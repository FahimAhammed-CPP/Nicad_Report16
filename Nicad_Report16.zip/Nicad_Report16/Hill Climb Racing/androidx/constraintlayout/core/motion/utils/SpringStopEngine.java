package androidx.constraintlayout.core.motion.utils;

import java.io.PrintStream;

public class SpringStopEngine implements StopEngine {
  private static final double UNSET = 1.7976931348623157E308D;
  
  private int mBoundaryMode = 0;
  
  double mDamping = 0.5D;
  
  private boolean mInitialized = false;
  
  private float mLastTime;
  
  private double mLastVelocity;
  
  private float mMass;
  
  private float mPos;
  
  private double mStiffness;
  
  private float mStopThreshold;
  
  private double mTargetPos;
  
  private float mV;
  
  private void compute(double paramDouble) {
    double d1 = this.mStiffness;
    double d2 = this.mDamping;
    double d3 = this.mMass;
    Double.isNaN(d3);
    int j = (int)(9.0D / Math.sqrt(d1 / d3) * paramDouble * 4.0D + 1.0D);
    d3 = j;
    Double.isNaN(d3);
    d3 = paramDouble / d3;
    int i = 0;
    paramDouble = d2;
    while (i < j) {
      float f1 = this.mPos;
      double d4 = f1;
      d2 = this.mTargetPos;
      Double.isNaN(d4);
      double d5 = -d1;
      float f2 = this.mV;
      double d6 = f2;
      Double.isNaN(d6);
      float f3 = this.mMass;
      double d7 = f3;
      Double.isNaN(d7);
      d5 = (d5 * (d4 - d2) - d6 * paramDouble) / d7;
      d4 = f2;
      d5 = d5 * d3 / 2.0D;
      Double.isNaN(d4);
      d4 += d5;
      d5 = f1;
      d6 = d3 * d4 / 2.0D;
      Double.isNaN(d5);
      d2 = -(d5 + d6 - d2);
      d5 = f3;
      Double.isNaN(d5);
      d5 = (d2 * d1 - d4 * paramDouble) / d5 * d3;
      d2 = f2;
      d4 = d5 / 2.0D;
      Double.isNaN(d2);
      d6 = f2;
      Double.isNaN(d6);
      f2 = (float)(d6 + d5);
      this.mV = f2;
      d5 = f1;
      Double.isNaN(d5);
      f1 = (float)(d5 + (d2 + d4) * d3);
      this.mPos = f1;
      int k = this.mBoundaryMode;
      if (k > 0) {
        if (f1 < 0.0F && (k & 0x1) == 1) {
          this.mPos = -f1;
          this.mV = -f2;
        } 
        f1 = this.mPos;
        if (f1 > 1.0F && (k & 0x2) == 2) {
          this.mPos = 2.0F - f1;
          this.mV = -this.mV;
        } 
      } 
      i++;
    } 
  }
  
  public String debug(String paramString, float paramFloat) {
    return null;
  }
  
  public float getAcceleration() {
    double d4 = this.mStiffness;
    double d1 = this.mDamping;
    double d2 = this.mPos;
    double d3 = this.mTargetPos;
    Double.isNaN(d2);
    d4 = -d4;
    double d5 = this.mV;
    Double.isNaN(d5);
    return (float)(d4 * (d2 - d3) - d1 * d5) / this.mMass;
  }
  
  public float getInterpolation(float paramFloat) {
    compute((paramFloat - this.mLastTime));
    this.mLastTime = paramFloat;
    return this.mPos;
  }
  
  public float getVelocity() {
    return 0.0F;
  }
  
  public float getVelocity(float paramFloat) {
    return this.mV;
  }
  
  public boolean isStopped() {
    double d1 = this.mPos;
    double d2 = this.mTargetPos;
    Double.isNaN(d1);
    d1 -= d2;
    d2 = this.mStiffness;
    double d3 = this.mV;
    double d4 = this.mMass;
    Double.isNaN(d3);
    Double.isNaN(d3);
    Double.isNaN(d4);
    return (Math.sqrt((d3 * d3 * d4 + d2 * d1 * d1) / d2) <= this.mStopThreshold);
  }
  
  void log(String paramString) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    StringBuilder stringBuilder1 = new StringBuilder(".(");
    stringBuilder1.append(stackTraceElement.getFileName());
    stringBuilder1.append(":");
    stringBuilder1.append(stackTraceElement.getLineNumber());
    stringBuilder1.append(") ");
    stringBuilder1.append(stackTraceElement.getMethodName());
    stringBuilder1.append("() ");
    String str = stringBuilder1.toString();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append(paramString);
    printStream.println(stringBuilder2.toString());
  }
  
  public void springConfig(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, int paramInt) {
    this.mTargetPos = paramFloat2;
    this.mDamping = paramFloat6;
    this.mInitialized = false;
    this.mPos = paramFloat1;
    this.mLastVelocity = paramFloat3;
    this.mStiffness = paramFloat5;
    this.mMass = paramFloat4;
    this.mStopThreshold = paramFloat7;
    this.mBoundaryMode = paramInt;
    this.mLastTime = 0.0F;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\SpringStopEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */