package androidx.constraintlayout.core.motion.utils;

public class LinearCurveFit extends CurveFit {
  private static final String TAG = "LinearCurveFit";
  
  private boolean mExtrapolate = true;
  
  double[] mSlopeTemp;
  
  private double[] mT;
  
  private double mTotalLength = Double.NaN;
  
  private double[][] mY;
  
  public LinearCurveFit(double[] paramArrayOfdouble, double[][] paramArrayOfdouble1) {
    int i = paramArrayOfdouble.length;
    i = (paramArrayOfdouble1[0]).length;
    this.mSlopeTemp = new double[i];
    this.mT = paramArrayOfdouble;
    this.mY = paramArrayOfdouble1;
    if (i > 2) {
      double d1 = 0.0D;
      double d2 = d1;
      i = 0;
      while (i < paramArrayOfdouble.length) {
        double d = paramArrayOfdouble1[i][0];
        if (i > 0)
          Math.hypot(d - d1, d - d2); 
        i++;
        d1 = d;
        d2 = d1;
      } 
      this.mTotalLength = 0.0D;
    } 
  }
  
  private double getLength2D(double paramDouble) {
    if (Double.isNaN(this.mTotalLength))
      return 0.0D; 
    double[] arrayOfDouble = this.mT;
    int i = arrayOfDouble.length;
    if (paramDouble <= arrayOfDouble[0])
      return 0.0D; 
    int j = i - 1;
    if (paramDouble >= arrayOfDouble[j])
      return this.mTotalLength; 
    double d2 = 0.0D;
    double d1 = d2;
    double d4 = d1;
    i = 0;
    double d3 = d1;
    while (i < j) {
      arrayOfDouble = this.mY[i];
      double d6 = arrayOfDouble[0];
      double d5 = arrayOfDouble[1];
      d1 = d2;
      if (i > 0)
        d1 = d2 + Math.hypot(d6 - d3, d5 - d4); 
      arrayOfDouble = this.mT;
      d2 = arrayOfDouble[i];
      if (paramDouble == d2)
        return d1; 
      int k = i + 1;
      d3 = arrayOfDouble[k];
      if (paramDouble < d3) {
        paramDouble = (paramDouble - d2) / (d3 - d2);
        double[][] arrayOfDouble2 = this.mY;
        arrayOfDouble = arrayOfDouble2[i];
        d2 = arrayOfDouble[0];
        double[] arrayOfDouble1 = arrayOfDouble2[k];
        d3 = arrayOfDouble1[0];
        d4 = arrayOfDouble[1];
        double d7 = arrayOfDouble1[1];
        double d8 = 1.0D - paramDouble;
        return d1 + Math.hypot(d5 - d4 * d8 + d7 * paramDouble, d6 - d2 * d8 + d3 * paramDouble);
      } 
      i = k;
      d3 = d6;
      d4 = d5;
      d2 = d1;
    } 
    return 0.0D;
  }
  
  public double getPos(double paramDouble, int paramInt) {
    double[] arrayOfDouble = this.mT;
    int j = arrayOfDouble.length;
    boolean bool = this.mExtrapolate;
    int i = 0;
    if (bool) {
      double d1 = arrayOfDouble[0];
      if (paramDouble <= d1) {
        double d4 = this.mY[0][paramInt];
        double d3 = paramDouble - d1;
        d1 = getSlope(d1, paramInt);
        paramDouble = d4;
        return paramDouble + d3 * d1;
      } 
      int k = j - 1;
      double d2 = arrayOfDouble[k];
      if (paramDouble >= d2) {
        d1 = this.mY[k][paramInt];
        double d = paramDouble - d2;
        d2 = getSlope(d2, paramInt);
        paramDouble = d1;
        d1 = d2;
        return paramDouble + d * d1;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0])
        return this.mY[0][paramInt]; 
      int k = j - 1;
      if (paramDouble >= arrayOfDouble[k])
        return this.mY[k][paramInt]; 
    } 
    while (i < j - 1) {
      arrayOfDouble = this.mT;
      double d1 = arrayOfDouble[i];
      if (paramDouble == d1)
        return this.mY[i][paramInt]; 
      int k = i + 1;
      double d2 = arrayOfDouble[k];
      if (paramDouble < d2) {
        paramDouble = (paramDouble - d1) / (d2 - d1);
        double[][] arrayOfDouble1 = this.mY;
        return arrayOfDouble1[i][paramInt] * (1.0D - paramDouble) + arrayOfDouble1[k][paramInt] * paramDouble;
      } 
      i = k;
    } 
    return 0.0D;
  }
  
  public void getPos(double paramDouble, double[] paramArrayOfdouble) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      double d = arrayOfDouble[0];
      if (paramDouble <= d) {
        getSlope(d, this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]; 
        return;
      } 
      j = m - 1;
      d = arrayOfDouble[j];
      if (paramDouble >= d) {
        getSlope(d, this.mSlopeTemp);
        while (i < k) {
          paramArrayOfdouble[i] = this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i];
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOfdouble[i] = this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOfdouble[i] = this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOfdouble[j] = this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      double d = arrayOfDouble[n];
      if (paramDouble < d) {
        double d1 = arrayOfDouble[i];
        paramDouble = (paramDouble - d1) / (d - d1);
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          paramArrayOfdouble[j] = arrayOfDouble2[i][j] * (1.0D - paramDouble) + arrayOfDouble2[n][j] * paramDouble;
        } 
        return;
      } 
    } 
  }
  
  public void getPos(double paramDouble, float[] paramArrayOffloat) {
    double[] arrayOfDouble = this.mT;
    int m = arrayOfDouble.length;
    double[][] arrayOfDouble1 = this.mY;
    int j = 0;
    boolean bool = false;
    int i = 0;
    int k = (arrayOfDouble1[0]).length;
    if (this.mExtrapolate) {
      double d = arrayOfDouble[0];
      if (paramDouble <= d) {
        getSlope(d, this.mSlopeTemp);
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)(this.mY[0][i] + (paramDouble - this.mT[0]) * this.mSlopeTemp[i]); 
        return;
      } 
      j = m - 1;
      d = arrayOfDouble[j];
      if (paramDouble >= d) {
        getSlope(d, this.mSlopeTemp);
        while (i < k) {
          paramArrayOffloat[i] = (float)(this.mY[j][i] + (paramDouble - this.mT[j]) * this.mSlopeTemp[i]);
          i++;
        } 
        return;
      } 
    } else {
      if (paramDouble <= arrayOfDouble[0]) {
        for (i = 0; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[0][i]; 
        return;
      } 
      int n = m - 1;
      if (paramDouble >= arrayOfDouble[n]) {
        for (i = j; i < k; i++)
          paramArrayOffloat[i] = (float)this.mY[n][i]; 
        return;
      } 
    } 
    for (i = 0; i < m - 1; i = n) {
      if (paramDouble == this.mT[i])
        for (j = 0; j < k; j++)
          paramArrayOffloat[j] = (float)this.mY[i][j];  
      arrayOfDouble = this.mT;
      int n = i + 1;
      double d = arrayOfDouble[n];
      if (paramDouble < d) {
        double d1 = arrayOfDouble[i];
        paramDouble = (paramDouble - d1) / (d - d1);
        for (j = bool; j < k; j++) {
          double[][] arrayOfDouble2 = this.mY;
          paramArrayOffloat[j] = (float)(arrayOfDouble2[i][j] * (1.0D - paramDouble) + arrayOfDouble2[n][j] * paramDouble);
        } 
        return;
      } 
    } 
  }
  
  public double getSlope(double paramDouble, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mT : [D
    //   4: astore #11
    //   6: aload #11
    //   8: arraylength
    //   9: istore #10
    //   11: iconst_0
    //   12: istore #9
    //   14: aload #11
    //   16: iconst_0
    //   17: daload
    //   18: dstore #4
    //   20: dload_1
    //   21: dload #4
    //   23: dcmpg
    //   24: ifge -> 40
    //   27: dload #4
    //   29: dstore_1
    //   30: iload #9
    //   32: istore #8
    //   34: dload_1
    //   35: dstore #4
    //   37: goto -> 69
    //   40: aload #11
    //   42: iload #10
    //   44: iconst_1
    //   45: isub
    //   46: daload
    //   47: dstore #6
    //   49: iload #9
    //   51: istore #8
    //   53: dload_1
    //   54: dstore #4
    //   56: dload_1
    //   57: dload #6
    //   59: dcmpl
    //   60: iflt -> 69
    //   63: dload #6
    //   65: dstore_1
    //   66: goto -> 30
    //   69: iload #8
    //   71: iload #10
    //   73: iconst_1
    //   74: isub
    //   75: if_icmpge -> 148
    //   78: aload_0
    //   79: getfield mT : [D
    //   82: astore #11
    //   84: iload #8
    //   86: iconst_1
    //   87: iadd
    //   88: istore #9
    //   90: aload #11
    //   92: iload #9
    //   94: daload
    //   95: dstore_1
    //   96: dload #4
    //   98: dload_1
    //   99: dcmpg
    //   100: ifgt -> 141
    //   103: aload #11
    //   105: iload #8
    //   107: daload
    //   108: dstore #4
    //   110: aload_0
    //   111: getfield mY : [[D
    //   114: astore #11
    //   116: aload #11
    //   118: iload #8
    //   120: aaload
    //   121: iload_3
    //   122: daload
    //   123: dstore #6
    //   125: aload #11
    //   127: iload #9
    //   129: aaload
    //   130: iload_3
    //   131: daload
    //   132: dload #6
    //   134: dsub
    //   135: dload_1
    //   136: dload #4
    //   138: dsub
    //   139: ddiv
    //   140: dreturn
    //   141: iload #9
    //   143: istore #8
    //   145: goto -> 69
    //   148: dconst_0
    //   149: dreturn
  }
  
  public void getSlope(double paramDouble, double[] paramArrayOfdouble) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mT : [D
    //   4: astore #13
    //   6: aload #13
    //   8: arraylength
    //   9: istore #12
    //   11: aload_0
    //   12: getfield mY : [[D
    //   15: astore #14
    //   17: iconst_0
    //   18: istore #9
    //   20: aload #14
    //   22: iconst_0
    //   23: aaload
    //   24: arraylength
    //   25: istore #11
    //   27: aload #13
    //   29: iconst_0
    //   30: daload
    //   31: dstore #4
    //   33: dload_1
    //   34: dload #4
    //   36: dcmpg
    //   37: ifgt -> 49
    //   40: dload #4
    //   42: dstore_1
    //   43: dload_1
    //   44: dstore #4
    //   46: goto -> 74
    //   49: aload #13
    //   51: iload #12
    //   53: iconst_1
    //   54: isub
    //   55: daload
    //   56: dstore #6
    //   58: dload_1
    //   59: dstore #4
    //   61: dload_1
    //   62: dload #6
    //   64: dcmpl
    //   65: iflt -> 74
    //   68: dload #6
    //   70: dstore_1
    //   71: goto -> 43
    //   74: iconst_0
    //   75: istore #8
    //   77: iload #8
    //   79: iload #12
    //   81: iconst_1
    //   82: isub
    //   83: if_icmpge -> 177
    //   86: aload_0
    //   87: getfield mT : [D
    //   90: astore #13
    //   92: iload #8
    //   94: iconst_1
    //   95: iadd
    //   96: istore #10
    //   98: aload #13
    //   100: iload #10
    //   102: daload
    //   103: dstore_1
    //   104: dload #4
    //   106: dload_1
    //   107: dcmpg
    //   108: ifgt -> 170
    //   111: aload #13
    //   113: iload #8
    //   115: daload
    //   116: dstore #4
    //   118: iload #9
    //   120: iload #11
    //   122: if_icmpge -> 177
    //   125: aload_0
    //   126: getfield mY : [[D
    //   129: astore #13
    //   131: aload #13
    //   133: iload #8
    //   135: aaload
    //   136: iload #9
    //   138: daload
    //   139: dstore #6
    //   141: aload_3
    //   142: iload #9
    //   144: aload #13
    //   146: iload #10
    //   148: aaload
    //   149: iload #9
    //   151: daload
    //   152: dload #6
    //   154: dsub
    //   155: dload_1
    //   156: dload #4
    //   158: dsub
    //   159: ddiv
    //   160: dastore
    //   161: iload #9
    //   163: iconst_1
    //   164: iadd
    //   165: istore #9
    //   167: goto -> 118
    //   170: iload #10
    //   172: istore #8
    //   174: goto -> 77
    //   177: return
  }
  
  public double[] getTimePoints() {
    return this.mT;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\LinearCurveFit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */