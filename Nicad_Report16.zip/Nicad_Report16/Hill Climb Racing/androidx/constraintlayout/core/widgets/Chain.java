package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;

public class Chain {
  private static final boolean DEBUG = false;
  
  public static final boolean USE_CHAIN_OPTIMIZATION = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: iload_2
    //   1: istore #17
    //   3: aload #4
    //   5: getfield mFirst : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   8: astore #23
    //   10: aload #4
    //   12: getfield mLast : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   15: astore #27
    //   17: aload #4
    //   19: getfield mFirstVisibleWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   22: astore #18
    //   24: aload #4
    //   26: getfield mLastVisibleWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   29: astore #25
    //   31: aload #4
    //   33: getfield mHead : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   36: astore #20
    //   38: aload #4
    //   40: getfield mTotalWeight : F
    //   43: fstore #5
    //   45: aload #4
    //   47: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   50: astore #19
    //   52: aload #4
    //   54: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   57: astore #19
    //   59: aload_0
    //   60: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   63: iload #17
    //   65: aaload
    //   66: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   69: if_acmpne -> 78
    //   72: iconst_1
    //   73: istore #13
    //   75: goto -> 81
    //   78: iconst_0
    //   79: istore #13
    //   81: iload #17
    //   83: ifne -> 141
    //   86: aload #20
    //   88: getfield mHorizontalChainStyle : I
    //   91: ifne -> 100
    //   94: iconst_1
    //   95: istore #8
    //   97: goto -> 103
    //   100: iconst_0
    //   101: istore #8
    //   103: aload #20
    //   105: getfield mHorizontalChainStyle : I
    //   108: iconst_1
    //   109: if_icmpne -> 118
    //   112: iconst_1
    //   113: istore #9
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #9
    //   121: iload #8
    //   123: istore #10
    //   125: iload #9
    //   127: istore #11
    //   129: aload #20
    //   131: getfield mHorizontalChainStyle : I
    //   134: iconst_2
    //   135: if_icmpne -> 207
    //   138: goto -> 193
    //   141: aload #20
    //   143: getfield mVerticalChainStyle : I
    //   146: ifne -> 155
    //   149: iconst_1
    //   150: istore #8
    //   152: goto -> 158
    //   155: iconst_0
    //   156: istore #8
    //   158: aload #20
    //   160: getfield mVerticalChainStyle : I
    //   163: iconst_1
    //   164: if_icmpne -> 173
    //   167: iconst_1
    //   168: istore #9
    //   170: goto -> 176
    //   173: iconst_0
    //   174: istore #9
    //   176: iload #8
    //   178: istore #10
    //   180: iload #9
    //   182: istore #11
    //   184: aload #20
    //   186: getfield mVerticalChainStyle : I
    //   189: iconst_2
    //   190: if_icmpne -> 207
    //   193: iconst_1
    //   194: istore #14
    //   196: iload #8
    //   198: istore #10
    //   200: iload #9
    //   202: istore #11
    //   204: goto -> 210
    //   207: iconst_0
    //   208: istore #14
    //   210: iconst_0
    //   211: istore #8
    //   213: aload #23
    //   215: astore #21
    //   217: iload #10
    //   219: istore #12
    //   221: aconst_null
    //   222: astore #26
    //   224: aconst_null
    //   225: astore #22
    //   227: iload #8
    //   229: ifne -> 672
    //   232: aload #21
    //   234: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   237: iload_3
    //   238: aaload
    //   239: astore #19
    //   241: iload #14
    //   243: ifeq -> 252
    //   246: iconst_1
    //   247: istore #9
    //   249: goto -> 255
    //   252: iconst_4
    //   253: istore #9
    //   255: aload #19
    //   257: invokevirtual getMargin : ()I
    //   260: istore #10
    //   262: aload #21
    //   264: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: iload #17
    //   269: aaload
    //   270: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   273: if_acmpne -> 293
    //   276: aload #21
    //   278: getfield mResolvedMatchConstraintDefault : [I
    //   281: iload #17
    //   283: iaload
    //   284: ifne -> 293
    //   287: iconst_1
    //   288: istore #16
    //   290: goto -> 296
    //   293: iconst_0
    //   294: istore #16
    //   296: iload #10
    //   298: istore #15
    //   300: aload #19
    //   302: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   305: ifnull -> 332
    //   308: iload #10
    //   310: istore #15
    //   312: aload #21
    //   314: aload #23
    //   316: if_acmpeq -> 332
    //   319: iload #10
    //   321: aload #19
    //   323: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   326: invokevirtual getMargin : ()I
    //   329: iadd
    //   330: istore #15
    //   332: iload #14
    //   334: ifeq -> 358
    //   337: aload #21
    //   339: aload #23
    //   341: if_acmpeq -> 358
    //   344: aload #21
    //   346: aload #18
    //   348: if_acmpeq -> 358
    //   351: bipush #8
    //   353: istore #9
    //   355: goto -> 358
    //   358: aload #19
    //   360: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   363: ifnull -> 492
    //   366: aload #21
    //   368: aload #18
    //   370: if_acmpne -> 397
    //   373: aload_1
    //   374: aload #19
    //   376: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   379: aload #19
    //   381: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   384: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   387: iload #15
    //   389: bipush #6
    //   391: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   394: goto -> 418
    //   397: aload_1
    //   398: aload #19
    //   400: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   403: aload #19
    //   405: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   408: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   411: iload #15
    //   413: bipush #8
    //   415: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   418: iload #9
    //   420: istore #10
    //   422: iload #16
    //   424: ifeq -> 439
    //   427: iload #9
    //   429: istore #10
    //   431: iload #14
    //   433: ifne -> 439
    //   436: iconst_5
    //   437: istore #10
    //   439: aload #21
    //   441: aload #18
    //   443: if_acmpne -> 467
    //   446: iload #14
    //   448: ifeq -> 467
    //   451: aload #21
    //   453: iload #17
    //   455: invokevirtual isInBarrier : (I)Z
    //   458: ifeq -> 467
    //   461: iconst_5
    //   462: istore #10
    //   464: goto -> 467
    //   467: aload_1
    //   468: aload #19
    //   470: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   473: aload #19
    //   475: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   478: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   481: iload #15
    //   483: iload #10
    //   485: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   488: pop
    //   489: goto -> 492
    //   492: iload #13
    //   494: ifeq -> 578
    //   497: aload #21
    //   499: invokevirtual getVisibility : ()I
    //   502: bipush #8
    //   504: if_icmpeq -> 552
    //   507: aload #21
    //   509: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   512: iload #17
    //   514: aaload
    //   515: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   518: if_acmpne -> 552
    //   521: aload_1
    //   522: aload #21
    //   524: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   527: iload_3
    //   528: iconst_1
    //   529: iadd
    //   530: aaload
    //   531: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   534: aload #21
    //   536: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   539: iload_3
    //   540: aaload
    //   541: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   544: iconst_0
    //   545: iconst_5
    //   546: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   549: goto -> 552
    //   552: aload_1
    //   553: aload #21
    //   555: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   558: iload_3
    //   559: aaload
    //   560: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   563: aload_0
    //   564: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   567: iload_3
    //   568: aaload
    //   569: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   572: iconst_0
    //   573: bipush #8
    //   575: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   578: aload #21
    //   580: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   583: iload_3
    //   584: iconst_1
    //   585: iadd
    //   586: aaload
    //   587: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   590: astore #24
    //   592: aload #22
    //   594: astore #19
    //   596: aload #24
    //   598: ifnull -> 654
    //   601: aload #24
    //   603: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   606: astore #24
    //   608: aload #22
    //   610: astore #19
    //   612: aload #24
    //   614: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   617: iload_3
    //   618: aaload
    //   619: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   622: ifnull -> 654
    //   625: aload #24
    //   627: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   630: iload_3
    //   631: aaload
    //   632: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   635: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   638: aload #21
    //   640: if_acmpeq -> 650
    //   643: aload #22
    //   645: astore #19
    //   647: goto -> 654
    //   650: aload #24
    //   652: astore #19
    //   654: aload #19
    //   656: ifnull -> 666
    //   659: aload #19
    //   661: astore #21
    //   663: goto -> 669
    //   666: iconst_1
    //   667: istore #8
    //   669: goto -> 221
    //   672: aload #25
    //   674: ifnull -> 870
    //   677: aload #27
    //   679: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   682: astore #19
    //   684: iload_3
    //   685: iconst_1
    //   686: iadd
    //   687: istore #9
    //   689: aload #19
    //   691: iload #9
    //   693: aaload
    //   694: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   697: ifnull -> 870
    //   700: aload #25
    //   702: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   705: iload #9
    //   707: aaload
    //   708: astore #19
    //   710: aload #25
    //   712: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   715: iload #17
    //   717: aaload
    //   718: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   721: if_acmpne -> 741
    //   724: aload #25
    //   726: getfield mResolvedMatchConstraintDefault : [I
    //   729: iload #17
    //   731: iaload
    //   732: ifne -> 741
    //   735: iconst_1
    //   736: istore #8
    //   738: goto -> 744
    //   741: iconst_0
    //   742: istore #8
    //   744: iload #8
    //   746: ifeq -> 794
    //   749: iload #14
    //   751: ifne -> 794
    //   754: aload #19
    //   756: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   759: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   762: aload_0
    //   763: if_acmpne -> 794
    //   766: aload_1
    //   767: aload #19
    //   769: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   772: aload #19
    //   774: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   777: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   780: aload #19
    //   782: invokevirtual getMargin : ()I
    //   785: ineg
    //   786: iconst_5
    //   787: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   790: pop
    //   791: goto -> 836
    //   794: iload #14
    //   796: ifeq -> 836
    //   799: aload #19
    //   801: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   804: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   807: aload_0
    //   808: if_acmpne -> 836
    //   811: aload_1
    //   812: aload #19
    //   814: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   817: aload #19
    //   819: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   822: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   825: aload #19
    //   827: invokevirtual getMargin : ()I
    //   830: ineg
    //   831: iconst_4
    //   832: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   835: pop
    //   836: aload_1
    //   837: aload #19
    //   839: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   842: aload #27
    //   844: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   847: iload #9
    //   849: aaload
    //   850: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   853: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   856: aload #19
    //   858: invokevirtual getMargin : ()I
    //   861: ineg
    //   862: bipush #6
    //   864: invokevirtual addLowerThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   867: goto -> 870
    //   870: iload #13
    //   872: ifeq -> 920
    //   875: aload_0
    //   876: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   879: astore_0
    //   880: iload_3
    //   881: iconst_1
    //   882: iadd
    //   883: istore #8
    //   885: aload_1
    //   886: aload_0
    //   887: iload #8
    //   889: aaload
    //   890: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   893: aload #27
    //   895: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   898: iload #8
    //   900: aaload
    //   901: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   904: aload #27
    //   906: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   909: iload #8
    //   911: aaload
    //   912: invokevirtual getMargin : ()I
    //   915: bipush #8
    //   917: invokevirtual addGreaterThan : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   920: aload #4
    //   922: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   925: astore_0
    //   926: aload_0
    //   927: ifnull -> 1223
    //   930: aload_0
    //   931: invokevirtual size : ()I
    //   934: istore #8
    //   936: iload #8
    //   938: iconst_1
    //   939: if_icmple -> 1223
    //   942: aload #4
    //   944: getfield mHasUndefinedWeights : Z
    //   947: ifeq -> 969
    //   950: aload #4
    //   952: getfield mHasComplexMatchWeights : Z
    //   955: ifne -> 969
    //   958: aload #4
    //   960: getfield mWidgetsMatchCount : I
    //   963: i2f
    //   964: fstore #6
    //   966: goto -> 973
    //   969: fload #5
    //   971: fstore #6
    //   973: aconst_null
    //   974: astore #19
    //   976: iconst_0
    //   977: istore #9
    //   979: fconst_0
    //   980: fstore #7
    //   982: iload #9
    //   984: iload #8
    //   986: if_icmpge -> 1223
    //   989: aload_0
    //   990: iload #9
    //   992: invokevirtual get : (I)Ljava/lang/Object;
    //   995: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   998: astore #21
    //   1000: aload #21
    //   1002: getfield mWeight : [F
    //   1005: iload #17
    //   1007: faload
    //   1008: fstore #5
    //   1010: fload #5
    //   1012: fconst_0
    //   1013: fcmpg
    //   1014: ifge -> 1063
    //   1017: aload #4
    //   1019: getfield mHasComplexMatchWeights : Z
    //   1022: ifeq -> 1057
    //   1025: aload_1
    //   1026: aload #21
    //   1028: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1031: iload_3
    //   1032: iconst_1
    //   1033: iadd
    //   1034: aaload
    //   1035: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1038: aload #21
    //   1040: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1043: iload_3
    //   1044: aaload
    //   1045: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1048: iconst_0
    //   1049: iconst_4
    //   1050: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1053: pop
    //   1054: goto -> 1100
    //   1057: fconst_1
    //   1058: fstore #5
    //   1060: goto -> 1063
    //   1063: fload #5
    //   1065: fconst_0
    //   1066: fcmpl
    //   1067: ifne -> 1107
    //   1070: aload_1
    //   1071: aload #21
    //   1073: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1076: iload_3
    //   1077: iconst_1
    //   1078: iadd
    //   1079: aaload
    //   1080: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1083: aload #21
    //   1085: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1088: iload_3
    //   1089: aaload
    //   1090: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1093: iconst_0
    //   1094: bipush #8
    //   1096: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1099: pop
    //   1100: fload #7
    //   1102: fstore #5
    //   1104: goto -> 1210
    //   1107: aload #19
    //   1109: ifnull -> 1206
    //   1112: aload #19
    //   1114: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1117: iload_3
    //   1118: aaload
    //   1119: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1122: astore #22
    //   1124: aload #19
    //   1126: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1129: astore #19
    //   1131: iload_3
    //   1132: iconst_1
    //   1133: iadd
    //   1134: istore #10
    //   1136: aload #19
    //   1138: iload #10
    //   1140: aaload
    //   1141: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1144: astore #19
    //   1146: aload #21
    //   1148: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1151: iload_3
    //   1152: aaload
    //   1153: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1156: astore #24
    //   1158: aload #21
    //   1160: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1163: iload #10
    //   1165: aaload
    //   1166: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1169: astore #28
    //   1171: aload_1
    //   1172: invokevirtual createRow : ()Landroidx/constraintlayout/core/ArrayRow;
    //   1175: astore #29
    //   1177: aload #29
    //   1179: fload #7
    //   1181: fload #6
    //   1183: fload #5
    //   1185: aload #22
    //   1187: aload #19
    //   1189: aload #24
    //   1191: aload #28
    //   1193: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;)Landroidx/constraintlayout/core/ArrayRow;
    //   1196: pop
    //   1197: aload_1
    //   1198: aload #29
    //   1200: invokevirtual addConstraint : (Landroidx/constraintlayout/core/ArrayRow;)V
    //   1203: goto -> 1206
    //   1206: aload #21
    //   1208: astore #19
    //   1210: iload #9
    //   1212: iconst_1
    //   1213: iadd
    //   1214: istore #9
    //   1216: fload #5
    //   1218: fstore #7
    //   1220: goto -> 982
    //   1223: aload #18
    //   1225: ifnull -> 1403
    //   1228: aload #18
    //   1230: aload #25
    //   1232: if_acmpeq -> 1240
    //   1235: iload #14
    //   1237: ifeq -> 1403
    //   1240: aload #23
    //   1242: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1245: iload_3
    //   1246: aaload
    //   1247: astore_0
    //   1248: aload #27
    //   1250: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1253: astore #4
    //   1255: iload_3
    //   1256: iconst_1
    //   1257: iadd
    //   1258: istore_2
    //   1259: aload #4
    //   1261: iload_2
    //   1262: aaload
    //   1263: astore #19
    //   1265: aload_0
    //   1266: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1269: ifnull -> 1283
    //   1272: aload_0
    //   1273: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1276: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1279: astore_0
    //   1280: goto -> 1285
    //   1283: aconst_null
    //   1284: astore_0
    //   1285: aload #19
    //   1287: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1290: ifnull -> 1306
    //   1293: aload #19
    //   1295: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1298: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1301: astore #4
    //   1303: goto -> 1309
    //   1306: aconst_null
    //   1307: astore #4
    //   1309: aload #18
    //   1311: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1314: iload_3
    //   1315: aaload
    //   1316: astore #21
    //   1318: aload #25
    //   1320: ifnull -> 1332
    //   1323: aload #25
    //   1325: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1328: iload_2
    //   1329: aaload
    //   1330: astore #19
    //   1332: aload_0
    //   1333: ifnull -> 2434
    //   1336: aload #4
    //   1338: ifnull -> 2434
    //   1341: iload #17
    //   1343: ifne -> 1356
    //   1346: aload #20
    //   1348: getfield mHorizontalBiasPercent : F
    //   1351: fstore #5
    //   1353: goto -> 1363
    //   1356: aload #20
    //   1358: getfield mVerticalBiasPercent : F
    //   1361: fstore #5
    //   1363: aload #21
    //   1365: invokevirtual getMargin : ()I
    //   1368: istore_2
    //   1369: aload #19
    //   1371: invokevirtual getMargin : ()I
    //   1374: istore #8
    //   1376: aload_1
    //   1377: aload #21
    //   1379: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1382: aload_0
    //   1383: iload_2
    //   1384: fload #5
    //   1386: aload #4
    //   1388: aload #19
    //   1390: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1393: iload #8
    //   1395: bipush #7
    //   1397: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1400: goto -> 2434
    //   1403: iload #12
    //   1405: ifeq -> 1867
    //   1408: aload #18
    //   1410: ifnull -> 1867
    //   1413: aload #4
    //   1415: getfield mWidgetsMatchCount : I
    //   1418: ifle -> 1440
    //   1421: aload #4
    //   1423: getfield mWidgetsCount : I
    //   1426: aload #4
    //   1428: getfield mWidgetsMatchCount : I
    //   1431: if_icmpne -> 1440
    //   1434: iconst_1
    //   1435: istore #8
    //   1437: goto -> 1443
    //   1440: iconst_0
    //   1441: istore #8
    //   1443: aload #18
    //   1445: astore #19
    //   1447: aload #19
    //   1449: astore #20
    //   1451: aload #20
    //   1453: ifnull -> 2434
    //   1456: aload #20
    //   1458: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1461: iload #17
    //   1463: aaload
    //   1464: astore_0
    //   1465: aload_0
    //   1466: ifnull -> 1489
    //   1469: aload_0
    //   1470: invokevirtual getVisibility : ()I
    //   1473: bipush #8
    //   1475: if_icmpne -> 1489
    //   1478: aload_0
    //   1479: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1482: iload #17
    //   1484: aaload
    //   1485: astore_0
    //   1486: goto -> 1465
    //   1489: aload_0
    //   1490: ifnonnull -> 1506
    //   1493: aload #20
    //   1495: aload #25
    //   1497: if_acmpne -> 1503
    //   1500: goto -> 1506
    //   1503: goto -> 1840
    //   1506: aload #20
    //   1508: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1511: iload_3
    //   1512: aaload
    //   1513: astore #21
    //   1515: aload #21
    //   1517: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1520: astore #24
    //   1522: aload #21
    //   1524: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1527: ifnull -> 1543
    //   1530: aload #21
    //   1532: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1535: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1538: astore #4
    //   1540: goto -> 1546
    //   1543: aconst_null
    //   1544: astore #4
    //   1546: aload #19
    //   1548: aload #20
    //   1550: if_acmpeq -> 1570
    //   1553: aload #19
    //   1555: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1558: iload_3
    //   1559: iconst_1
    //   1560: iadd
    //   1561: aaload
    //   1562: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1565: astore #4
    //   1567: goto -> 1611
    //   1570: aload #20
    //   1572: aload #18
    //   1574: if_acmpne -> 1611
    //   1577: aload #23
    //   1579: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1582: iload_3
    //   1583: aaload
    //   1584: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1587: ifnull -> 1608
    //   1590: aload #23
    //   1592: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1595: iload_3
    //   1596: aaload
    //   1597: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1600: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1603: astore #4
    //   1605: goto -> 1611
    //   1608: aconst_null
    //   1609: astore #4
    //   1611: aload #21
    //   1613: invokevirtual getMargin : ()I
    //   1616: istore #13
    //   1618: aload #20
    //   1620: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1623: astore #21
    //   1625: iload_3
    //   1626: iconst_1
    //   1627: iadd
    //   1628: istore #10
    //   1630: aload #21
    //   1632: iload #10
    //   1634: aaload
    //   1635: invokevirtual getMargin : ()I
    //   1638: istore #9
    //   1640: aload_0
    //   1641: ifnull -> 1662
    //   1644: aload_0
    //   1645: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1648: iload_3
    //   1649: aaload
    //   1650: astore #22
    //   1652: aload #22
    //   1654: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1657: astore #21
    //   1659: goto -> 1693
    //   1662: aload #27
    //   1664: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1667: iload #10
    //   1669: aaload
    //   1670: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1673: astore #22
    //   1675: aload #22
    //   1677: ifnull -> 1690
    //   1680: aload #22
    //   1682: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1685: astore #21
    //   1687: goto -> 1659
    //   1690: aconst_null
    //   1691: astore #21
    //   1693: aload #20
    //   1695: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1698: iload #10
    //   1700: aaload
    //   1701: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1704: astore #28
    //   1706: iload #9
    //   1708: istore_2
    //   1709: aload #22
    //   1711: ifnull -> 1723
    //   1714: iload #9
    //   1716: aload #22
    //   1718: invokevirtual getMargin : ()I
    //   1721: iadd
    //   1722: istore_2
    //   1723: iload #13
    //   1725: aload #19
    //   1727: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1730: iload #10
    //   1732: aaload
    //   1733: invokevirtual getMargin : ()I
    //   1736: iadd
    //   1737: istore #9
    //   1739: aload #24
    //   1741: ifnull -> 1837
    //   1744: aload #4
    //   1746: ifnull -> 1837
    //   1749: aload #21
    //   1751: ifnull -> 1837
    //   1754: aload #28
    //   1756: ifnull -> 1837
    //   1759: aload #20
    //   1761: aload #18
    //   1763: if_acmpne -> 1778
    //   1766: aload #18
    //   1768: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1771: iload_3
    //   1772: aaload
    //   1773: invokevirtual getMargin : ()I
    //   1776: istore #9
    //   1778: aload #20
    //   1780: aload #25
    //   1782: if_acmpne -> 1800
    //   1785: aload #25
    //   1787: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1790: iload #10
    //   1792: aaload
    //   1793: invokevirtual getMargin : ()I
    //   1796: istore_2
    //   1797: goto -> 1800
    //   1800: iload #8
    //   1802: ifeq -> 1812
    //   1805: bipush #8
    //   1807: istore #10
    //   1809: goto -> 1815
    //   1812: iconst_5
    //   1813: istore #10
    //   1815: aload_1
    //   1816: aload #24
    //   1818: aload #4
    //   1820: iload #9
    //   1822: ldc 0.5
    //   1824: aload #21
    //   1826: aload #28
    //   1828: iload_2
    //   1829: iload #10
    //   1831: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   1834: goto -> 1840
    //   1837: goto -> 1503
    //   1840: aload #20
    //   1842: invokevirtual getVisibility : ()I
    //   1845: bipush #8
    //   1847: if_icmpeq -> 1853
    //   1850: goto -> 1857
    //   1853: aload #19
    //   1855: astore #20
    //   1857: aload #20
    //   1859: astore #19
    //   1861: aload_0
    //   1862: astore #20
    //   1864: goto -> 1451
    //   1867: iload #11
    //   1869: ifeq -> 2434
    //   1872: aload #18
    //   1874: ifnull -> 2434
    //   1877: aload #4
    //   1879: getfield mWidgetsMatchCount : I
    //   1882: ifle -> 1904
    //   1885: aload #4
    //   1887: getfield mWidgetsCount : I
    //   1890: aload #4
    //   1892: getfield mWidgetsMatchCount : I
    //   1895: if_icmpne -> 1904
    //   1898: iconst_1
    //   1899: istore #8
    //   1901: goto -> 1907
    //   1904: iconst_0
    //   1905: istore #8
    //   1907: aload #18
    //   1909: astore #4
    //   1911: aload #4
    //   1913: astore #19
    //   1915: iload_2
    //   1916: istore #9
    //   1918: aload #19
    //   1920: ifnull -> 2274
    //   1923: aload #19
    //   1925: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1928: iload #9
    //   1930: aaload
    //   1931: astore_0
    //   1932: aload_0
    //   1933: ifnull -> 1956
    //   1936: aload_0
    //   1937: invokevirtual getVisibility : ()I
    //   1940: bipush #8
    //   1942: if_icmpne -> 1956
    //   1945: aload_0
    //   1946: getfield mNextChainWidget : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1949: iload #9
    //   1951: aaload
    //   1952: astore_0
    //   1953: goto -> 1932
    //   1956: aload #19
    //   1958: aload #18
    //   1960: if_acmpeq -> 2251
    //   1963: aload #19
    //   1965: aload #25
    //   1967: if_acmpeq -> 2251
    //   1970: aload_0
    //   1971: ifnull -> 2251
    //   1974: aload_0
    //   1975: aload #25
    //   1977: if_acmpne -> 1985
    //   1980: aconst_null
    //   1981: astore_0
    //   1982: goto -> 1985
    //   1985: aload #19
    //   1987: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1990: iload_3
    //   1991: aaload
    //   1992: astore #20
    //   1994: aload #20
    //   1996: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1999: astore #28
    //   2001: aload #20
    //   2003: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2006: ifnull -> 2019
    //   2009: aload #20
    //   2011: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2014: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2017: astore #21
    //   2019: aload #4
    //   2021: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2024: astore #21
    //   2026: iload_3
    //   2027: iconst_1
    //   2028: iadd
    //   2029: istore #14
    //   2031: aload #21
    //   2033: iload #14
    //   2035: aaload
    //   2036: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2039: astore #29
    //   2041: aload #20
    //   2043: invokevirtual getMargin : ()I
    //   2046: istore #13
    //   2048: aload #19
    //   2050: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2053: iload #14
    //   2055: aaload
    //   2056: invokevirtual getMargin : ()I
    //   2059: istore #10
    //   2061: aload_0
    //   2062: ifnull -> 2111
    //   2065: aload_0
    //   2066: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2069: iload_3
    //   2070: aaload
    //   2071: astore #21
    //   2073: aload #21
    //   2075: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2078: astore #22
    //   2080: aload #21
    //   2082: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2085: ifnull -> 2101
    //   2088: aload #21
    //   2090: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2093: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2096: astore #20
    //   2098: goto -> 2104
    //   2101: aconst_null
    //   2102: astore #20
    //   2104: aload #20
    //   2106: astore #24
    //   2108: goto -> 2155
    //   2111: aload #25
    //   2113: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2116: iload_3
    //   2117: aaload
    //   2118: astore #21
    //   2120: aload #21
    //   2122: ifnull -> 2135
    //   2125: aload #21
    //   2127: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2130: astore #20
    //   2132: goto -> 2138
    //   2135: aconst_null
    //   2136: astore #20
    //   2138: aload #19
    //   2140: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2143: iload #14
    //   2145: aaload
    //   2146: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2149: astore #24
    //   2151: aload #20
    //   2153: astore #22
    //   2155: iload #10
    //   2157: istore #9
    //   2159: aload #21
    //   2161: ifnull -> 2174
    //   2164: iload #10
    //   2166: aload #21
    //   2168: invokevirtual getMargin : ()I
    //   2171: iadd
    //   2172: istore #9
    //   2174: aload #4
    //   2176: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2179: iload #14
    //   2181: aaload
    //   2182: invokevirtual getMargin : ()I
    //   2185: istore #14
    //   2187: iload #8
    //   2189: ifeq -> 2199
    //   2192: bipush #8
    //   2194: istore #10
    //   2196: goto -> 2202
    //   2199: iconst_4
    //   2200: istore #10
    //   2202: aload #28
    //   2204: ifnull -> 2248
    //   2207: aload #29
    //   2209: ifnull -> 2248
    //   2212: aload #22
    //   2214: ifnull -> 2248
    //   2217: aload #24
    //   2219: ifnull -> 2248
    //   2222: aload_1
    //   2223: aload #28
    //   2225: aload #29
    //   2227: iload #14
    //   2229: iload #13
    //   2231: iadd
    //   2232: ldc 0.5
    //   2234: aload #22
    //   2236: aload #24
    //   2238: iload #9
    //   2240: iload #10
    //   2242: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2245: goto -> 2248
    //   2248: goto -> 2251
    //   2251: aload #19
    //   2253: invokevirtual getVisibility : ()I
    //   2256: bipush #8
    //   2258: if_icmpeq -> 2268
    //   2261: aload #19
    //   2263: astore #4
    //   2265: goto -> 2268
    //   2268: aload_0
    //   2269: astore #19
    //   2271: goto -> 1915
    //   2274: aload #18
    //   2276: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2279: iload_3
    //   2280: aaload
    //   2281: astore_0
    //   2282: aload #23
    //   2284: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2287: iload_3
    //   2288: aaload
    //   2289: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2292: astore #4
    //   2294: aload #25
    //   2296: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2299: astore #19
    //   2301: iload_3
    //   2302: iconst_1
    //   2303: iadd
    //   2304: istore_2
    //   2305: aload #19
    //   2307: iload_2
    //   2308: aaload
    //   2309: astore #19
    //   2311: aload #27
    //   2313: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2316: iload_2
    //   2317: aaload
    //   2318: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2321: astore #20
    //   2323: aload #4
    //   2325: ifnull -> 2400
    //   2328: aload #18
    //   2330: aload #25
    //   2332: if_acmpeq -> 2357
    //   2335: aload_1
    //   2336: aload_0
    //   2337: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2340: aload #4
    //   2342: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2345: aload_0
    //   2346: invokevirtual getMargin : ()I
    //   2349: iconst_5
    //   2350: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2353: pop
    //   2354: goto -> 2400
    //   2357: aload #20
    //   2359: ifnull -> 2400
    //   2362: aload_1
    //   2363: aload_0
    //   2364: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2367: aload #4
    //   2369: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2372: aload_0
    //   2373: invokevirtual getMargin : ()I
    //   2376: ldc 0.5
    //   2378: aload #19
    //   2380: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2383: aload #20
    //   2385: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2388: aload #19
    //   2390: invokevirtual getMargin : ()I
    //   2393: iconst_5
    //   2394: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2397: goto -> 2400
    //   2400: aload #20
    //   2402: ifnull -> 2434
    //   2405: aload #18
    //   2407: aload #25
    //   2409: if_acmpeq -> 2434
    //   2412: aload_1
    //   2413: aload #19
    //   2415: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2418: aload #20
    //   2420: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2423: aload #19
    //   2425: invokevirtual getMargin : ()I
    //   2428: ineg
    //   2429: iconst_5
    //   2430: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   2433: pop
    //   2434: iload #12
    //   2436: ifne -> 2444
    //   2439: iload #11
    //   2441: ifeq -> 2651
    //   2444: aload #18
    //   2446: ifnull -> 2651
    //   2449: aload #18
    //   2451: aload #25
    //   2453: if_acmpeq -> 2651
    //   2456: aload #18
    //   2458: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2461: iload_3
    //   2462: aaload
    //   2463: astore #20
    //   2465: aload #25
    //   2467: astore #4
    //   2469: aload #25
    //   2471: ifnonnull -> 2478
    //   2474: aload #18
    //   2476: astore #4
    //   2478: aload #4
    //   2480: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2483: astore_0
    //   2484: iload_3
    //   2485: iconst_1
    //   2486: iadd
    //   2487: istore_2
    //   2488: aload_0
    //   2489: iload_2
    //   2490: aaload
    //   2491: astore #21
    //   2493: aload #20
    //   2495: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2498: ifnull -> 2514
    //   2501: aload #20
    //   2503: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2506: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2509: astore #19
    //   2511: goto -> 2517
    //   2514: aconst_null
    //   2515: astore #19
    //   2517: aload #21
    //   2519: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2522: ifnull -> 2537
    //   2525: aload #21
    //   2527: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2530: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2533: astore_0
    //   2534: goto -> 2539
    //   2537: aconst_null
    //   2538: astore_0
    //   2539: aload #27
    //   2541: aload #4
    //   2543: if_acmpeq -> 2578
    //   2546: aload #27
    //   2548: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2551: iload_2
    //   2552: aaload
    //   2553: astore #22
    //   2555: aload #26
    //   2557: astore_0
    //   2558: aload #22
    //   2560: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2563: ifnull -> 2575
    //   2566: aload #22
    //   2568: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2571: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2574: astore_0
    //   2575: goto -> 2578
    //   2578: aload #18
    //   2580: aload #4
    //   2582: if_acmpne -> 2603
    //   2585: aload #18
    //   2587: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2590: iload_3
    //   2591: aaload
    //   2592: astore #20
    //   2594: aload #18
    //   2596: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2599: iload_2
    //   2600: aaload
    //   2601: astore #21
    //   2603: aload #19
    //   2605: ifnull -> 2651
    //   2608: aload_0
    //   2609: ifnull -> 2651
    //   2612: aload #20
    //   2614: invokevirtual getMargin : ()I
    //   2617: istore_3
    //   2618: aload #4
    //   2620: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   2623: iload_2
    //   2624: aaload
    //   2625: invokevirtual getMargin : ()I
    //   2628: istore_2
    //   2629: aload_1
    //   2630: aload #20
    //   2632: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2635: aload #19
    //   2637: iload_3
    //   2638: ldc 0.5
    //   2640: aload_0
    //   2641: aload #21
    //   2643: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   2646: iload_2
    //   2647: iconst_5
    //   2648: invokevirtual addCentering : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IFLandroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)V
    //   2651: return
  }
  
  public static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, ArrayList<ConstraintWidget> paramArrayList, int paramInt) {
    int i;
    byte b;
    ChainHead[] arrayOfChainHead;
    int j = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b = 0;
    } else {
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
      b = 2;
    } 
    while (j < i) {
      ChainHead chainHead = arrayOfChainHead[j];
      chainHead.define();
      if (paramArrayList == null || (paramArrayList != null && paramArrayList.contains(chainHead.mFirst)))
        applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b, chainHead); 
      j++;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */