package androidx.constraintlayout.core.state.helpers;

import androidx.constraintlayout.core.state.ConstraintReference;
import androidx.constraintlayout.core.state.State;
import java.util.Iterator;

public class HorizontalChainReference extends ChainReference {
  public HorizontalChainReference(State paramState) {
    super(paramState, State.Helper.HORIZONTAL_CHAIN);
  }
  
  public void apply() {
    for (Object object : this.mReferences)
      this.mState.constraints(object).clearHorizontal(); 
    Iterator<Object> iterator = this.mReferences.iterator();
    ConstraintReference constraintReference1 = null;
    ConstraintReference constraintReference2;
    for (constraintReference2 = null; iterator.hasNext(); constraintReference2 = constraintReference4) {
      ConstraintReference constraintReference3 = (ConstraintReference)iterator.next();
      constraintReference3 = this.mState.constraints(constraintReference3);
      ConstraintReference constraintReference4 = constraintReference2;
      if (constraintReference2 == null) {
        if (this.mStartToStart != null) {
          constraintReference3.startToStart(this.mStartToStart).margin(this.mMarginStart);
        } else if (this.mStartToEnd != null) {
          constraintReference3.startToEnd(this.mStartToEnd).margin(this.mMarginStart);
        } else {
          constraintReference3.startToStart(State.PARENT);
        } 
        constraintReference4 = constraintReference3;
      } 
      if (constraintReference1 != null) {
        constraintReference1.endToStart(constraintReference3.getKey());
        constraintReference3.startToEnd(constraintReference1.getKey());
      } 
      constraintReference1 = constraintReference3;
    } 
    if (constraintReference1 != null)
      if (this.mEndToStart != null) {
        constraintReference1.endToStart(this.mEndToStart).margin(this.mMarginEnd);
      } else if (this.mEndToEnd != null) {
        constraintReference1.endToEnd(this.mEndToEnd).margin(this.mMarginEnd);
      } else {
        constraintReference1.endToEnd(State.PARENT);
      }  
    if (constraintReference2 == null)
      return; 
    if (this.mBias != 0.5F)
      constraintReference2.horizontalBias(this.mBias); 
    int i = null.$SwitchMap$androidx$constraintlayout$core$state$State$Chain[this.mStyle.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3)
          return; 
        constraintReference2.setHorizontalChainStyle(2);
        return;
      } 
      constraintReference2.setHorizontalChainStyle(1);
      return;
    } 
    constraintReference2.setHorizontalChainStyle(0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\core\state\helpers\HorizontalChainReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */