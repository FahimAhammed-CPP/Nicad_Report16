package androidx.constraintlayout.widget;

public abstract class ConstraintsChangedListener {
  public void postLayoutChange(int paramInt1, int paramInt2) {}
  
  public void preLayoutChange(int paramInt1, int paramInt2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintsChangedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */