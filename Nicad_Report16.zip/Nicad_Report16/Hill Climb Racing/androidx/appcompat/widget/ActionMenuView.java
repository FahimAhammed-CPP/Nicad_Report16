package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;

public class ActionMenuView extends LinearLayoutCompat implements MenuBuilder.ItemInvoker, MenuView {
  static final int GENERATED_ITEM_PADDING = 4;
  
  static final int MIN_CELL_SIZE = 56;
  
  private static final String TAG = "ActionMenuView";
  
  private MenuPresenter.Callback mActionMenuPresenterCallback;
  
  private boolean mFormatItems;
  
  private int mFormatItemsWidth;
  
  private int mGeneratedItemPadding;
  
  private MenuBuilder mMenu;
  
  MenuBuilder.Callback mMenuBuilderCallback;
  
  private int mMinCellSize;
  
  OnMenuItemClickListener mOnMenuItemClickListener;
  
  private Context mPopupContext;
  
  private int mPopupTheme;
  
  private ActionMenuPresenter mPresenter;
  
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mMinCellSize = (int)(56.0F * f);
    this.mGeneratedItemPadding = (int)(f * 4.0F);
    this.mPopupContext = paramContext;
    this.mPopupTheme = 0;
  }
  
  static int measureChildForCells(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   7: astore #10
    //   9: iload_3
    //   10: invokestatic getSize : (I)I
    //   13: iload #4
    //   15: isub
    //   16: iload_3
    //   17: invokestatic getMode : (I)I
    //   20: invokestatic makeMeasureSpec : (II)I
    //   23: istore #6
    //   25: aload_0
    //   26: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   29: ifeq -> 41
    //   32: aload_0
    //   33: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   36: astore #9
    //   38: goto -> 44
    //   41: aconst_null
    //   42: astore #9
    //   44: iconst_1
    //   45: istore #8
    //   47: aload #9
    //   49: ifnull -> 65
    //   52: aload #9
    //   54: invokevirtual hasText : ()Z
    //   57: ifeq -> 65
    //   60: iconst_1
    //   61: istore_3
    //   62: goto -> 67
    //   65: iconst_0
    //   66: istore_3
    //   67: iload_2
    //   68: ifle -> 142
    //   71: iconst_2
    //   72: istore #4
    //   74: iload_3
    //   75: ifeq -> 83
    //   78: iload_2
    //   79: iconst_2
    //   80: if_icmplt -> 142
    //   83: aload_0
    //   84: iload_2
    //   85: iload_1
    //   86: imul
    //   87: ldc -2147483648
    //   89: invokestatic makeMeasureSpec : (II)I
    //   92: iload #6
    //   94: invokevirtual measure : (II)V
    //   97: aload_0
    //   98: invokevirtual getMeasuredWidth : ()I
    //   101: istore #7
    //   103: iload #7
    //   105: iload_1
    //   106: idiv
    //   107: istore #5
    //   109: iload #5
    //   111: istore_2
    //   112: iload #7
    //   114: iload_1
    //   115: irem
    //   116: ifeq -> 124
    //   119: iload #5
    //   121: iconst_1
    //   122: iadd
    //   123: istore_2
    //   124: iload_3
    //   125: ifeq -> 139
    //   128: iload_2
    //   129: iconst_2
    //   130: if_icmpge -> 139
    //   133: iload #4
    //   135: istore_2
    //   136: goto -> 144
    //   139: goto -> 144
    //   142: iconst_0
    //   143: istore_2
    //   144: aload #10
    //   146: getfield isOverflowButton : Z
    //   149: ifne -> 159
    //   152: iload_3
    //   153: ifeq -> 159
    //   156: goto -> 162
    //   159: iconst_0
    //   160: istore #8
    //   162: aload #10
    //   164: iload #8
    //   166: putfield expandable : Z
    //   169: aload #10
    //   171: iload_2
    //   172: putfield cellsUsed : I
    //   175: aload_0
    //   176: iload_1
    //   177: iload_2
    //   178: imul
    //   179: ldc 1073741824
    //   181: invokestatic makeMeasureSpec : (II)I
    //   184: iload #6
    //   186: invokevirtual measure : (II)V
    //   189: iload_2
    //   190: ireturn
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore #12
    //   6: iload_1
    //   7: invokestatic getSize : (I)I
    //   10: istore_1
    //   11: iload_2
    //   12: invokestatic getSize : (I)I
    //   15: istore #6
    //   17: aload_0
    //   18: invokevirtual getPaddingLeft : ()I
    //   21: istore #5
    //   23: aload_0
    //   24: invokevirtual getPaddingRight : ()I
    //   27: istore #7
    //   29: aload_0
    //   30: invokevirtual getPaddingTop : ()I
    //   33: aload_0
    //   34: invokevirtual getPaddingBottom : ()I
    //   37: iadd
    //   38: istore #13
    //   40: iload_2
    //   41: iload #13
    //   43: bipush #-2
    //   45: invokestatic getChildMeasureSpec : (III)I
    //   48: istore #19
    //   50: iload_1
    //   51: iload #5
    //   53: iload #7
    //   55: iadd
    //   56: isub
    //   57: istore #14
    //   59: aload_0
    //   60: getfield mMinCellSize : I
    //   63: istore_2
    //   64: iload #14
    //   66: iload_2
    //   67: idiv
    //   68: istore_1
    //   69: iload_1
    //   70: ifne -> 81
    //   73: aload_0
    //   74: iload #14
    //   76: iconst_0
    //   77: invokevirtual setMeasuredDimension : (II)V
    //   80: return
    //   81: iload_2
    //   82: iload #14
    //   84: iload_2
    //   85: irem
    //   86: iload_1
    //   87: idiv
    //   88: iadd
    //   89: istore #20
    //   91: aload_0
    //   92: invokevirtual getChildCount : ()I
    //   95: istore #21
    //   97: iconst_0
    //   98: istore #5
    //   100: iconst_0
    //   101: istore #9
    //   103: iconst_0
    //   104: istore #7
    //   106: iconst_0
    //   107: istore #11
    //   109: iconst_0
    //   110: istore #10
    //   112: iconst_0
    //   113: istore #8
    //   115: lconst_0
    //   116: lstore #22
    //   118: iload #9
    //   120: iload #21
    //   122: if_icmpge -> 375
    //   125: aload_0
    //   126: iload #9
    //   128: invokevirtual getChildAt : (I)Landroid/view/View;
    //   131: astore #31
    //   133: aload #31
    //   135: invokevirtual getVisibility : ()I
    //   138: bipush #8
    //   140: if_icmpne -> 149
    //   143: iload #8
    //   145: istore_2
    //   146: goto -> 363
    //   149: aload #31
    //   151: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   154: istore #30
    //   156: iload #11
    //   158: iconst_1
    //   159: iadd
    //   160: istore #11
    //   162: iload #30
    //   164: ifeq -> 184
    //   167: aload_0
    //   168: getfield mGeneratedItemPadding : I
    //   171: istore_2
    //   172: aload #31
    //   174: iload_2
    //   175: iconst_0
    //   176: iload_2
    //   177: iconst_0
    //   178: invokevirtual setPadding : (IIII)V
    //   181: goto -> 184
    //   184: aload #31
    //   186: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   189: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   192: astore #32
    //   194: aload #32
    //   196: iconst_0
    //   197: putfield expanded : Z
    //   200: aload #32
    //   202: iconst_0
    //   203: putfield extraPixels : I
    //   206: aload #32
    //   208: iconst_0
    //   209: putfield cellsUsed : I
    //   212: aload #32
    //   214: iconst_0
    //   215: putfield expandable : Z
    //   218: aload #32
    //   220: iconst_0
    //   221: putfield leftMargin : I
    //   224: aload #32
    //   226: iconst_0
    //   227: putfield rightMargin : I
    //   230: iload #30
    //   232: ifeq -> 252
    //   235: aload #31
    //   237: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   240: invokevirtual hasText : ()Z
    //   243: ifeq -> 252
    //   246: iconst_1
    //   247: istore #30
    //   249: goto -> 255
    //   252: iconst_0
    //   253: istore #30
    //   255: aload #32
    //   257: iload #30
    //   259: putfield preventEdgeOffset : Z
    //   262: aload #32
    //   264: getfield isOverflowButton : Z
    //   267: ifeq -> 275
    //   270: iconst_1
    //   271: istore_2
    //   272: goto -> 277
    //   275: iload_1
    //   276: istore_2
    //   277: aload #31
    //   279: iload #20
    //   281: iload_2
    //   282: iload #19
    //   284: iload #13
    //   286: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   289: istore #15
    //   291: iload #10
    //   293: iload #15
    //   295: invokestatic max : (II)I
    //   298: istore #10
    //   300: iload #8
    //   302: istore_2
    //   303: aload #32
    //   305: getfield expandable : Z
    //   308: ifeq -> 316
    //   311: iload #8
    //   313: iconst_1
    //   314: iadd
    //   315: istore_2
    //   316: aload #32
    //   318: getfield isOverflowButton : Z
    //   321: ifeq -> 327
    //   324: iconst_1
    //   325: istore #7
    //   327: iload_1
    //   328: iload #15
    //   330: isub
    //   331: istore_1
    //   332: iload #5
    //   334: aload #31
    //   336: invokevirtual getMeasuredHeight : ()I
    //   339: invokestatic max : (II)I
    //   342: istore #5
    //   344: iload #15
    //   346: iconst_1
    //   347: if_icmpne -> 363
    //   350: lload #22
    //   352: iconst_1
    //   353: iload #9
    //   355: ishl
    //   356: i2l
    //   357: lor
    //   358: lstore #22
    //   360: goto -> 363
    //   363: iload #9
    //   365: iconst_1
    //   366: iadd
    //   367: istore #9
    //   369: iload_2
    //   370: istore #8
    //   372: goto -> 118
    //   375: iload #7
    //   377: ifeq -> 392
    //   380: iload #11
    //   382: iconst_2
    //   383: if_icmpne -> 392
    //   386: iconst_1
    //   387: istore #9
    //   389: goto -> 395
    //   392: iconst_0
    //   393: istore #9
    //   395: iconst_0
    //   396: istore_2
    //   397: iload_1
    //   398: istore #13
    //   400: iload #9
    //   402: istore #15
    //   404: iload #14
    //   406: istore #9
    //   408: iload #8
    //   410: ifle -> 735
    //   413: iload #13
    //   415: ifle -> 735
    //   418: iconst_0
    //   419: istore #17
    //   421: iconst_0
    //   422: istore #16
    //   424: ldc 2147483647
    //   426: istore #14
    //   428: lconst_0
    //   429: lstore #26
    //   431: iload #16
    //   433: iload #21
    //   435: if_icmpge -> 561
    //   438: aload_0
    //   439: iload #16
    //   441: invokevirtual getChildAt : (I)Landroid/view/View;
    //   444: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   447: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   450: astore #31
    //   452: aload #31
    //   454: getfield expandable : Z
    //   457: ifne -> 474
    //   460: iload #17
    //   462: istore_1
    //   463: iload #14
    //   465: istore #18
    //   467: lload #26
    //   469: lstore #24
    //   471: goto -> 541
    //   474: aload #31
    //   476: getfield cellsUsed : I
    //   479: iload #14
    //   481: if_icmpge -> 502
    //   484: aload #31
    //   486: getfield cellsUsed : I
    //   489: istore #18
    //   491: lconst_1
    //   492: iload #16
    //   494: lshl
    //   495: lstore #24
    //   497: iconst_1
    //   498: istore_1
    //   499: goto -> 541
    //   502: iload #17
    //   504: istore_1
    //   505: iload #14
    //   507: istore #18
    //   509: lload #26
    //   511: lstore #24
    //   513: aload #31
    //   515: getfield cellsUsed : I
    //   518: iload #14
    //   520: if_icmpne -> 541
    //   523: iload #17
    //   525: iconst_1
    //   526: iadd
    //   527: istore_1
    //   528: lload #26
    //   530: lconst_1
    //   531: iload #16
    //   533: lshl
    //   534: lor
    //   535: lstore #24
    //   537: iload #14
    //   539: istore #18
    //   541: iload #16
    //   543: iconst_1
    //   544: iadd
    //   545: istore #16
    //   547: iload_1
    //   548: istore #17
    //   550: iload #18
    //   552: istore #14
    //   554: lload #24
    //   556: lstore #26
    //   558: goto -> 431
    //   561: iload_2
    //   562: istore_1
    //   563: iload #5
    //   565: istore_2
    //   566: lload #22
    //   568: lload #26
    //   570: lor
    //   571: lstore #22
    //   573: iload #17
    //   575: iload #13
    //   577: if_icmple -> 583
    //   580: goto -> 740
    //   583: iconst_0
    //   584: istore_1
    //   585: iload_1
    //   586: iload #21
    //   588: if_icmpge -> 727
    //   591: aload_0
    //   592: iload_1
    //   593: invokevirtual getChildAt : (I)Landroid/view/View;
    //   596: astore #31
    //   598: aload #31
    //   600: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   603: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   606: astore #32
    //   608: iconst_1
    //   609: iload_1
    //   610: ishl
    //   611: i2l
    //   612: lstore #28
    //   614: lload #26
    //   616: lload #28
    //   618: land
    //   619: lconst_0
    //   620: lcmp
    //   621: ifne -> 654
    //   624: lload #22
    //   626: lstore #24
    //   628: aload #32
    //   630: getfield cellsUsed : I
    //   633: iload #14
    //   635: iconst_1
    //   636: iadd
    //   637: if_icmpne -> 647
    //   640: lload #22
    //   642: lload #28
    //   644: lor
    //   645: lstore #24
    //   647: lload #24
    //   649: lstore #22
    //   651: goto -> 720
    //   654: iload #15
    //   656: ifeq -> 696
    //   659: aload #32
    //   661: getfield preventEdgeOffset : Z
    //   664: ifeq -> 696
    //   667: iload #13
    //   669: iconst_1
    //   670: if_icmpne -> 696
    //   673: aload_0
    //   674: getfield mGeneratedItemPadding : I
    //   677: istore #5
    //   679: aload #31
    //   681: iload #5
    //   683: iload #20
    //   685: iadd
    //   686: iconst_0
    //   687: iload #5
    //   689: iconst_0
    //   690: invokevirtual setPadding : (IIII)V
    //   693: goto -> 696
    //   696: aload #32
    //   698: aload #32
    //   700: getfield cellsUsed : I
    //   703: iconst_1
    //   704: iadd
    //   705: putfield cellsUsed : I
    //   708: aload #32
    //   710: iconst_1
    //   711: putfield expanded : Z
    //   714: iload #13
    //   716: iconst_1
    //   717: isub
    //   718: istore #13
    //   720: iload_1
    //   721: iconst_1
    //   722: iadd
    //   723: istore_1
    //   724: goto -> 585
    //   727: iload_2
    //   728: istore #5
    //   730: iconst_1
    //   731: istore_2
    //   732: goto -> 408
    //   735: iload_2
    //   736: istore_1
    //   737: iload #5
    //   739: istore_2
    //   740: iload #7
    //   742: ifne -> 757
    //   745: iload #11
    //   747: iconst_1
    //   748: if_icmpne -> 757
    //   751: iconst_1
    //   752: istore #5
    //   754: goto -> 760
    //   757: iconst_0
    //   758: istore #5
    //   760: iload #13
    //   762: ifle -> 1107
    //   765: lload #22
    //   767: lconst_0
    //   768: lcmp
    //   769: ifeq -> 1107
    //   772: iload #13
    //   774: iload #11
    //   776: iconst_1
    //   777: isub
    //   778: if_icmplt -> 792
    //   781: iload #5
    //   783: ifne -> 792
    //   786: iload #10
    //   788: iconst_1
    //   789: if_icmple -> 1107
    //   792: lload #22
    //   794: invokestatic bitCount : (J)I
    //   797: i2f
    //   798: fstore #4
    //   800: iload #5
    //   802: ifne -> 895
    //   805: fload #4
    //   807: fstore_3
    //   808: lload #22
    //   810: lconst_1
    //   811: land
    //   812: lconst_0
    //   813: lcmp
    //   814: ifeq -> 843
    //   817: fload #4
    //   819: fstore_3
    //   820: aload_0
    //   821: iconst_0
    //   822: invokevirtual getChildAt : (I)Landroid/view/View;
    //   825: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   828: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   831: getfield preventEdgeOffset : Z
    //   834: ifne -> 843
    //   837: fload #4
    //   839: ldc 0.5
    //   841: fsub
    //   842: fstore_3
    //   843: iload #21
    //   845: iconst_1
    //   846: isub
    //   847: istore #5
    //   849: fload_3
    //   850: fstore #4
    //   852: lload #22
    //   854: iconst_1
    //   855: iload #5
    //   857: ishl
    //   858: i2l
    //   859: land
    //   860: lconst_0
    //   861: lcmp
    //   862: ifeq -> 895
    //   865: fload_3
    //   866: fstore #4
    //   868: aload_0
    //   869: iload #5
    //   871: invokevirtual getChildAt : (I)Landroid/view/View;
    //   874: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   877: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   880: getfield preventEdgeOffset : Z
    //   883: ifne -> 895
    //   886: fload_3
    //   887: ldc 0.5
    //   889: fsub
    //   890: fstore #4
    //   892: goto -> 895
    //   895: fload #4
    //   897: fconst_0
    //   898: fcmpl
    //   899: ifle -> 917
    //   902: iload #13
    //   904: iload #20
    //   906: imul
    //   907: i2f
    //   908: fload #4
    //   910: fdiv
    //   911: f2i
    //   912: istore #5
    //   914: goto -> 920
    //   917: iconst_0
    //   918: istore #5
    //   920: iconst_0
    //   921: istore #7
    //   923: iload_1
    //   924: istore #8
    //   926: iload #7
    //   928: iload #21
    //   930: if_icmpge -> 1110
    //   933: lload #22
    //   935: iconst_1
    //   936: iload #7
    //   938: ishl
    //   939: i2l
    //   940: land
    //   941: lconst_0
    //   942: lcmp
    //   943: ifne -> 952
    //   946: iload_1
    //   947: istore #8
    //   949: goto -> 1095
    //   952: aload_0
    //   953: iload #7
    //   955: invokevirtual getChildAt : (I)Landroid/view/View;
    //   958: astore #31
    //   960: aload #31
    //   962: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   965: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   968: astore #32
    //   970: aload #31
    //   972: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   975: ifeq -> 1020
    //   978: aload #32
    //   980: iload #5
    //   982: putfield extraPixels : I
    //   985: aload #32
    //   987: iconst_1
    //   988: putfield expanded : Z
    //   991: iload #7
    //   993: ifne -> 1017
    //   996: aload #32
    //   998: getfield preventEdgeOffset : Z
    //   1001: ifne -> 1017
    //   1004: aload #32
    //   1006: iload #5
    //   1008: ineg
    //   1009: iconst_2
    //   1010: idiv
    //   1011: putfield leftMargin : I
    //   1014: goto -> 1017
    //   1017: goto -> 1051
    //   1020: aload #32
    //   1022: getfield isOverflowButton : Z
    //   1025: ifeq -> 1057
    //   1028: aload #32
    //   1030: iload #5
    //   1032: putfield extraPixels : I
    //   1035: aload #32
    //   1037: iconst_1
    //   1038: putfield expanded : Z
    //   1041: aload #32
    //   1043: iload #5
    //   1045: ineg
    //   1046: iconst_2
    //   1047: idiv
    //   1048: putfield rightMargin : I
    //   1051: iconst_1
    //   1052: istore #8
    //   1054: goto -> 1095
    //   1057: iload #7
    //   1059: ifeq -> 1071
    //   1062: aload #32
    //   1064: iload #5
    //   1066: iconst_2
    //   1067: idiv
    //   1068: putfield leftMargin : I
    //   1071: iload_1
    //   1072: istore #8
    //   1074: iload #7
    //   1076: iload #21
    //   1078: iconst_1
    //   1079: isub
    //   1080: if_icmpeq -> 1095
    //   1083: aload #32
    //   1085: iload #5
    //   1087: iconst_2
    //   1088: idiv
    //   1089: putfield rightMargin : I
    //   1092: iload_1
    //   1093: istore #8
    //   1095: iload #7
    //   1097: iconst_1
    //   1098: iadd
    //   1099: istore #7
    //   1101: iload #8
    //   1103: istore_1
    //   1104: goto -> 923
    //   1107: iload_1
    //   1108: istore #8
    //   1110: iload #8
    //   1112: ifeq -> 1184
    //   1115: iconst_0
    //   1116: istore_1
    //   1117: iload_1
    //   1118: iload #21
    //   1120: if_icmpge -> 1184
    //   1123: aload_0
    //   1124: iload_1
    //   1125: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1128: astore #31
    //   1130: aload #31
    //   1132: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1135: checkcast androidx/appcompat/widget/ActionMenuView$LayoutParams
    //   1138: astore #32
    //   1140: aload #32
    //   1142: getfield expanded : Z
    //   1145: ifne -> 1151
    //   1148: goto -> 1177
    //   1151: aload #31
    //   1153: aload #32
    //   1155: getfield cellsUsed : I
    //   1158: iload #20
    //   1160: imul
    //   1161: aload #32
    //   1163: getfield extraPixels : I
    //   1166: iadd
    //   1167: ldc 1073741824
    //   1169: invokestatic makeMeasureSpec : (II)I
    //   1172: iload #19
    //   1174: invokevirtual measure : (II)V
    //   1177: iload_1
    //   1178: iconst_1
    //   1179: iadd
    //   1180: istore_1
    //   1181: goto -> 1117
    //   1184: iload #12
    //   1186: ldc 1073741824
    //   1188: if_icmpeq -> 1194
    //   1191: goto -> 1197
    //   1194: iload #6
    //   1196: istore_2
    //   1197: aload_0
    //   1198: iload #9
    //   1200: iload_2
    //   1201: invokevirtual setMeasuredDimension : (II)V
    //   1204: return
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dismissPopupMenus() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null)
      actionMenuPresenter.dismissPopupMenus(); 
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    LayoutParams layoutParams = new LayoutParams(-2, -2);
    layoutParams.gravity = 16;
    return layoutParams;
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      LayoutParams layoutParams;
      if (paramLayoutParams instanceof LayoutParams) {
        layoutParams = new LayoutParams((LayoutParams)paramLayoutParams);
      } else {
        layoutParams = new LayoutParams((ViewGroup.LayoutParams)layoutParams);
      } 
      if (layoutParams.gravity <= 0)
        layoutParams.gravity = 16; 
      return layoutParams;
    } 
    return generateDefaultLayoutParams();
  }
  
  public LayoutParams generateOverflowButtonLayoutParams() {
    LayoutParams layoutParams = generateDefaultLayoutParams();
    layoutParams.isOverflowButton = true;
    return layoutParams;
  }
  
  public Menu getMenu() {
    if (this.mMenu == null) {
      Context context = getContext();
      MenuBuilder menuBuilder = new MenuBuilder(context);
      this.mMenu = menuBuilder;
      menuBuilder.setCallback(new MenuBuilderCallback());
      ActionMenuPresenter actionMenuPresenter1 = new ActionMenuPresenter(context);
      this.mPresenter = actionMenuPresenter1;
      actionMenuPresenter1.setReserveOverflow(true);
      ActionMenuPresenter actionMenuPresenter2 = this.mPresenter;
      MenuPresenter.Callback callback = this.mActionMenuPresenterCallback;
      if (callback == null)
        callback = new ActionMenuPresenterCallback(); 
      actionMenuPresenter2.setCallback(callback);
      this.mMenu.addMenuPresenter((MenuPresenter)this.mPresenter, this.mPopupContext);
      this.mPresenter.setMenuView(this);
    } 
    return (Menu)this.mMenu;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    return this.mPresenter.getOverflowIcon();
  }
  
  public int getPopupTheme() {
    return this.mPopupTheme;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof ActionMenuChildView)
        i = false | ((ActionMenuChildView)view1).needsDividerAfter(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof ActionMenuChildView)
        bool = i | ((ActionMenuChildView)view2).needsDividerBefore(); 
    } 
    return bool;
  }
  
  public boolean hideOverflowMenu() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.hideOverflowMenu());
  }
  
  public void initialize(MenuBuilder paramMenuBuilder) {
    this.mMenu = paramMenuBuilder;
  }
  
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl) {
    return this.mMenu.performItemAction((MenuItem)paramMenuItemImpl, 0);
  }
  
  public boolean isOverflowMenuShowPending() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowPending());
  }
  
  public boolean isOverflowMenuShowing() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.isOverflowMenuShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    if (actionMenuPresenter != null) {
      actionMenuPresenter.updateMenuView(false);
      if (this.mPresenter.isOverflowMenuShowing()) {
        this.mPresenter.hideOverflowMenu();
        this.mPresenter.showOverflowMenu();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.mFormatItems) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int j = getChildCount();
    int i = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    paramInt1 = m - getPaddingRight() - getPaddingLeft();
    paramBoolean = ViewUtils.isLayoutRtl((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < j) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isOverflowButton) {
          int i1;
          int n = view.getMeasuredWidth();
          paramInt4 = n;
          if (hasSupportDividerBeforeChildAt(paramInt2))
            paramInt4 = n + k; 
          int i2 = view.getMeasuredHeight();
          if (paramBoolean) {
            i1 = getPaddingLeft() + layoutParams.leftMargin;
            n = i1 + paramInt4;
          } else {
            n = getWidth() - getPaddingRight() - layoutParams.rightMargin;
            i1 = n - paramInt4;
          } 
          int i3 = i - i2 / 2;
          view.layout(i1, i3, n, i2 + i3);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
          hasSupportDividerBeforeChildAt(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (j == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = m / 2 - paramInt1 / 2;
      paramInt4 = i - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= layoutParams.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2 - paramInt3, i1, paramInt2, n + i1);
            paramInt3 = paramInt2 - paramInt3 + layoutParams.leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += layoutParams.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            int n = view.getMeasuredHeight();
            int i1 = i - n / 2;
            view.layout(paramInt2, i1, paramInt2 + paramInt3, n + i1);
            paramInt3 = paramInt2 + paramInt3 + layoutParams.rightMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool2 = this.mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.mFormatItems = bool1;
    if (bool2 != bool1)
      this.mFormatItemsWidth = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.mFormatItems) {
      MenuBuilder menuBuilder = this.mMenu;
      if (menuBuilder != null && i != this.mFormatItemsWidth) {
        this.mFormatItemsWidth = i;
        menuBuilder.onItemsChanged(true);
      } 
    } 
    int j = getChildCount();
    if (this.mFormatItems && j > 0) {
      onMeasureExactFormat(paramInt1, paramInt2);
      return;
    } 
    for (i = 0; i < j; i++) {
      LayoutParams layoutParams = (LayoutParams)getChildAt(i).getLayoutParams();
      layoutParams.rightMargin = 0;
      layoutParams.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public MenuBuilder peekMenu() {
    return this.mMenu;
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mPresenter.setExpandedActionViewsExclusive(paramBoolean);
  }
  
  public void setMenuCallbacks(MenuPresenter.Callback paramCallback, MenuBuilder.Callback paramCallback1) {
    this.mActionMenuPresenterCallback = paramCallback;
    this.mMenuBuilderCallback = paramCallback1;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.mOnMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    this.mPresenter.setOverflowIcon(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.mPopupTheme != paramInt) {
      this.mPopupTheme = paramInt;
      if (paramInt == 0) {
        this.mPopupContext = getContext();
        return;
      } 
      this.mPopupContext = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter) {
    this.mPresenter = paramActionMenuPresenter;
    paramActionMenuPresenter.setMenuView(this);
  }
  
  public boolean showOverflowMenu() {
    ActionMenuPresenter actionMenuPresenter = this.mPresenter;
    return (actionMenuPresenter != null && actionMenuPresenter.showOverflowMenu());
  }
  
  public static interface ActionMenuChildView {
    boolean needsDividerAfter();
    
    boolean needsDividerBefore();
  }
  
  private static class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      return false;
    }
  }
  
  public static class LayoutParams extends LinearLayoutCompat.LayoutParams {
    @ExportedProperty
    public int cellsUsed;
    
    @ExportedProperty
    public boolean expandable;
    
    boolean expanded;
    
    @ExportedProperty
    public int extraPixels;
    
    @ExportedProperty
    public boolean isOverflowButton;
    
    @ExportedProperty
    public boolean preventEdgeOffset;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = false;
    }
    
    LayoutParams(int param1Int1, int param1Int2, boolean param1Boolean) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = param1Boolean;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super((ViewGroup.LayoutParams)param1LayoutParams);
      this.isOverflowButton = param1LayoutParams.isOverflowButton;
    }
  }
  
  private class MenuBuilderCallback implements MenuBuilder.Callback {
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return (ActionMenuView.this.mOnMenuItemClickListener != null && ActionMenuView.this.mOnMenuItemClickListener.onMenuItemClick(param1MenuItem));
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (ActionMenuView.this.mMenuBuilderCallback != null)
        ActionMenuView.this.mMenuBuilderCallback.onMenuModeChange(param1MenuBuilder); 
    }
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */