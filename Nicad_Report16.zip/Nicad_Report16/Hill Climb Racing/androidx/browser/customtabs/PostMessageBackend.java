package androidx.browser.customtabs;

import android.content.Context;
import android.os.Bundle;

public interface PostMessageBackend {
  void onDisconnectChannel(Context paramContext);
  
  boolean onNotifyMessageChannelReady(Bundle paramBundle);
  
  boolean onPostMessage(String paramString, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\browser\customtabs\PostMessageBackend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */