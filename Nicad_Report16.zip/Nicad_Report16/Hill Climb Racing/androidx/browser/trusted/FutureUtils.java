package androidx.browser.trusted;

import androidx.concurrent.futures.ResolvableFuture;
import com.google.common.util.concurrent.ListenableFuture;

class FutureUtils {
  static <T> ListenableFuture<T> immediateFailedFuture(Throwable paramThrowable) {
    ResolvableFuture resolvableFuture = ResolvableFuture.create();
    resolvableFuture.setException(paramThrowable);
    return (ListenableFuture<T>)resolvableFuture;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\browser\trusted\FutureUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */