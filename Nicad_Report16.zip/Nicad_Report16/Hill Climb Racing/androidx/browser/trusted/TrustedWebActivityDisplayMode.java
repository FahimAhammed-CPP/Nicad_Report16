package androidx.browser.trusted;

import android.os.Bundle;

public interface TrustedWebActivityDisplayMode {
  public static final String KEY_ID = "androidx.browser.trusted.displaymode.KEY_ID";
  
  Bundle toBundle();
  
  public static class DefaultMode implements TrustedWebActivityDisplayMode {
    private static final int ID = 0;
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putInt("androidx.browser.trusted.displaymode.KEY_ID", 0);
      return bundle;
    }
  }
  
  public static class ImmersiveMode implements TrustedWebActivityDisplayMode {
    private static final int ID = 1;
    
    public static final String KEY_CUTOUT_MODE = "androidx.browser.trusted.displaymode.KEY_CUTOUT_MODE";
    
    public static final String KEY_STICKY = "androidx.browser.trusted.displaymode.KEY_STICKY";
    
    private final boolean mIsSticky;
    
    private final int mLayoutInDisplayCutoutMode;
    
    public ImmersiveMode(boolean param1Boolean, int param1Int) {
      this.mIsSticky = param1Boolean;
      this.mLayoutInDisplayCutoutMode = param1Int;
    }
    
    static TrustedWebActivityDisplayMode fromBundle(Bundle param1Bundle) {
      return new ImmersiveMode(param1Bundle.getBoolean("androidx.browser.trusted.displaymode.KEY_STICKY"), param1Bundle.getInt("androidx.browser.trusted.displaymode.KEY_CUTOUT_MODE"));
    }
    
    public boolean isSticky() {
      return this.mIsSticky;
    }
    
    public int layoutInDisplayCutoutMode() {
      return this.mLayoutInDisplayCutoutMode;
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      bundle.putInt("androidx.browser.trusted.displaymode.KEY_ID", 1);
      bundle.putBoolean("androidx.browser.trusted.displaymode.KEY_STICKY", this.mIsSticky);
      bundle.putInt("androidx.browser.trusted.displaymode.KEY_CUTOUT_MODE", this.mLayoutInDisplayCutoutMode);
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityDisplayMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */