package androidx.core.animation;

import android.animation.Animator;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000(\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\002\n\002\b\004\n\002\030\002\n\002\b\n\032¤\001\020\000\032\0020\001*\0020\0022#\b\006\020\003\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\t\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\n\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\013\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\032Z\020\f\032\0020\r*\0020\0022#\b\006\020\016\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\0042#\b\006\020\017\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\020\032\0020\001*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\022\032\0020\001*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\023\032\0020\r*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\024\032\0020\001*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\025\032\0020\r*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\0325\020\026\032\0020\001*\0020\0022#\b\004\020\021\032\035\022\023\022\0210\002¢\006\f\b\005\022\b\b\006\022\004\b\b(\007\022\004\022\0020\b0\004H\bø\001\000\002\007\n\005\b20\001¨\006\027"}, d2 = {"addListener", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "onEnd", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "animator", "", "onStart", "onCancel", "onRepeat", "addPauseListener", "Landroid/animation/Animator$AnimatorPauseListener;", "onResume", "onPause", "doOnCancel", "action", "doOnEnd", "doOnPause", "doOnRepeat", "doOnResume", "doOnStart", "core-ktx_release"}, k = 2, mv = {1, 6, 0}, xi = 48)
public final class AnimatorKt {
  public static final Animator.AnimatorListener addListener(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction11, Function1<? super Animator, Unit> paramFunction12, Function1<? super Animator, Unit> paramFunction13, Function1<? super Animator, Unit> paramFunction14) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction11, "onEnd");
    Intrinsics.checkNotNullParameter(paramFunction12, "onStart");
    Intrinsics.checkNotNullParameter(paramFunction13, "onCancel");
    Intrinsics.checkNotNullParameter(paramFunction14, "onRepeat");
    AnimatorKt$addListener$listener$1 animatorKt$addListener$listener$1 = new AnimatorKt$addListener$listener$1(paramFunction14, paramFunction11, paramFunction13, paramFunction12);
    paramAnimator.addListener(animatorKt$addListener$listener$1);
    return animatorKt$addListener$listener$1;
  }
  
  public static final Animator.AnimatorPauseListener addPauseListener(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction11, Function1<? super Animator, Unit> paramFunction12) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction11, "onResume");
    Intrinsics.checkNotNullParameter(paramFunction12, "onPause");
    AnimatorKt$addPauseListener$listener$1 animatorKt$addPauseListener$listener$1 = new AnimatorKt$addPauseListener$listener$1(paramFunction12, paramFunction11);
    paramAnimator.addPauseListener(animatorKt$addPauseListener$listener$1);
    return animatorKt$addPauseListener$listener$1;
  }
  
  public static final Animator.AnimatorListener doOnCancel(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnCancel$$inlined$addListener$default$1 animatorKt$doOnCancel$$inlined$addListener$default$1 = new AnimatorKt$doOnCancel$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnCancel$$inlined$addListener$default$1);
    return animatorKt$doOnCancel$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorListener doOnEnd(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnEnd$$inlined$addListener$default$1 animatorKt$doOnEnd$$inlined$addListener$default$1 = new AnimatorKt$doOnEnd$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnEnd$$inlined$addListener$default$1);
    return animatorKt$doOnEnd$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorPauseListener doOnPause(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnPause$$inlined$addPauseListener$default$1 animatorKt$doOnPause$$inlined$addPauseListener$default$1 = new AnimatorKt$doOnPause$$inlined$addPauseListener$default$1(paramFunction1);
    paramAnimator.addPauseListener(animatorKt$doOnPause$$inlined$addPauseListener$default$1);
    return animatorKt$doOnPause$$inlined$addPauseListener$default$1;
  }
  
  public static final Animator.AnimatorListener doOnRepeat(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnRepeat$$inlined$addListener$default$1 animatorKt$doOnRepeat$$inlined$addListener$default$1 = new AnimatorKt$doOnRepeat$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnRepeat$$inlined$addListener$default$1);
    return animatorKt$doOnRepeat$$inlined$addListener$default$1;
  }
  
  public static final Animator.AnimatorPauseListener doOnResume(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnResume$$inlined$addPauseListener$default$1 animatorKt$doOnResume$$inlined$addPauseListener$default$1 = new AnimatorKt$doOnResume$$inlined$addPauseListener$default$1(paramFunction1);
    paramAnimator.addPauseListener(animatorKt$doOnResume$$inlined$addPauseListener$default$1);
    return animatorKt$doOnResume$$inlined$addPauseListener$default$1;
  }
  
  public static final Animator.AnimatorListener doOnStart(Animator paramAnimator, Function1<? super Animator, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramAnimator, "<this>");
    Intrinsics.checkNotNullParameter(paramFunction1, "action");
    AnimatorKt$doOnStart$$inlined$addListener$default$1 animatorKt$doOnStart$$inlined$addListener$default$1 = new AnimatorKt$doOnStart$$inlined$addListener$default$1(paramFunction1);
    paramAnimator.addListener(animatorKt$doOnStart$$inlined$addListener$default$1);
    return animatorKt$doOnStart$$inlined$addListener$default$1;
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addListener$1 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$1 INSTANCE = new AnimatorKt$addListener$1();
    
    public AnimatorKt$addListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addListener$2 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$2 INSTANCE = new AnimatorKt$addListener$2();
    
    public AnimatorKt$addListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addListener$3 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$3 INSTANCE = new AnimatorKt$addListener$3();
    
    public AnimatorKt$addListener$3() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addListener$4 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addListener$4 INSTANCE = new AnimatorKt$addListener$4();
    
    public AnimatorKt$addListener$4() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026¨\006\t"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "onAnimationCancel", "", "animator", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationRepeat", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addListener$listener$1 implements Animator.AnimatorListener {
    public AnimatorKt$addListener$listener$1(Function1<? super Animator, Unit> param1Function11, Function1<? super Animator, Unit> param1Function12, Function1<? super Animator, Unit> param1Function13, Function1<? super Animator, Unit> param1Function14) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onStart.invoke(param1Animator);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addPauseListener$1 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addPauseListener$1 INSTANCE = new AnimatorKt$addPauseListener$1();
    
    public AnimatorKt$addPauseListener$1() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\000\n\002\030\002\n\000\020\000\032\0020\0012\006\020\002\032\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "", "it", "Landroid/animation/Animator;", "invoke"}, k = 3, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addPauseListener$2 extends Lambda implements Function1<Animator, Unit> {
    public static final AnimatorKt$addPauseListener$2 INSTANCE = new AnimatorKt$addPauseListener$2();
    
    public AnimatorKt$addPauseListener$2() {
      super(1);
    }
    
    public final void invoke(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "it");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/core/animation/AnimatorKt$addPauseListener$listener$1", "Landroid/animation/Animator$AnimatorPauseListener;", "onAnimationPause", "", "animator", "Landroid/animation/Animator;", "onAnimationResume", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$addPauseListener$listener$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$addPauseListener$listener$1(Function1<? super Animator, Unit> param1Function11, Function1<? super Animator, Unit> param1Function12) {}
    
    public void onAnimationPause(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onPause.invoke(param1Animator);
    }
    
    public void onAnimationResume(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onResume.invoke(param1Animator);
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026¨\006\t¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "onAnimationCancel", "", "animator", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationRepeat", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnCancel$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnCancel$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onCancel.invoke(param1Animator);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026¨\006\t¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "onAnimationCancel", "", "animator", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationRepeat", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnEnd$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnEnd$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onEnd.invoke(param1Animator);
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addPauseListener$listener$1", "Landroid/animation/Animator$AnimatorPauseListener;", "onAnimationPause", "", "animator", "Landroid/animation/Animator;", "onAnimationResume", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnPause$$inlined$addPauseListener$default$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$doOnPause$$inlined$addPauseListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationPause(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onPause.invoke(param1Animator);
    }
    
    public void onAnimationResume(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026¨\006\t¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "onAnimationCancel", "", "animator", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationRepeat", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnRepeat$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnRepeat$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onRepeat.invoke(param1Animator);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addPauseListener$listener$1", "Landroid/animation/Animator$AnimatorPauseListener;", "onAnimationPause", "", "animator", "Landroid/animation/Animator;", "onAnimationResume", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnResume$$inlined$addPauseListener$default$1 implements Animator.AnimatorPauseListener {
    public AnimatorKt$doOnResume$$inlined$addPauseListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationPause(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationResume(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onResume.invoke(param1Animator);
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\007\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\b\032\0020\0032\006\020\004\032\0020\005H\026¨\006\t¸\006\000"}, d2 = {"androidx/core/animation/AnimatorKt$addListener$listener$1", "Landroid/animation/Animator$AnimatorListener;", "onAnimationCancel", "", "animator", "Landroid/animation/Animator;", "onAnimationEnd", "onAnimationRepeat", "onAnimationStart", "core-ktx_release"}, k = 1, mv = {1, 6, 0}, xi = 176)
  public static final class AnimatorKt$doOnStart$$inlined$addListener$default$1 implements Animator.AnimatorListener {
    public AnimatorKt$doOnStart$$inlined$addListener$default$1(Function1 param1Function1) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationRepeat(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
    }
    
    public void onAnimationStart(Animator param1Animator) {
      Intrinsics.checkNotNullParameter(param1Animator, "animator");
      this.$onStart.invoke(param1Animator);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Hill Climb Racing-dex2jar.jar!\androidx\core\animation\AnimatorKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */